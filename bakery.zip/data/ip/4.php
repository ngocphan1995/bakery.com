<?php

$ranges = array(50331648 => array(83886079, 'US'));