<?php

$ranges = array(4009754624 => array(4278190079, 'ZZ'));