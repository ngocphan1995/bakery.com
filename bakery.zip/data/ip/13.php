<?php

$ranges = array(201326592 => array(234881023, 'US'));