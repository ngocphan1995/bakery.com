<?php

$ranges = array();