<?php

$ranges = array(419430400 => array(436207615, 'GB'));