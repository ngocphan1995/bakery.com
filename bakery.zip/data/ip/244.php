<?php

$ranges = array(3841982464 => array(4110417919, 'ZZ'));