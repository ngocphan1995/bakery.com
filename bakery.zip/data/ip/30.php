<?php

$ranges = array(486539264 => array(520093695, 'US'));