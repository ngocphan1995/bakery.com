<?php

$ranges = array(3758096384 => array(4294967295, 'ZZ'));