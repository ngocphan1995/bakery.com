<?php

$ranges = array(251658240 => array(385875967, 'US'));