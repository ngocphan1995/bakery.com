<?php

$ranges = array(3875536896 => array(4143972351, 'ZZ'));