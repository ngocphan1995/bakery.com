<?php

$ranges = array(301989888 => array(369098751, 'US'));