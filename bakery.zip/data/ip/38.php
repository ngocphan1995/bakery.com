<?php

$ranges = array(637534208 => array(654311423, 'US'));