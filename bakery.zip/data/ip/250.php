<?php

$ranges = array(3942645760 => array(4211081215, 'ZZ'));