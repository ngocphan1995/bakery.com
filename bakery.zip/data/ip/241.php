<?php

$ranges = array(3791650816 => array(4060086271, 'ZZ'));