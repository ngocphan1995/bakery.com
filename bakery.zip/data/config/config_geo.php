<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 16 Dec 2012 11:25:59 GMT
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$config_geo = array();
$config_geo['AD'] = 'vi';
$config_geo['AE'] = 'vi';
$config_geo['AF'] = 'vi';