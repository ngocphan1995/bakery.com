-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: April 26, 2016, 07:36 AM GMT
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `bakery`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'c339b05331d1f0087cc99c2e243376e4', 1461314382, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, 'a7ac2ebfda1f18f77744c59181605686'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, 'f2e1105b18a31e8302a9a441fbf2063e'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, 'af638307321dab6a0b2bb870e8e29350'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, '18261946aefe82ed0423dbc548f2c4f2'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '8e12d6d80d55957723e23f8b883f8f36'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, 'c3182116feb8322b960399acbf144ca4'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, 'fc1f3e7a4355df61b0338dd8477226ff'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '2b6e83d79ee6bd276404d022f864cf09'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '4c3860963a9a812fcc6d511ff2728ef4'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '034d20b51b0bf144fb0411fa0489850a'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '4b1983f1b9b4ee5070227e3efef555fb');


-- ---------------------------------------


--
-- Table structure for table `nv4_banip`
--

DROP TABLE IF EXISTS `nv4_banip`;
CREATE TABLE `nv4_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_clients`
--

DROP TABLE IF EXISTS `nv4_banners_clients`;
CREATE TABLE `nv4_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 370, 200, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1), 
(3, '', 'Quảng cáo ở trái trang', '', 'sequential', 165, 500, 1), 
(4, '', 'Quảng cáo phải_body', '', 'sequential', 290, 300, 1), 
(5, '', 'quảng cao trái dong 2', '', 'sequential', 230, 150, 1), 
(6, '', 'Quảng cáo giữa dòng 2', '', 'sequential', 600, 150, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', '', 'http://www.mofa.gov.vn', '_blank', 1459471000, 1459471000, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', '', 'http://vinades.vn', '_blank', 1459471000, 1459471000, 0, 0, 1, 2), 
(6, 'quảng cáo bánh quy', 4, 0, 'banner3.png', 'png', 'image/png', 270, 254, '', '', 'http://demo.magentech.com/themes/sm_bakery/#', '_blank', 1460345537, 1460345537, 0, 0, 1, 1), 
(4, 'quảng cáo bánh', 3, 0, 'banner1.png', 'png', 'image/png', 180, 254, '', '', 'http://demo.magentech.com/themes/sm_bakery/#', '_blank', 1460345145, 1460345145, 0, 0, 1, 1), 
(5, 'quảng cáo bánh kato', 1, 0, 'banner2.png', 'png', 'image/png', 390, 254, '', '', 'http://demo.magentech.com/themes/sm_bakery/#', '_blank', 1460345379, 1460345379, 0, 0, 1, 1), 
(7, 'quảng cáo bánh kem', 5, 0, 'banner4.png', 'png', 'image/png', 270, 147, '', '', 'http://demo.magentech.com/themes/sm_bakery/#', '_blank', 1460345819, 1460345819, 0, 0, 1, 1), 
(8, 'quảng cáo bánh cuộn', 6, 0, 'banner5.png', 'png', 'image/png', 590, 147, 'abc', '', 'http://demo.magentech.com/themes/sm_bakery/#', '_blank', 1460345922, 1460345922, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '10485760'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', ''), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '13'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.24'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'auto_login_after_reg', '1'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '2'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '8'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'Phan Thị Ngọc'), 
('vi', 'global', 'site_logo', 'uploads/logo.png'), 
('vi', 'global', 'site_banner', ''), 
('vi', 'global', 'site_favicon', ''), 
('vi', 'global', 'site_description', 'Default welcome msg&#33;'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'bakery'), 
('vi', 'global', 'mobile_theme', 'mobile_default'), 
('vi', 'global', 'site_home_module', 'shops'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'upload_logo', ''), 
('vi', 'global', 'upload_logo_pos', 'bottomRight'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1461656512'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'global', 'ssl_https_modules', ''), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '0'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('vi', 'siteterms', 'auto_postcomm', '1'), 
('vi', 'siteterms', 'allowed_comm', '-1'), 
('vi', 'siteterms', 'view_comm', '6'), 
('vi', 'siteterms', 'setcomm', '4'), 
('vi', 'siteterms', 'activecomm', '0'), 
('vi', 'siteterms', 'emailcomm', '0'), 
('vi', 'siteterms', 'adminscomm', ''), 
('vi', 'siteterms', 'sortcomm', '0'), 
('vi', 'siteterms', 'captcha', '1'), 
('vi', 'freecontent', 'next_execute', '0'), 
('vi', 'contact', 'bodytext', 'Forem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque convallis ligula eget tellus lacinia tristique. Vivamus convallis tristique fringilla. Pellentesque pharetra, lacus tincidunt pulvinar facilisis. Fellus risus varius augue, sit amet dictum turpis justo eget felis. Curabitur convallis cursus velit, vel convallis sem aliquam a. Sed non dui consectetur enim mattis suscipit sit amet ac nunc.<br  />
<br  />
Fellus risus varius augue, sit amet dictum turpis justo eget felis. Curabitur convallis cursus velit, vel convallis sem aliquam a. Sed non dui consectetur enim mattis suscipit sit amet ac nunc. Donec vestibulum, dui a tristique suscipit, erat mi tristique mi, sit amet posuere nunc sapien tincidunt urna. Quisque id turpis tincidunt orci euismod fermentum ac eget purus. Duis eget dictum velit. Suspendisse turpis mauris, molestie ut pharetra sed, tempor vitae mauris. Ut eget facilisis nulla. Nunc non libero ligula. Forem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque convallis.<br  />
&nbsp;<iframe allowfullscreen=\"allowfullscreen\" frameborder=\"0\" height=\"450\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3725.197795236852!2d105.79351331445388!3d20.984706994657678!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac93055e2f2f%3A0x91f4b423089193dd!2zQ8O0bmcgdHkgQ-G7lSBwaOG6p24gUGjDoXQgdHJp4buDbiBOZ3Xhu5NuIG3hu58gVmnhu4d0IE5hbSAoVklOQURFUyk!5e0!3m2!1svi!2s!4v1461124096040\" style=\"border:0\" width=\"100%\"></iframe>'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'ngocphan1201995@gmail.com'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'ngocphan1201995@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'bakery.com'), 
('sys', 'global', 'cookie_prefix', 'nv4c_u63y5'), 
('sys', 'global', 'session_prefix', 'nv4s_z7Or06'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'Jl9qi0JzaT08MFesFxlwRiZfaotCc2k9PDBXrBcZcEY,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'shops', 'image_size', '100x100'), 
('vi', 'shops', 'home_view', 'view_home_none'), 
('vi', 'shops', 'per_page', '10'), 
('vi', 'shops', 'per_row', '4'), 
('vi', 'shops', 'money_unit', 'VND'), 
('vi', 'shops', 'weight_unit', 'g'), 
('vi', 'shops', 'post_auto_member', '0'), 
('vi', 'shops', 'auto_check_order', '1'), 
('vi', 'shops', 'format_order_id', 'S%06s'), 
('vi', 'shops', 'format_code_id', 'S%06s'), 
('vi', 'shops', 'facebookappid', ''), 
('vi', 'shops', 'active_guest_order', '1'), 
('vi', 'shops', 'active_showhomtext', '1'), 
('vi', 'shops', 'active_order', '1'), 
('vi', 'shops', 'active_order_popup', '1'), 
('vi', 'shops', 'active_order_non_detail', '1'), 
('vi', 'shops', 'active_price', '1'), 
('vi', 'shops', 'active_order_number', '0'), 
('vi', 'shops', 'order_day', '0'), 
('vi', 'shops', 'order_nexttime', '0'), 
('vi', 'shops', 'active_payment', '1'), 
('vi', 'shops', 'groups_price', '3'), 
('vi', 'shops', 'active_tooltip', '1'), 
('vi', 'shops', 'timecheckstatus', '0'), 
('vi', 'shops', 'show_product_code', '1'), 
('vi', 'shops', 'show_compare', '0'), 
('vi', 'shops', 'show_displays', '0'), 
('vi', 'shops', 'use_shipping', '0'), 
('vi', 'shops', 'use_coupons', '0'), 
('vi', 'shops', 'active_wishlist', '1'), 
('vi', 'shops', 'active_gift', '1'), 
('vi', 'shops', 'active_warehouse', '1'), 
('vi', 'shops', 'tags_alias', '0'), 
('vi', 'shops', 'auto_tags', '1'), 
('vi', 'shops', 'tags_remind', '0'), 
('vi', 'shops', 'point_active', '0'), 
('vi', 'shops', 'point_conversion', '0'), 
('vi', 'shops', 'point_new_order', '0'), 
('vi', 'shops', 'review_active', '1'), 
('vi', 'shops', 'review_check', '1'), 
('vi', 'shops', 'review_captcha', '1'), 
('vi', 'shops', 'group_price', ''), 
('vi', 'shops', 'groups_notify', '3'), 
('vi', 'shops', 'template_active', '0'), 
('vi', 'shops', 'download_active', '0'), 
('vi', 'shops', 'download_groups', '6'), 
('vi', 'shops', 'alias_lower', '1'), 
('vi', 'shops', 'auto_postcomm', '1'), 
('vi', 'shops', 'allowed_comm', '-1'), 
('vi', 'shops', 'view_comm', '6'), 
('vi', 'shops', 'setcomm', '4'), 
('vi', 'shops', 'activecomm', '1'), 
('vi', 'shops', 'emailcomm', '0'), 
('vi', 'shops', 'adminscomm', ''), 
('vi', 'shops', 'sortcomm', '0'), 
('vi', 'shops', 'captcha', '1'), 
('vi', 'new2', 'indexfile', 'viewcat_main_right'), 
('vi', 'new2', 'per_page', '20'), 
('vi', 'new2', 'st_links', '10'), 
('vi', 'new2', 'homewidth', '100'), 
('vi', 'new2', 'homeheight', '150'), 
('vi', 'new2', 'blockwidth', '52'), 
('vi', 'new2', 'blockheight', '75'), 
('vi', 'new2', 'imagefull', '460'), 
('vi', 'new2', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'new2', 'showtooltip', '1'), 
('vi', 'new2', 'tooltip_position', 'bottom'), 
('vi', 'new2', 'tooltip_length', '150'), 
('vi', 'new2', 'showhometext', '1'), 
('vi', 'new2', 'timecheckstatus', '0'), 
('vi', 'new2', 'config_source', '0'), 
('vi', 'new2', 'show_no_image', ''), 
('vi', 'new2', 'allowed_rating_point', '1'), 
('vi', 'new2', 'facebookappid', ''), 
('vi', 'new2', 'socialbutton', '1'), 
('vi', 'new2', 'alias_lower', '1'), 
('vi', 'new2', 'tags_alias', '0'), 
('vi', 'new2', 'auto_tags', '0'), 
('vi', 'new2', 'tags_remind', '1'), 
('vi', 'new2', 'structure_upload', 'Ym'), 
('vi', 'new2', 'imgposition', '2'), 
('vi', 'new2', 'auto_postcomm', '1'), 
('vi', 'new2', 'allowed_comm', '-1'), 
('vi', 'new2', 'view_comm', '6'), 
('vi', 'new2', 'setcomm', '4'), 
('vi', 'new2', 'activecomm', '1'), 
('vi', 'new2', 'emailcomm', '0'), 
('vi', 'new2', 'adminscomm', ''), 
('vi', 'new2', 'sortcomm', '0'), 
('vi', 'new2', 'captcha', '1');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1461656198, 0), 
('total', 'hits', 1461656198, 96, 96), 
('year', '2016', 1461656198, 96, 96), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('year', '2024', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 1461656198, 96, 96), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 1459521658, 9, 9), 
('day', '02', 1459615131, 4, 4), 
('day', '03', 1459702456, 3, 3), 
('day', '04', 1459763264, 9, 9), 
('day', '05', 0, 0, 0), 
('day', '06', 1459936174, 8, 8), 
('day', '07', 0, 0, 0), 
('day', '08', 1460108562, 7, 7), 
('day', '09', 1460217958, 1, 1), 
('day', '10', 1460307426, 4, 4), 
('day', '11', 1460348901, 9, 9), 
('day', '12', 1460480116, 15, 15), 
('day', '13', 1460541509, 11, 11), 
('day', '14', 0, 0, 0), 
('day', '15', 1460738439, 8, 8), 
('day', '16', 1460740447, 1, 1), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 1461125307, 4, 4), 
('day', '21', 0, 0, 0), 
('day', '22', 1461314311, 2, 2), 
('day', '23', 0, 0, 0), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 1461656198, 1, 1), 
('day', '27', 0, 0, 0), 
('day', '28', 0, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 1460307426, 7, 7), 
('dayofweek', 'Monday', 1460348901, 18, 18), 
('dayofweek', 'Tuesday', 1461656198, 16, 16), 
('dayofweek', 'Wednesday', 1461125307, 23, 23), 
('dayofweek', 'Thursday', 0, 0, 0), 
('dayofweek', 'Friday', 1461314311, 26, 26), 
('dayofweek', 'Saturday', 1460740447, 6, 6), 
('hour', '00', 1460740447, 0, 0), 
('hour', '01', 1459706725, 0, 0), 
('hour', '02', 0, 0, 0), 
('hour', '03', 0, 0, 0), 
('hour', '04', 0, 0, 0), 
('hour', '05', 0, 0, 0), 
('hour', '06', 0, 0, 0), 
('hour', '07', 1459471167, 0, 0), 
('hour', '08', 1460339676, 0, 0), 
('hour', '09', 1461119409, 0, 0), 
('hour', '10', 1461123474, 0, 0), 
('hour', '11', 1461125307, 0, 0), 
('hour', '12', 0, 0, 0), 
('hour', '13', 1461306547, 0, 0), 
('hour', '14', 1461656198, 1, 1), 
('hour', '15', 1461314311, 0, 0), 
('hour', '16', 1460714293, 0, 0), 
('hour', '17', 1460457978, 0, 0), 
('hour', '18', 1460461605, 0, 0), 
('hour', '19', 1460465211, 0, 0), 
('hour', '20', 1460468818, 0, 0), 
('hour', '21', 1460470621, 0, 0), 
('hour', '22', 1460475928, 0, 0), 
('hour', '23', 1460738439, 0, 0), 
('bot', 'googlebot', 0, 0, 0), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 0, 0, 0), 
('browser', 'edge', 0, 0, 0), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1461656198, 14, 14), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 0, 0, 0), 
('browser', 'iphone', 0, 0, 0), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1461125307, 82, 82), 
('browser', 'android', 0, 0, 0), 
('browser', 'googlebot', 0, 0, 0), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('os', 'unknown', 0, 0, 0), 
('os', 'win', 0, 0, 0), 
('os', 'win10', 0, 0, 0), 
('os', 'win8', 1461656198, 96, 96), 
('os', 'win7', 0, 0, 0), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 0, 0, 0), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 0, 0, 0), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1461656198, 96, 96), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1459471000, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1461656212, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1459471000, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1461306556, 1, 'Tự động lưu CSDL'), 
(3, 1459471000, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1461318038, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1459471000, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1461318038, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1459471000, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1461306556, 1, 'Xóa các file error_log quá hạn'), 
(6, 1459471000, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1459471000, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1461318038, 1, 'Xóa các referer quá hạn'), 
(8, 1459471000, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1461306556, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1459471000, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1461318038, 1, 'Kiểm tra phiên bản NukeViet'), 
(10, 1459471000, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1461306556, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `nv4_extension_files`
--

DROP TABLE IF EXISTS `nv4_extension_files`;
CREATE TABLE `nv4_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_googleplus`
--

DROP TABLE IF EXISTS `nv4_googleplus`;
CREATE TABLE `nv4_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_groups`
--

DROP TABLE IF EXISTS `nv4_groups`;
CREATE TABLE `nv4_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240) NOT NULL,
  `description` text,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups`
--

INSERT INTO `nv4_groups` VALUES
(1, 'Super admin', 'Super Admin', '', 1459471000, 0, 0, 1, 1, 0, 1, 0), 
(2, 'General admin', 'General Admin', '', 1459471000, 0, 0, 2, 1, 0, 0, 0), 
(3, 'Module admin', 'Module Admin', '', 1459471000, 0, 0, 3, 1, 0, 0, 0), 
(4, 'Users', 'Users', '', 1459471000, 0, 0, 4, 1, 0, 1, 0), 
(5, 'Guest', 'Guest', '', 1459471000, 0, 0, 5, 1, 0, 0, 0), 
(6, 'All', 'All', '', 1459471000, 0, 0, 6, 1, 0, 0, 0), 
(10, 'NukeViet-Fans', 'Nhóm những người hâm mộ hệ thống NukeViet', '', 1459471000, 0, 1, 7, 1, 0, 0, 0), 
(11, 'NukeViet-Admins', 'Nhóm những người quản lý website xây dựng bằng hệ thống NukeViet', '', 1459471000, 0, 1, 8, 1, 0, 0, 0), 
(12, 'NukeViet-Programmers', 'Nhóm Lập trình viên hệ thống NukeViet', '', 1459471000, 0, 1, 9, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_groups_users`
--

DROP TABLE IF EXISTS `nv4_groups_users`;
CREATE TABLE `nv4_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups_users`
--

INSERT INTO `nv4_groups_users` VALUES
(1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(200) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=200  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_logs`
--

INSERT INTO `nv4_logs` VALUES
(1, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1459471302), 
(2, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1459471308), 
(3, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459471318), 
(4, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1459471352), 
(5, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1459471370), 
(6, 'vi', 'themes', 'Thiết lập giao diện theme: \"bakery\"', '', '', 1, 1459471655), 
(7, 'vi', 'themes', 'Kích hoạt theme: \"bakery\"', '', '', 1, 1459471661), 
(8, 'vi', 'themes', 'Kích hoạt theme: \"bakery\"', '', '', 1, 1459471661), 
(9, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459474145), 
(10, 'vi', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1459474200), 
(11, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459496977), 
(12, 'vi', 'modules', 'Thứ tự module: shops', '15 -> 1', '', 1, 1459497047), 
(13, 'vi', 'modules', 'Thứ tự module: freecontent', '15 -> 1', '', 1, 1459497051), 
(14, 'vi', 'modules', 'Thứ tự module: shops', '15 -> 1', '', 1, 1459497059), 
(15, 'vi', 'upload', 'Upload file', 'uploads/menu/flag-default.png', '', 1, 1459497671), 
(16, 'vi', 'themes', 'Sửa block', 'Name : Contact Default', '', 1, 1459497718), 
(17, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1459497755), 
(18, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1459504746), 
(19, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459698550), 
(20, 'vi', 'upload', 'Upload file', 'uploads/sl1.png', '', 1, 1459698638), 
(21, 'vi', 'upload', 'Upload file', 'uploads/3_2.jpg', '', 1, 1459698639), 
(22, 'vi', 'upload', 'Upload file', 'uploads/5_5.jpg', '', 1, 1459698640), 
(23, 'vi', 'upload', 'Upload file', 'uploads/6.jpg', '', 1, 1459698640), 
(24, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459698673), 
(25, 'vi', 'themes', 'Sửa block', 'Name : global image', '', 1, 1459698726), 
(26, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1459752430), 
(27, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1459752437), 
(28, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459752450), 
(29, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459752990), 
(30, 'vi', 'themes', 'Sửa block', 'Name : global image', '', 1, 1459753078), 
(31, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459753226), 
(32, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459753896), 
(33, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459755271), 
(34, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459755453), 
(35, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459755498), 
(36, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459755558), 
(37, 'vi', 'themes', 'Thêm block', 'Name : global image', '', 1, 1459755594), 
(38, 'vi', 'themes', 'Sửa block', 'Name : global image', '', 1, 1459755645), 
(39, 'vi', 'themes', 'Sửa block', 'Name : global image', '', 1, 1459756491), 
(40, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459763707), 
(41, 'vi', 'themes', 'Thêm block', 'Name : global html', '', 1, 1459764005), 
(42, 'vi', 'themes', 'Sửa block', 'Name : global html', '', 1, 1459764214), 
(43, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459764232), 
(44, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459764339), 
(45, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459764355), 
(46, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459764391), 
(47, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459764597), 
(48, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1459924578), 
(49, 'vi', 'shops', 'log_add_catalog', 'id 23', '', 1, 1459924878), 
(50, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/65_2_3.jpg', '', 1, 1459924959), 
(51, 'vi', 'shops', 'Add A Product', 'ID: 12', '', 1, 1459925047), 
(52, 'vi', 'shops', 'log_del_product', 'id 11,10,9,8,7,', '', 1, 1459925064), 
(53, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/68.jpg', '', 1, 1459925210), 
(54, 'vi', 'shops', 'Add A Product', 'ID: 13', '', 1, 1459925252), 
(55, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459925737), 
(56, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459925813), 
(57, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459925863), 
(58, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459925889), 
(59, 'vi', 'themes', 'Thêm block', 'Name : global block bxproduct center', '', 1, 1459925966), 
(60, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459925997), 
(61, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459926042), 
(62, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459926064), 
(63, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459926095), 
(64, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459926541), 
(65, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459926560), 
(66, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459926570), 
(67, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459926608), 
(68, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1459926646), 
(69, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459926985), 
(70, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459927006), 
(71, 'vi', 'shops', 'Edit A Product', 'ID: 13', '', 1, 1459927018), 
(72, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459927980), 
(73, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459928259), 
(74, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459929288), 
(75, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459929313), 
(76, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459929716), 
(77, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1459929832), 
(78, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459929870), 
(79, 'vi', 'themes', 'Thêm block', 'Name : global block product center', '', 1, 1459930085), 
(80, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459930101), 
(81, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459930179), 
(82, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459930210), 
(83, 'vi', 'themes', 'Thêm block', 'Name : global block relates product', '', 1, 1459930263), 
(84, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459930278), 
(85, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459930311), 
(86, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1459930341), 
(87, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459930374), 
(88, 'vi', 'themes', 'Sửa block', 'Name : Featured Cakes', '', 1, 1459930398), 
(89, 'vi', 'themes', 'Thêm block', 'Name : global block product center', '', 1, 1459931919), 
(90, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm hot', '', 1, 1459931932), 
(91, 'vi', 'shops', 'Edit A Product', 'ID: 13', '', 1, 1459932726), 
(92, 'vi', 'shops', 'Edit A Product', 'ID: 13', '', 1, 1459932768), 
(93, 'vi', 'shops', 'Edit A Product', 'ID: 12', '', 1, 1459932779), 
(94, 'vi', 'shops', 'Edit A Product', 'ID: 13', '', 1, 1459932981), 
(95, 'vi', 'shops', 'Edit A Product', 'ID: 12', '', 1, 1459932999), 
(96, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/44_1_2.jpg', '', 1, 1459933169), 
(97, 'vi', 'shops', 'Add A Product', 'ID: 14', '', 1, 1459933194), 
(98, 'vi', 'shops', 'Add A Product', 'ID: 15', '', 1, 1459933289), 
(99, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/42_3.jpg', '', 1, 1459933336), 
(100, 'vi', 'shops', 'Edit A Product', 'ID: 15', '', 1, 1459933343), 
(101, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/66_1_2.jpg', '', 1, 1459933472), 
(102, 'vi', 'shops', 'Add A Product', 'ID: 16', '', 1, 1459933480), 
(103, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/45_2.jpg', '', 1, 1459933585), 
(104, 'vi', 'shops', 'Add A Product', 'ID: 17', '', 1, 1459933613), 
(105, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/64_3.jpg', '', 1, 1459933692), 
(106, 'vi', 'shops', 'Add A Product', 'ID: 18', '', 1, 1459933714), 
(107, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/30_2.jpg', '', 1, 1459933868), 
(108, 'vi', 'shops', 'Add A Product', 'ID: 19', '', 1, 1459933919), 
(109, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/34_3.jpg', '', 1, 1459934016), 
(110, 'vi', 'shops', 'Add A Product', 'ID: 20', '', 1, 1459934043), 
(111, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_04/9_4.jpg', '', 1, 1459934160), 
(112, 'vi', 'shops', 'Add A Product', 'ID: 21', '', 1, 1459934193), 
(113, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1460099095), 
(114, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1460099102), 
(115, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1460099112), 
(116, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460099265), 
(117, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460100268), 
(118, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460101194), 
(119, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460102997), 
(120, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1460339772), 
(121, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1460339799), 
(122, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460339831), 
(123, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460341634), 
(124, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1460342035), 
(125, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1460342052), 
(126, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1460343519), 
(127, 'vi', 'themes', 'Kích hoạt theme: \"bakery\"', '', '', 1, 1460343520), 
(128, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460343524), 
(129, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460343826), 
(130, 'vi', 'upload', 'Upload file', 'uploads/siteterms/banner1.png', '', 1, 1460344557), 
(131, 'vi', 'upload', 'Upload file', 'uploads/siteterms/banner4.png', '', 1, 1460344757), 
(132, 'vi', 'upload', 'Upload file', 'uploads/siteterms/banner3.png', '', 1, 1460344768), 
(133, 'vi', 'upload', 'Upload file', 'uploads/siteterms/banner2.png', '', 1, 1460344785), 
(134, 'vi', 'upload', 'Upload file', 'uploads/siteterms/banner5.png', '', 1, 1460344849), 
(135, 'vi', 'banners', 'log_add_plan', 'planid 3', '', 1, 1460345049), 
(136, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1460345063), 
(137, 'vi', 'banners', 'log_add_banner', 'bannerid 4', '', 1, 1460345145), 
(138, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1460345158), 
(139, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1460345312), 
(140, 'vi', 'banners', 'log_add_banner', 'bannerid 5', '', 1, 1460345379), 
(141, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1460345403), 
(142, 'vi', 'banners', 'log_del_banner', 'bannerid 3', '', 1, 1460345438), 
(143, 'vi', 'banners', 'log_add_plan', 'planid 4', '', 1, 1460345510), 
(144, 'vi', 'banners', 'log_add_banner', 'bannerid 6', '', 1, 1460345537), 
(145, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1460345561), 
(146, 'vi', 'banners', 'log_add_plan', 'planid 5', '', 1, 1460345786), 
(147, 'vi', 'banners', 'log_add_banner', 'bannerid 7', '', 1, 1460345819), 
(148, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1460345836), 
(149, 'vi', 'banners', 'log_add_plan', 'planid 6', '', 1, 1460345899), 
(150, 'vi', 'banners', 'log_add_banner', 'bannerid 8', '', 1, 1460345922), 
(151, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1460345944), 
(152, 'vi', 'banners', 'log_edit_plan', 'planid 6', '', 1, 1460345971), 
(153, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1460346429), 
(154, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1460346464), 
(155, 'vi', 'banners', 'log_edit_plan', 'planid 4', '', 1, 1460346802), 
(156, 'vi', 'banners', 'log_edit_banner', 'bannerid 8', '', 1, 1460347341), 
(157, 'vi', 'banners', 'log_edit_banner', 'bannerid 7', '', 1, 1460347384), 
(158, 'vi', 'banners', 'log_edit_banner', 'bannerid 6', '', 1, 1460347392), 
(159, 'vi', 'banners', 'log_edit_banner', 'bannerid 5', '', 1, 1460347404), 
(160, 'vi', 'banners', 'log_edit_banner', 'bannerid 4', '', 1, 1460347417), 
(161, 'vi', 'banners', 'log_edit_banner', 'bannerid 8', '', 1, 1460347528), 
(162, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1460454442), 
(163, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1460454457), 
(164, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460454468), 
(165, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1460454471), 
(166, 'vi', 'banners', 'log_edit_plan', 'planid 1', '', 1, 1460456047), 
(167, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1460456132), 
(168, 'vi', 'banners', 'log_edit_plan', 'planid 5', '', 1, 1460472113), 
(169, 'vi', 'themes', 'Sửa block', 'Name : Các chuyên mục chính', '', 1, 1460480154), 
(170, 'vi', 'themes', 'Sửa block', 'Name : Why Choose Us', '', 1, 1460480180), 
(171, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1460529510), 
(172, 'vi', 'themes', 'Thêm block', 'Name : global treeview', '', 1, 1460530233), 
(173, 'vi', 'themes', 'Thêm block', 'Name : global social', '', 1, 1460530281), 
(174, 'vi', 'themes', 'Thêm block', 'Name : global module menu', '', 1, 1460530355), 
(175, 'vi', 'themes', 'Sửa block', 'Name : global treeview', '', 1, 1460530465), 
(176, 'vi', 'themes', 'Sửa block', 'Name : global treeview', '', 1, 1460530616), 
(177, 'vi', 'themes', 'Sửa block', 'Name : Contact Information', '', 1, 1460533007), 
(178, 'vi', 'themes', 'Sửa block', 'Name : Contact Information', '', 1, 1460533035), 
(179, 'vi', 'themes', 'Sửa block', 'Name : Social With Us', '', 1, 1460533629), 
(180, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1460703524), 
(181, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1461119632), 
(182, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1461119637), 
(183, 'vi', 'login', '[ngocphan12031995@gmail.com] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1461119644), 
(184, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1461119653), 
(185, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1461121601), 
(186, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1461121638), 
(187, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1461121746), 
(188, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1461121799), 
(189, 'vi', 'themes', 'Sửa block', 'Name : global image', '', 1, 1461121900), 
(190, 'vi', 'about', 'Add', ' ', '', 1, 1461122818), 
(191, 'vi', 'about', 'Edit', 'ID: 9', '', 1, 1461122904), 
(192, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1461124890), 
(193, 'vi', 'themes', 'Sửa block', 'Name : Contact Default', '', 1, 1461125127), 
(194, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1461126160), 
(195, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1461126175), 
(196, 'vi', 'login', '[ngocphan] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1461314382), 
(197, 'vi', 'modules', 'Thêm module ảo new2', '', '', 1, 1461314408), 
(198, 'vi', 'modules', 'Thiết lập module mới new2', '', '', 1, 1461314421), 
(199, 'vi', 'modules', 'Sửa module &ldquo;new2&rdquo;', '', '', 1, 1461314432);


-- ---------------------------------------


--
-- Table structure for table `nv4_notification`
--

DROP TABLE IF EXISTS `nv4_notification`;
CREATE TABLE `nv4_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3) NOT NULL,
  `module` varchar(50) NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_sessions`
--

INSERT INTO `nv4_sessions` VALUES
('dqko8fltu4aema5vk923k8d1l6', 0, 'guest', 1461656198);


-- ---------------------------------------


--
-- Table structure for table `nv4_setup`
--

DROP TABLE IF EXISTS `nv4_setup`;
CREATE TABLE `nv4_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'shops', 0, 1, 'shops', 'shops', '4.0.17 1371948600', 1459471345, 'VINADES (contact@vinades.vn)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'default', 0, 0, 'default', 'default', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.21 1436199600', 1459471000, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'new2', 0, 0, 'news', 'new2', '', 1461314408, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block`
--

DROP TABLE IF EXISTS `nv4_shops_block`;
CREATE TABLE `nv4_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_block`
--

INSERT INTO `nv4_shops_block` VALUES
(2, 15, 0), 
(2, 14, 0), 
(2, 13, 0), 
(1, 6, 2), 
(1, 5, 1), 
(2, 4, 4), 
(2, 3, 3), 
(2, 2, 2), 
(2, 1, 1), 
(2, 12, 0), 
(2, 16, 0), 
(2, 17, 0), 
(2, 18, 0), 
(2, 19, 0), 
(2, 20, 0), 
(2, 21, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block_cat`
--

DROP TABLE IF EXISTS `nv4_shops_block_cat`;
CREATE TABLE `nv4_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_block_cat`
--

INSERT INTO `nv4_shops_block_cat` VALUES
(1, 0, '', 1, 1433298294, 1433298294, 'Sản phẩm bán chạy', 'San-pham-ban-chay', '', ''), 
(2, 0, '', 2, 1433298325, 1433298325, 'Sản phẩm hot', 'San-pham-hot', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier`
--

DROP TABLE IF EXISTS `nv4_shops_carrier`;
CREATE TABLE `nv4_shops_carrier` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config`;
CREATE TABLE `nv4_shops_carrier_config` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_items`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_items`;
CREATE TABLE `nv4_shops_carrier_config_items` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `cid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` smallint(4) unsigned NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_location`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_location`;
CREATE TABLE `nv4_shops_carrier_config_location` (
  `cid` tinyint(3) unsigned NOT NULL,
  `iid` smallint(4) unsigned NOT NULL,
  `lid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_weight`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_weight`;
CREATE TABLE `nv4_shops_carrier_config_weight` (
  `iid` smallint(4) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  `weight_unit` varchar(20) NOT NULL,
  `carrier_price` float NOT NULL,
  `carrier_price_unit` char(3) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_catalogs`
--

DROP TABLE IF EXISTS `nv4_shops_catalogs`;
CREATE TABLE `nv4_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(4) NOT NULL DEFAULT '3',
  `typeprice` tinyint(4) NOT NULL DEFAULT '2',
  `form` varchar(50) NOT NULL DEFAULT '',
  `group_price` text NOT NULL,
  `viewdescriptionhtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `cat_allow_point` tinyint(1) NOT NULL DEFAULT '0',
  `cat_number_point` tinyint(4) NOT NULL DEFAULT '0',
  `cat_number_product` tinyint(4) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_title_custom` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_descriptionhtml` text NOT NULL,
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=24  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_catalogs`
--

INSERT INTO `nv4_shops_catalogs` VALUES
(2, 0, '', 1, 1, 0, 'viewcat_page_list', 4, '6,7,8,9', 1, 4, 7, 1, '', '', 0, '', 1432362728, 1432362803, '6', 0, 0, 0, 'Váy', 'Váy', 'Vay-nu', '', '', 'váy, vay'), 
(3, 0, '', 2, 6, 0, 'viewcat_page_list', 4, '13,14,15,16', 1, 4, 7, 1, '', '', 0, '', 1432362789, 1432362789, '6', 0, 0, 0, 'Giày dép', 'Giày dép', 'Giay-dep', '', '', 'giay, dep, giày, dép'), 
(4, 0, '', 3, 11, 0, 'viewcat_page_list', 3, '10,11,12', 1, 4, 7, 1, '', '', 0, '', 1432362835, 1432364806, '6', 0, 0, 0, 'Áo', 'Áo', 'Ao', '', '', 'áo, ao'), 
(5, 0, '', 4, 15, 0, 'viewcat_page_list', 5, '18,19,20,21,22', 1, 4, 7, 1, '', '', 0, '', 1432362887, 1432362887, '6', 0, 0, 0, 'Phụ kiện', 'Phụ kiện', 'Phu-kien', '', '', 'Phụ kiện, Phu kien, kiện, kien, phu kien'), 
(6, 2, '', 1, 2, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364675, 1432364675, '6', 0, 0, 0, 'váy dài', 'váy dài', 'vay-dai', '', '', 'váy dài, dài, vay dai'), 
(7, 2, '', 2, 3, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364695, 1432364695, '6', 0, 0, 0, 'váy ngắn', 'váy ngắn', 'vay-ngan', '', '', 'váy ngắn, vay ngan'), 
(8, 2, '', 3, 4, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364752, 1432364752, '6', 0, 0, 0, 'đầm maxi', 'đầm maxi', 'dam-maxi', '', '', 'đầm, maxi, Maxi, đầm maxi, Đầm maxi'), 
(9, 2, '', 4, 5, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364786, 1432364786, '6', 0, 0, 0, 'Váy chữ A', 'Váy chữ A', 'Vay-chu-A', '', '', 'Váy chữ A, váy chữ a'), 
(10, 4, '', 1, 12, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364825, 1432364863, '6', 0, 0, 0, 'Áo sơmi', 'Áo sơmi', 'Ao-somi', '', '', 'Áo sơmi,, sơmi. áo'), 
(11, 4, '', 2, 13, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364880, 1432364880, '6', 0, 0, 0, 'Áo phông', 'Áo phông', 'Ao-phong', '', '', ''), 
(12, 4, '', 3, 14, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364936, 1432364936, '6', 0, 0, 0, 'Áo dáng dài', 'Áo dáng dài', 'Ao-dang-dai', '', '', 'Áo dáng dài, áo'), 
(13, 3, '', 1, 7, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364976, 1432364976, '6', 0, 0, 0, 'Giày cao gót', 'Giày cao gót', 'Giay-cao-got', '', '', 'Giày cao gót, cao gót, cao got'), 
(14, 3, '', 2, 8, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365033, 1432365033, '6', 0, 0, 0, 'Giày sandal', 'Giày sandal', 'Giay-sandal', '', '', 'sandal, Sandal, giày, giày sandal'), 
(15, 3, '', 3, 9, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365081, 1432365081, '6', 0, 0, 0, 'Giày búp bê', 'Giày búp bê', 'Giay-bup-be', '', '', 'giày búp bê, Giày búp bê, giay bup be, Giay bup be, búp bê, bup be'), 
(16, 3, '', 4, 10, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365108, 1432365108, '6', 0, 0, 0, 'Giày vải', 'Giày vải', 'Giay-vai', '', '', 'vải, giày vải, giay vai'), 
(19, 5, '', 2, 17, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365211, 1432365211, '6', 0, 0, 0, 'Lắc tay', 'Lắc tay', 'Lac-tay', '', '', 'Lắc tay. lac tay, lắc'), 
(18, 5, '', 1, 16, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365185, 1432365185, '6', 0, 0, 0, 'Vòng cổ', 'Vòng cổ', 'Phu-kien-Vong-co', '', '', 'vòng cổ, Vòng cổ, vong co'), 
(20, 5, '', 3, 18, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365242, 1432365242, '6', 0, 0, 0, 'Thắt lưng', 'Thắt lưng', 'That-lung', '', '', 'Thắt lưng, that lung, thắt lưng'), 
(21, 5, '', 4, 19, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365281, 1432365281, '6', 0, 0, 0, 'Đồng hồ', 'Đồng hồ', 'Dong-ho', '', '', 'Đồng hồ, hồ, dong ho'), 
(22, 5, '', 5, 20, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365303, 1432365303, '6', 0, 0, 0, 'Ví nữ', 'Ví nữ', 'Vi-nu', '', '', 'ví nữ, ví'), 
(23, 0, '', 5, 21, 0, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1459924878, 1459924878, '6', 0, 0, 0, 'Featured Cakes', '', 'Featured-Cakes', '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons`
--

DROP TABLE IF EXISTS `nv4_shops_coupons`;
CREATE TABLE `nv4_shops_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(1) NOT NULL DEFAULT 'p',
  `discount` float NOT NULL DEFAULT '0',
  `total_amount` float NOT NULL DEFAULT '0',
  `date_start` int(11) unsigned NOT NULL DEFAULT '0',
  `date_end` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon_count` int(11) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_history`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_history`;
CREATE TABLE `nv4_shops_coupons_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_product`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_product`;
CREATE TABLE `nv4_shops_coupons_product` (
  `cid` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_discounts`
--

DROP TABLE IF EXISTS `nv4_shops_discounts`;
CREATE TABLE `nv4_shops_discounts` (
  `did` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `begin_time` int(11) unsigned NOT NULL DEFAULT '0',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `detail` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  KEY `begin_time` (`begin_time`,`end_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_field`
--

DROP TABLE IF EXISTS `nv4_shops_field`;
CREATE TABLE `nv4_shops_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `listtemplate` varchar(25) NOT NULL,
  `tab` varchar(255) NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `class` varchar(25) NOT NULL DEFAULT '',
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_files`
--

DROP TABLE IF EXISTS `nv4_shops_files`;
CREATE TABLE `nv4_shops_files` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `filesize` int(11) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(10) NOT NULL DEFAULT '',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `download_groups` varchar(255) NOT NULL DEFAULT '-1',
  `status` tinyint(1) unsigned DEFAULT '1',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_description` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_files_rows`
--

DROP TABLE IF EXISTS `nv4_shops_files_rows`;
CREATE TABLE `nv4_shops_files_rows` (
  `id_rows` int(11) unsigned NOT NULL,
  `id_files` mediumint(8) unsigned NOT NULL,
  `download_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id_files` (`id_files`,`id_rows`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group`
--

DROP TABLE IF EXISTS `nv4_shops_group`;
CREATE TABLE `nv4_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `indetail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `numpro` int(11) unsigned NOT NULL DEFAULT '0',
  `in_order` tinyint(2) NOT NULL DEFAULT '0',
  `is_require` tinyint(1) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=58  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_group`
--

INSERT INTO `nv4_shops_group` VALUES
(1, 0, '', 1, 1, 0, 'viewcat_page_list', 6, '6,7,8,9,10,11', 1, 0, 1432623061, 1432623061, 0, 1, 0, 'Thương hiệu', 'Thuong-hieu', '', ''), 
(2, 0, '', 2, 8, 0, 'viewcat_page_list', 12, '12,13,15,16,17,18,19,20,21,22,23,24', 1, 0, 1432623083, 1432623083, 0, 1, 0, 'Màu sắc', 'Mau-sac', '', ''), 
(3, 0, '', 3, 21, 0, 'viewcat_page_list', 15, '25,26,27,28,29,30,31,32,33,34,35,36,37,38,39', 1, 0, 1432623101, 1432623101, 0, 1, 0, 'Kích thước', 'Kich-thuoc', '', ''), 
(4, 0, '', 4, 37, 0, 'viewcat_page_list', 8, '40,41,42,43,44,45,46,47', 1, 0, 1432623118, 1432623118, 0, 1, 0, 'Chất liệu', 'Chat-lieu', '', ''), 
(5, 0, '', 5, 46, 0, 'viewcat_page_list', 10, '48,49,50,51,52,53,54,55,56,57', 1, 0, 1432623133, 1432623133, 0, 1, 0, 'Xuất xứ', 'Xuat-xu', '', ''), 
(6, 1, '', 1, 2, 1, 'viewcat_page_list', 0, '', 1, 0, 1432626862, 1432626862, 0, 1, 0, 'Việt Tiến', 'Viet-Tien', '', ''), 
(7, 1, '', 2, 3, 1, 'viewcat_page_list', 0, '', 1, 0, 1432626882, 1432626882, 0, 1, 0, 'ZARA', 'ZARA', '', ''), 
(8, 1, '', 3, 4, 1, 'viewcat_page_list', 0, '', 1, 0, 1432626899, 1432626899, 0, 1, 0, 'MATTANA', 'MATTANA', '', ''), 
(9, 1, '', 4, 5, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627013, 1432627013, 0, 1, 0, 'KELVIN', 'KELVIN', '', ''), 
(10, 1, '', 5, 6, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627027, 1432627027, 0, 1, 0, 'THÁI TUẤN', 'THAI-TUAN', '', ''), 
(11, 1, '', 6, 7, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627053, 1432627053, 0, 1, 0, 'VICTORIA SECRECT', 'VICTORIA-SECRECT', '', ''), 
(12, 2, '', 1, 9, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627064, 1432627064, 0, 1, 0, 'ĐỎ', 'DO', '', ''), 
(13, 2, '', 2, 10, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627070, 1432627070, 0, 1, 0, 'VÀNG', 'VANG', '', ''), 
(16, 2, '', 4, 12, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627102, 1432627102, 0, 1, 0, 'HỒNG PHẤN', 'HONG-PHAN', '', ''), 
(15, 2, '', 3, 11, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627095, 1432627095, 0, 1, 0, 'XANH NGỌC', 'XANH-NGOC', '', ''), 
(17, 2, '', 5, 13, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627107, 1432627107, 0, 1, 0, 'XANH RÊU', 'XANH-REU', '', ''), 
(18, 2, '', 6, 14, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627112, 1432627112, 0, 1, 0, 'TÍM', 'TIM', '', ''), 
(19, 2, '', 7, 15, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627123, 1432627123, 0, 1, 0, 'XÁM', 'XAM', '', ''), 
(20, 2, '', 8, 16, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627135, 1432627135, 0, 1, 0, 'XANH NƯỚC BIỂN', 'XANH-NUOC-BIEN', '', ''), 
(21, 2, '', 9, 17, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627148, 1432627148, 0, 1, 0, 'CAM', 'CAM', '', ''), 
(22, 2, '', 10, 18, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627153, 1432627153, 0, 1, 0, 'BẠC', 'BAC', '', ''), 
(23, 2, '', 11, 19, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627160, 1432627160, 0, 1, 0, 'MÀU DA', 'MAU-DA', '', ''), 
(24, 2, '', 12, 20, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627182, 1432627182, 0, 1, 0, 'ĐEN', 'DEN', '', ''), 
(25, 3, '', 1, 22, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627201, 1432627201, 0, 1, 0, 'F', 'F', '', ''), 
(26, 3, '', 2, 23, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627210, 1432627210, 0, 1, 0, 'L', 'L', '', ''), 
(27, 3, '', 3, 24, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627215, 1432627215, 0, 1, 0, 'M', 'M', '', ''), 
(28, 3, '', 4, 25, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627219, 1432627219, 0, 1, 0, 'S', 'S', '', ''), 
(29, 3, '', 5, 26, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627223, 1432627223, 0, 1, 0, 'XL', 'XL', '', ''), 
(30, 3, '', 6, 27, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627241, 1432627241, 0, 1, 0, 'XXL', 'XXL', '', ''), 
(31, 3, '', 7, 28, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627250, 1432627250, 0, 1, 0, 'XXXL', 'XXXL', '', ''), 
(32, 3, '', 8, 29, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627259, 1432627259, 0, 1, 0, '35', '35', '', ''), 
(33, 3, '', 9, 30, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627264, 1432627264, 0, 1, 0, '36', '36', '', ''), 
(34, 3, '', 10, 31, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627269, 1432627269, 0, 1, 0, '37', '37', '', ''), 
(35, 3, '', 11, 32, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627274, 1432627274, 0, 1, 0, '38', '38', '', ''), 
(36, 3, '', 12, 33, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627279, 1432627279, 0, 1, 0, '39', '39', '', ''), 
(37, 3, '', 13, 34, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627284, 1432627284, 0, 1, 0, '40', '40', '', ''), 
(38, 3, '', 14, 35, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627291, 1432627291, 0, 1, 0, '41', '41', '', ''), 
(39, 3, '', 15, 36, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627296, 1432627296, 0, 1, 0, '42', '42', '', ''), 
(40, 4, '', 1, 38, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627339, 1432627339, 0, 1, 0, 'COTTON', 'COTTON', '', ''), 
(41, 4, '', 2, 39, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627346, 1432627346, 0, 1, 0, 'DẠ', 'DA', '', ''), 
(42, 4, '', 3, 40, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627364, 1432627364, 0, 1, 0, 'JEANS', 'JEANS', '', ''), 
(43, 4, '', 4, 41, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627369, 1432627369, 0, 1, 0, 'BÒ', 'BO', '', ''), 
(44, 4, '', 5, 42, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627378, 1432627378, 0, 1, 0, 'LANH', 'LANH', '', ''), 
(45, 4, '', 6, 43, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627385, 1432627385, 0, 1, 0, 'TƠ TẰM', 'TO-TAM', '', ''), 
(46, 4, '', 7, 44, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627399, 1432627399, 0, 1, 0, 'THUN', 'THUN', '', ''), 
(47, 4, '', 8, 45, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627407, 1432627407, 0, 1, 0, 'LỤA', 'LUA', '', ''), 
(48, 5, '', 1, 47, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627418, 1432627418, 0, 1, 0, 'VIỆT NAM', 'VIET-NAM', '', ''), 
(49, 5, '', 2, 48, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627425, 1432627425, 0, 1, 0, 'HÀN QUỐC', 'HAN-QUOC', '', ''), 
(50, 5, '', 3, 49, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627519, 1432627519, 0, 1, 0, 'ĐỨC', 'DUC', '', ''), 
(51, 5, '', 4, 50, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627528, 1432627528, 0, 1, 0, 'NHẬT BẢN', 'NHAT-BAN', '', ''), 
(52, 5, '', 5, 51, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627541, 1432627541, 0, 1, 0, 'THÁI LAN', 'THAI-LAN', '', ''), 
(53, 5, '', 6, 52, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627553, 1432627553, 0, 1, 0, 'HONGKONG', 'HONGKONG', '', ''), 
(54, 5, '', 7, 53, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627565, 1432627565, 0, 1, 0, 'TRUNG QUỐC', 'TRUNG-QUOC', '', ''), 
(55, 5, '', 8, 54, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627573, 1432627573, 0, 1, 0, 'PHÁP', 'PHAP', '', ''), 
(56, 5, '', 9, 55, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627579, 1432627579, 0, 1, 0, 'ANH', 'ANH', '', ''), 
(57, 5, '', 10, 56, 1, 'viewcat_page_list', 0, '', 1, 0, 1432627617, 1432627617, 0, 1, 0, 'AUSTRALIA', 'AUSTRALIA', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_cateid`
--

DROP TABLE IF EXISTS `nv4_shops_group_cateid`;
CREATE TABLE `nv4_shops_group_cateid` (
  `groupid` mediumint(8) unsigned NOT NULL,
  `cateid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `groupid` (`groupid`,`cateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_group_cateid`
--

INSERT INTO `nv4_shops_group_cateid` VALUES
(1, 2), 
(1, 3), 
(1, 4), 
(1, 5), 
(2, 2), 
(2, 3), 
(2, 4), 
(2, 5), 
(3, 2), 
(3, 3), 
(3, 4), 
(3, 5), 
(4, 2), 
(4, 3), 
(4, 4), 
(4, 5), 
(5, 2), 
(5, 3), 
(5, 4), 
(5, 5);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_items`
--

DROP TABLE IF EXISTS `nv4_shops_group_items`;
CREATE TABLE `nv4_shops_group_items` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`,`group_id`),
  KEY `pro_id` (`pro_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_quantity`
--

DROP TABLE IF EXISTS `nv4_shops_group_quantity`;
CREATE TABLE `nv4_shops_group_quantity` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  UNIQUE KEY `pro_id` (`pro_id`,`listgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_info`
--

DROP TABLE IF EXISTS `nv4_shops_info`;
CREATE TABLE `nv4_shops_info` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `shopid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_location`
--

DROP TABLE IF EXISTS `nv4_shops_location`;
CREATE TABLE `nv4_shops_location` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsub` int(11) NOT NULL DEFAULT '0',
  `subid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_money_vi`
--

DROP TABLE IF EXISTS `nv4_shops_money_vi`;
CREATE TABLE `nv4_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10) NOT NULL,
  `number_format` varchar(5) NOT NULL DEFAULT ',||.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_money_vi`
--

INSERT INTO `nv4_shops_money_vi` VALUES
(840, 'USD', 'US Dollar', '21000', '0.01', ',||.'), 
(704, 'VND', 'Vietnam Dong', '1', '100', ',||.');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders`
--

DROP TABLE IF EXISTS `nv4_shops_orders`;
CREATE TABLE `nv4_shops_orders` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_address` varchar(255) NOT NULL,
  `order_note` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(11) unsigned NOT NULL DEFAULT '0',
  `who_is` int(2) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100) NOT NULL,
  `order_view` tinyint(2) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_id`
--

DROP TABLE IF EXISTS `nv4_shops_orders_id`;
CREATE TABLE `nv4_shops_orders_id` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `proid` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL,
  `price` int(11) NOT NULL,
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`order_id`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_id_group`
--

DROP TABLE IF EXISTS `nv4_shops_orders_id_group`;
CREATE TABLE `nv4_shops_orders_id_group` (
  `order_i` int(11) NOT NULL,
  `group_id` mediumint(8) NOT NULL,
  UNIQUE KEY `orderid` (`order_i`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_shipping`
--

DROP TABLE IF EXISTS `nv4_shops_orders_shipping`;
CREATE TABLE `nv4_shops_orders_shipping` (
  `id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` tinyint(11) unsigned NOT NULL,
  `ship_name` varchar(255) NOT NULL,
  `ship_phone` varchar(25) NOT NULL,
  `ship_location_id` mediumint(8) unsigned NOT NULL,
  `ship_address_extend` varchar(255) NOT NULL,
  `ship_shops_id` tinyint(3) unsigned NOT NULL,
  `ship_carrier_id` tinyint(3) unsigned NOT NULL,
  `weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20) NOT NULL DEFAULT '',
  `ship_price` float NOT NULL DEFAULT '0',
  `ship_price_unit` char(3) NOT NULL DEFAULT '',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_payment`
--

DROP TABLE IF EXISTS `nv4_shops_payment`;
CREATE TABLE `nv4_shops_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point`
--

DROP TABLE IF EXISTS `nv4_shops_point`;
CREATE TABLE `nv4_shops_point` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `point_total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point_history`
--

DROP TABLE IF EXISTS `nv4_shops_point_history`;
CREATE TABLE `nv4_shops_point_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point_queue`
--

DROP TABLE IF EXISTS `nv4_shops_point_queue`;
CREATE TABLE `nv4_shops_point_queue` (
  `order_id` int(11) NOT NULL,
  `point` mediumint(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_review`
--

DROP TABLE IF EXISTS `nv4_shops_review`;
CREATE TABLE `nv4_shops_review` (
  `review_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `rating` int(1) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_rows`
--

DROP TABLE IF EXISTS `nv4_shops_rows`;
CREATE TABLE `nv4_shops_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(255) NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` float NOT NULL DEFAULT '0',
  `price_config` text NOT NULL,
  `money_unit` char(3) NOT NULL,
  `product_unit` smallint(4) NOT NULL,
  `product_weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20) NOT NULL DEFAULT '',
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `homeimgalt` varchar(255) NOT NULL,
  `otherimage` text NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gift_from` int(11) unsigned NOT NULL DEFAULT '0',
  `gift_to` int(11) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_sell` mediumint(8) NOT NULL DEFAULT '0',
  `showprice` tinyint(2) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_gift_content` text NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  AUTO_INCREMENT=22  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_rows`
--

INSERT INTO `nv4_shops_rows` VALUES
(1, 6, 1, 1432363521, 1432365563, 1, 1432363521, 0, 2, 'V01', 19, '100000', '', 'VND', 1, '20', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, 'Váy Maxi sang trọng', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 11, 0, 0, 1, 1, 'Đầm Maxi sang trọng', 'Dam-Maxi-sang-trong', 'Đầm maxi thời trang', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(2, 6, 1, 1432365534, 1432365970, 1, 1432365534, 0, 2, 'V02', 50, '100000', '', 'VND', 1, '250', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'Đầm maxi họa tiết', 'Dam-maxi-hoa-tiet', 'đầm maxi sang trọng', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(3, 7, 1, 1432366714, 1432366740, 1, 1432366714, 0, 2, 'V03', 14, '50000', '', 'VND', 1, '250', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, 'Chân Váy Công Sở', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 4, 0, 0, 1, 1, 'Chân Váy Công Sở', 'Chan-Vay-Cong-So', 'chân váy công sở', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(4, 7, 1, 1432367089, 1432367089, 1, 1432367089, 0, 2, 'S000004', 17, '50000', '', 'VND', 1, '300', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, 'chân váy caro', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 4, 0, 0, 3, 1, 'Chân váy caro', 'Chan-vay-caro', 'chân váy caro', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(5, 10, 1, 1432367366, 1432367366, 1, 1432367366, 0, 2, 'S000005', 30, '0', '', 'VND', 1, '220', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, 'áo somi lụa đẹp', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Áo sơmi lụa', 'Ao-somi-lua', 'áo somi lụa đẹp', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(6, 10, 1, 1432367846, 1432370007, 1, 1432367846, 0, 2, 'S000006', 15, '0', '', 'VND', 1, '300', 'g', 0, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 8, 0, 0, 0, 1, 'Áo sơ mi voan phối tay ren', 'Ao-so-mi-voan-phoi-tay-ren', '<h1><span style=\"font-size:14px;\">Áo sơ mi voan</span></h1>', 'Sản phẩm thời trang<br  /> <div style=\"text-align:center\"><img alt=\"giay bup be ngoi sao nhap khau\" height=\"800\" src=\"/uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg\" width=\"800\" /></div> ', '', ''), 
(15, 23, 1, 1459933289, 1459933343, 1, 1459933289, 0, 2, 'S000015', 0, '34', '', 'USD', 1, '0', 'g', 0, '2016_04/42_3.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Lasin ponke catin', 'lasin-ponke-catin', 'Katen rinus pakin nacon mazen ean nec ma ...', 'Katen rinus pakin nacon mazen ean nec ma ...', '', ''), 
(16, 23, 1, 1459933480, 1459933480, 1, 1459933480, 0, 2, 'S000016', 0, '43', '', 'USD', 1, '0', 'g', 0, '2016_04/66_1_2.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Grouped Product', 'grouped-product', 'Niten ratun kamas rinus diam turpis accu ...', 'Niten ratun kamas rinus diam turpis accu ...', '', ''), 
(17, 23, 1, 1459933613, 1459933613, 1, 1459933613, 0, 2, 'S000017', 0, '43', '', 'USD', 1, '0', 'g', 0, '2016_04/45_2.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Zuna masin okin', 'zuna-masin-okin', 'Latin baki makon oken mazine xarin bakun ...', 'Latin baki makon oken mazine xarin bakun ...', '', ''), 
(18, 23, 1, 1459933714, 1459933714, 1, 1459933714, 0, 2, 'S000018', 0, '44', '', 'VND', 1, '0', 'g', 0, '2016_04/64_3.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Bako larin hakin', 'bako-larin-hakin', 'Katen gakin bazon risus urna sed id temp ...', 'Katen gakin bazon risus urna sed id temp ...', '', ''), 
(19, 23, 1, 1459933919, 1459933919, 1, 1459933919, 0, 2, 'S000019', 0, '45', '', 'USD', 1, '0', 'g', 0, '2016_04/30_2.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Xuti ponse rentis', 'xuti-ponse-rentis', 'Bakin tusit ate rinus pakin nacon karen ...', 'Bakin tusit ate rinus pakin nacon karen ...', '', ''), 
(20, 23, 1, 1459934043, 1459934043, 1, 1459934043, 0, 2, 'S000020', 0, '45', '', 'USD', 1, '0', 'g', 0, '2016_04/34_3.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'Xuti ponse rentis', 'xuti-ponse-rentis-20', 'Bakin tusit ate rinus pakin nacon karen ...', 'Bakin tusit ate rinus pakin nacon karen ...', '', ''), 
(21, 23, 1, 1459934193, 1459934193, 1, 1459934193, 0, 2, 'S000021', 0, '46', '', 'USD', 1, '0', 'g', 0, '2016_04/9_4.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Patin kati cetin', 'patin-kati-cetin', 'Zento iken tenson hakin caton koten tire ...', 'Zento iken tenson hakin caton koten tire ...', '', ''), 
(13, 23, 1, 1459925252, 1459932981, 1, 1459925252, 0, 2, 'S000013', 0, '32', '', 'USD', 1, '0', 'g', 0, '2016_04/68.jpg', 2, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Satin makon lasen rinus', 'satin-makon-lasen-rinus', 'Takin caton mazine rines zagin rinu sire ...', 'Enkin casen rinus ipsum risus urna sed id tempus mauris. At Pellentesque id quis malesuada Aenean id Curabitur auctor nulla wisi. Tortor senectus Aenean nec mauris tellus velit id mauris interdum risus. Feugiat auctor et eros Integer justo lorem sagittis tincidunt Aenean tristique. Magna nulla malesuada id et dapibus nonummy. Urna id in nibh sodales id nulla diam turpis accumsan Curabitur. Neque justo laoreet aliquam molestie tempus Proin Integer Vestibulum lacinia semper. Interdum augue Nunc egestas magna gravida wisi Nullam id In tellus. Porta sed nec feugiat Vivamus tincidunt vitae vel quis accumsan faucibus. Tincidunt nisl vel lacinia felis et Quisque leo non malesuada', '', ''), 
(12, 23, 1, 1459925047, 1459932999, 1, 1459925047, 0, 2, 'S000012', 0, '20', '', 'USD', 1, '0', 'g', 0, '2016_04/65_2_3.jpg', 2, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Downloadable Product', 'downloadable-product', '<p>Enkin casen rinus ipsum risus urna sed i ...</p>', '<p>Quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis Haten justo justo. Fusce at bibendum massa. Nam mollis consectetur augue eu consequat. Nunc vel nulla est. Nulla dictum lorem nunc, sit amet congue sem sollicitudin vitae. Aliquam auctor ante non ipsum tristique, id cursus nulla vulputate.</p><p>Curabitur bibendum, justo egestas scelerisque pretium, nulla arcu eleifend urna, at suscipit purus lorem at orci. Pellentesque mollis lectus ac aliquam imperdiet. Mauris a iaculis libero, ut mollis ipsum. Vivamus porta enim sed tempor pellentesque. Donec ornare lacus sit amet pretium accumsan. Nunc vel nulla est. Nulla dictum lorem nunc, sit amet congue sem vitae. Aliquam auctor ante non ipsum.</p><p>Takin caton mazine rines zagin rinu siren ipsum risus urna sed id tempus mauris. At Pellentesque id quis malesuada Aenean id Curabitur auctor nulla wisi. Tortor senectus Aenean nec mauris tellus velit id mauris interdum risus. Feugiat auctor et eros Integer justo lorem sagittis tincidun.&nbsp;Fusce convallis ante elementum purus tincidunt, eget gravida tortor accumsan. Mauris sit amet est odio donec ornare lacus sit amet pretium accumsan. Keto jansen mazin merca ugen rinu maton iken tenson hakin caton koten tiren perka makan entos makos tukis miken taren rinus pato resin satos paake iken mazin patin ozin terdum risus.</p><p>At pellentesque id quis malesuada Aenean id Curabitur auctor nulla wisi. Tortor senectus Aenean nec mauris tellus velit id mauris interdum risus. Feugiat auctor et eros Integer justo lorem sagittis tincidun.&nbsp;Fusce convallis ante elementum purus tincidunt, eget gravida tortor accumsan. Mauris sit amet est odio donec ornare lacus sit amet pretium accumsan.</p>', '', ''), 
(14, 23, 1, 1459933194, 1459933194, 1, 1459933194, 0, 2, 'S000014', 0, '32', '', 'USD', 1, '0', 'g', 0, '2016_04/44_1_2.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Quates ganki osin', 'quates-ganki-osin', 'Danis baki makon oken mazine xarin bakun ...', 'Danis baki makon oken mazine xarin bakun ...', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_shops`
--

DROP TABLE IF EXISTS `nv4_shops_shops`;
CREATE TABLE `nv4_shops_shops` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `location` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_shops_carrier`
--

DROP TABLE IF EXISTS `nv4_shops_shops_carrier`;
CREATE TABLE `nv4_shops_shops_carrier` (
  `shops_id` tinyint(3) unsigned NOT NULL,
  `carrier_id` tinyint(3) unsigned NOT NULL,
  `config_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `shops_id` (`shops_id`,`carrier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tabs`
--

DROP TABLE IF EXISTS `nv4_shops_tabs`;
CREATE TABLE `nv4_shops_tabs` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(50) NOT NULL DEFAULT '',
  `content` varchar(50) NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_tabs`
--

INSERT INTO `nv4_shops_tabs` VALUES
(1, '', 'content_detail', 1, 1, 'Chi tiết sản phẩm'), 
(2, '', 'content_comments', 2, 1, 'Bình luận'), 
(3, '', 'content_rate', 3, 1, 'Đánh giá');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags_id_vi`
--

DROP TABLE IF EXISTS `nv4_shops_tags_id_vi`;
CREATE TABLE `nv4_shops_tags_id_vi` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_tags_id_vi`
--

INSERT INTO `nv4_shops_tags_id_vi` VALUES
(1, 1, 'thời trang'), 
(1, 2, 'sang trọng'), 
(1, 3, 'phù hợp'), 
(1, 4, 'đi chơi'), 
(6, 5, 'áo sơ mi'), 
(10, 6, 'mũi nhọn'), 
(11, 7, 'búp bê');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags_vi`
--

DROP TABLE IF EXISTS `nv4_shops_tags_vi`;
CREATE TABLE `nv4_shops_tags_vi` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numpro` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_tags_vi`
--

INSERT INTO `nv4_shops_tags_vi` VALUES
(1, 1, 'thời-trang', '', '', 'thời trang'), 
(2, 1, 'sang-trọng', '', '', 'sang trọng'), 
(3, 1, 'phù-hợp', '', '', 'phù hợp'), 
(4, 1, 'đi-chơi', '', '', 'đi chơi'), 
(5, 1, 'áo-sơ-mi', '', '', 'áo sơ mi'), 
(6, 1, 'mũi-nhọn', '', '', 'mũi nhọn'), 
(7, 1, 'búp-bê', '', '', 'búp bê');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_template`
--

DROP TABLE IF EXISTS `nv4_shops_template`;
CREATE TABLE `nv4_shops_template` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_transaction`
--

DROP TABLE IF EXISTS `nv4_shops_transaction`;
CREATE TABLE `nv4_shops_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(100) NOT NULL DEFAULT '0',
  `payment_id` varchar(22) NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` float NOT NULL DEFAULT '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_units`
--

DROP TABLE IF EXISTS `nv4_shops_units`;
CREATE TABLE `nv4_shops_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_units`
--

INSERT INTO `nv4_shops_units` VALUES
(1, 'cái', ''), 
(2, 'đôi', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse`;
CREATE TABLE `nv4_shops_warehouse` (
  `wid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_warehouse`
--

INSERT INTO `nv4_shops_warehouse` VALUES
(1, 'Nhập kho ngày 23/05/2015', '', 1, 1432364016), 
(2, 'Nhập kho ngày 23/05/2015', '', 1, 1432365552), 
(3, 'Nhập kho ngày 23/05/2015', '', 1, 1432366753), 
(4, 'Nhập kho ngày 23/05/2015', '', 1, 1432367106), 
(5, 'Nhập kho ngày 23/05/2015', '', 1, 1432367387), 
(6, 'Nhập kho ngày 23/05/2015', '', 1, 1432367857), 
(7, 'Nhập kho ngày 23/05/2015', '', 1, 1432369139), 
(8, 'Nhập kho ngày 26/05/2015', '', 1, 1432608794), 
(9, 'Nhập kho ngày 26/05/2015', '', 1, 1432608805), 
(10, 'Nhập kho ngày 26/05/2015', '', 1, 1432608819), 
(11, 'Nhập kho ngày 26/05/2015', '', 1, 1432608835);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse_logs`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse_logs`;
CREATE TABLE `nv4_shops_warehouse_logs` (
  `logid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) unsigned NOT NULL DEFAULT '0',
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `wid` (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_warehouse_logs`
--

INSERT INTO `nv4_shops_warehouse_logs` VALUES
(1, 1, 1, 20, '150000', 'VND'), 
(2, 2, 2, 50, '250000', 'VND'), 
(3, 3, 3, 15, '70000', 'VND'), 
(4, 4, 4, 20, '120000', 'VND'), 
(5, 5, 5, 30, '120000', 'VND'), 
(6, 6, 6, 15, '180000', 'VND'), 
(7, 7, 7, 50, '50000', 'VND'), 
(8, 8, 11, 20, '80', 'VND'), 
(9, 9, 10, 10, '180', 'VND'), 
(10, 10, 9, 10, '150', 'VND'), 
(11, 11, 8, 15, '50000', 'VND');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse_logs_group`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse_logs_group`;
CREATE TABLE `nv4_shops_warehouse_logs_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `logid` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logid` (`logid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_weight_vi`
--

DROP TABLE IF EXISTS `nv4_shops_weight_vi`;
CREATE TABLE `nv4_shops_weight_vi` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_weight_vi`
--

INSERT INTO `nv4_shops_weight_vi` VALUES
(1, 'g', 'Gram', '1', '0.1'), 
(2, 'kg', 'Kilogam', '1000', '0.1');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_wishlist`
--

DROP TABLE IF EXISTS `nv4_shops_wishlist`;
CREATE TABLE `nv4_shops_wishlist` (
  `wid` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listid` text,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(250) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=21  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads', 1459471331, 0, 0, 0, 0), 
(2, 'uploads/about', 1459924760, 0, 0, 0, 0), 
(3, 'uploads/banners', 1459924760, 0, 0, 0, 0), 
(4, 'uploads/contact', 1460344522, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 1459924761, 0, 0, 0, 0), 
(6, 'uploads/menu', 1459497664, 0, 0, 0, 0), 
(7, 'uploads/news', 1459924753, 0, 0, 0, 0), 
(8, 'uploads/news/source', 1459932659, 0, 0, 0, 0), 
(9, 'uploads/news/temp_pic', 1459932661, 0, 0, 0, 0), 
(10, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(11, 'uploads/page', 1459924752, 0, 0, 0, 0), 
(12, 'uploads/siteterms', 1459924750, 0, 0, 0, 0), 
(13, 'uploads/users', 1459924749, 0, 0, 0, 0), 
(14, 'uploads/shops/temp_pic', 0, 0, 0, 0, 0), 
(15, 'uploads/shops/2016_04', 1459924943, 3, 204, 136, 90), 
(16, 'uploads/shops/files', 0, 0, 0, 0, 0), 
(17, 'uploads/new2', 0, 0, 0, 0, 0), 
(18, 'uploads/new2/source', 0, 0, 0, 0, 0), 
(19, 'uploads/new2/temp_pic', 0, 0, 0, 0, 0), 
(20, 'uploads/new2/topics', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(245) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_file`
--

INSERT INTO `nv4_upload_file` VALUES
('logo.png', 'png', 'image', 15093, 'assets/logo.png', 80, 76, '197|188', 1, 1459474200, 1, 'logo.png', 'logo'), 
('flag-default.png', 'png', 'image', 539, 'assets/menu/flag-default.png', 14, 11, '14|11', 1, 1459497673, 6, 'flag-default.png', 'flag default'), 
('sl1.png', 'png', 'image', 339526, 'assets/sl1.png', 80, 42, '575|303', 1, 1459698639, 1, 'sl1.png', 'sl1'), 
('3_2.jpg', 'jpg', 'image', 49118, 'assets/3_2.jpg', 80, 42, '575|303', 1, 1459698640, 1, '3_2.jpg', '3 2'), 
('5_5.jpg', 'jpg', 'image', 48975, 'assets/5_5.jpg', 80, 42, '575|303', 1, 1459698640, 1, '5_5.jpg', '5 5'), 
('6.jpg', 'jpg', 'image', 13205, 'assets/6.jpg', 80, 42, '575|303', 1, 1459698640, 1, '6.jpg', '6'), 
('chuc-mung-...jpg', 'jpg', 'image', 130708, 'assets/news/chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 80, 62, '461|360', 1, 1445774038, 7, 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'chuc mung nukeviet thong tu 20 bo tttt'), 
('hoptac.jpg', 'jpg', 'image', 12871, 'assets/news/hoptac.jpg', 80, 66, '382|314', 1, 1445774038, 7, 'hoptac.jpg', 'hoptac'), 
('nangly.jpg', 'jpg', 'image', 34802, 'assets/news/nangly.jpg', 80, 53, '500|332', 1, 1445774038, 7, 'nangly.jpg', 'nangly'), 
('nukeviet-job.jpg', 'jpg', 'image', 23576, 'assets/news/nukeviet-job.jpg', 80, 60, '400|300', 1, 1445774038, 7, 'nukeviet-job.jpg', 'nukeviet job'), 
('nukeviet-n...jpg', 'jpg', 'image', 18611, 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 1, 1445774038, 7, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'), 
('bongoaigiao.jpg', 'jpg', 'image', 15104, 'assets/banners/bongoaigiao.jpg', 80, 27, '160|54', 1, 1445774038, 3, 'bongoaigiao.jpg', 'bongoaigiao'), 
('vinades.jpg', 'jpg', 'image', 26778, 'assets/banners/vinades.jpg', 34, 80, '190|454', 1, 1445774038, 3, 'vinades.jpg', 'vinades'), 
('vndads___05.jpg', 'jpg', 'image', 47783, 'assets/banners/vndads___05.jpg', 80, 10, '510|65', 1, 1445774038, 3, 'vndads___05.jpg', 'vndads 05'), 
('webnhanh_vn.png', 'png', 'image', 8047, 'assets/banners/webnhanh_vn.png', 80, 10, '510|65', 1, 1445774038, 3, 'webnhanh_vn.png', 'webnhanh vn'), 
('nukeviet-edu.jpg', 'jpg', 'image', 10338, 'assets/freecontent/nukeviet-edu.jpg', 80, 30, '220|80', 1, 1445774038, 5, 'nukeviet-edu.jpg', 'nukeviet edu'), 
('nukeviet-p...jpg', 'jpg', 'image', 11396, 'assets/freecontent/nukeviet-portal.jpg', 80, 30, '220|80', 1, 1445774038, 5, 'nukeviet-portal.jpg', 'nukeviet portal'), 
('nukeviet-t...jpg', 'jpg', 'image', 15627, 'assets/freecontent/nukeviet-toasoan.jpg', 80, 30, '220|80', 1, 1445774038, 5, 'nukeviet-toasoan.jpg', 'nukeviet toasoan'), 
('nukeviet.jpg', 'jpg', 'image', 9423, 'assets/freecontent/nukeviet.jpg', 80, 30, '220|80', 1, 1445774038, 5, 'nukeviet.jpg', 'nukeviet'), 
('65_2_3.jpg', 'jpg', 'image', 9231, 'assets/shops/2016_04/65_2_3.jpg', 80, 54, '204|136', 1, 1459924961, 15, '65_2_3.jpg', '65 2 3'), 
('68.jpg', 'jpg', 'image', 10198, 'assets/shops/2016_04/68.jpg', 80, 54, '204|136', 1, 1459925212, 15, '68.jpg', '68'), 
('44_1_2.jpg', 'jpg', 'image', 15478, 'assets/shops/2016_04/44_1_2.jpg', 80, 53, '204|136', 1, 1459933172, 15, '44_1_2.jpg', '44 1 2'), 
('42_3.jpg', 'jpg', 'image', 9570, 'assets/shops/2016_04/42_3.jpg', 80, 53, '204|136', 1, 1459933337, 15, '42_3.jpg', '42 3'), 
('66_1_2.jpg', 'jpg', 'image', 9855, 'assets/shops/2016_04/66_1_2.jpg', 80, 53, '204|136', 1, 1459933473, 15, '66_1_2.jpg', '66 1 2'), 
('45_2.jpg', 'jpg', 'image', 10188, 'assets/shops/2016_04/45_2.jpg', 80, 53, '204|136', 1, 1459933586, 15, '45_2.jpg', '45 2'), 
('64_3.jpg', 'jpg', 'image', 9530, 'assets/shops/2016_04/64_3.jpg', 80, 53, '204|136', 1, 1459933693, 15, '64_3.jpg', '64 3'), 
('30_2.jpg', 'jpg', 'image', 8146, 'assets/shops/2016_04/30_2.jpg', 80, 53, '204|136', 1, 1459933871, 15, '30_2.jpg', '30 2'), 
('34_3.jpg', 'jpg', 'image', 9295, 'assets/shops/2016_04/34_3.jpg', 80, 53, '204|136', 1, 1459934018, 15, '34_3.jpg', '34 3'), 
('9_4.jpg', 'jpg', 'image', 4214, 'assets/shops/2016_04/9_4.jpg', 80, 53, '204|136', 1, 1459934164, 15, '9_4.jpg', '9 4'), 
('banner1.png', 'png', 'image', 92915, 'assets/siteterms/banner1.png', 57, 80, '180|254', 1, 1460344564, 12, 'banner1.png', 'banner1'), 
('banner4.png', 'png', 'image', 82096, 'assets/siteterms/banner4.png', 80, 44, '270|147', 1, 1460344761, 12, 'banner4.png', 'banner4'), 
('banner3.png', 'png', 'image', 132071, 'assets/siteterms/banner3.png', 80, 75, '270|254', 1, 1460344773, 12, 'banner3.png', 'banner3'), 
('banner2.png', 'png', 'image', 193054, 'assets/siteterms/banner2.png', 80, 52, '390|254', 1, 1460344792, 12, 'banner2.png', 'banner2'), 
('banner5.png', 'png', 'image', 188128, 'assets/siteterms/banner5.png', 80, 20, '590|147', 1, 1460344859, 12, 'banner5.png', 'banner5');


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40) DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 'ngocphan', '48a8f79c8073d73711833fe20e5f132f', '{SSHA}AbqE+oSaavUkzUPysD9/2Qr9Lgh4NW1x', 'ngocphan1201995@gmail.com', 'ngocphan', '', '', '', 0, '', 1459471158, 'thich', 'thich', '', 0, 1, '', 1, '', 1459471158, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|11223344|654321|696969|1234567|12345678|87654321|123456789|23456789|1234567890|66666666|68686868|66668888|88888888|99999999|999999999|1234569|12345679|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman|hoilamgi|khongbiet|khongco|khongcopass', 1459471000), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1459471000), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1459471000), 
('avatar_width', '80', 1459471000), 
('avatar_height', '80', 1459471000), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  `openid_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about`
--

DROP TABLE IF EXISTS `nv4_vi_about`;
CREATE TABLE `nv4_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about`
--

INSERT INTO `nv4_vi_about` VALUES
(1, 'Giới thiệu về NukeViet', 'gioi-thieu-ve-nukeviet', '', '', 'NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian.', '<p>Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p>  <p>Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p>  <p style=\"text-align: justify;\">Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p>  <p style=\"text-align: justify;\">NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p>  <p style=\"text-align: justify;\">NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p>  <p style=\"text-align: justify;\">Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p>  <div style=\"text-align: center;\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"315\" src=\"https://www.youtube.com/embed/dG66RocXSeY?rel=0&amp;showinfo=0\" width=\"420\"></iframe><br  /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br  /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', '', 0, '4', '', 0, 2, 1, 1459471000, 1459471000, 1), 
(2, 'Giới thiệu về NukeViet CMS', 'gioi-thieu-ve-nukeviet-cms', '', '', 'Giới thiệu về NukeViet CMS', 'Giới thiệu về NukeViet CMS', '', 0, '4', '', 0, 3, 1, 1459471000, 1459471000, 1), 
(3, 'Logo và tên gọi NukeViet', 'logo-va-ten-goi-nukeviet', '', '', 'Logo và tên gọi NukeViet', 'Logo và tên gọi NukeViet', '', 0, '4', '', 0, 4, 1, 1459471000, 1459471000, 1), 
(4, 'Giấy phép sử dụng NukeViet', 'giay-phep-su-dung-nukeviet', '', '', 'Giấy phép công cộng GNU (tiếng Anh: GNU General Public License, viết tắt GNU GPL hay chỉ GPL) là giấy phép phần mềm tự do được sử dụng để phân phối mã nguồn mở NukeViet.', '<p><strong>Bản dịch tiếng Việt của Giấy phép Công cộng GNU</strong></p>  <p>Người dịch&nbsp;<a href=\"mailto:dangtuan@vietkey.net\">Đặng Minh Tuấn &lt;dangtuan@vietkey.net&gt;</a></p>  <p>Đây là bản dịch tiếng Việt không chính thức của Giấy phép Công cộng GNU. Bản dịch này không phải do Tổ chức Phần mềm Tự do ấn hành, và nó không quy định về mặt pháp lý các điều khoản cho các phần mềm sử dụng giấy phép GNU GPL -- chỉ có bản tiếng Anh gốc của GNU GPL mới có tính pháp lý. Tuy nhiên, chúng tôi hy vọng rằng bản dịch này sẽ giúp cho những người nói tiếng Việt hiểu rõ hơn về GNU GPL.</p>  <p>This is an unofficial translation of the GNU General Public License into Vietnamese. It was not published by the Free Software Foundation, and does not legally state the distribution terms for software that uses the GNU GPL--only the original English text of the GNU GPL does that. However, we hope that this translation will help Vietnamese speakers understand the GNU GPL better.</p>  <hr  /> <h3>GIẤY PHÉP CÔNG CỘNG GNU (GPL)</h3> Giấy phép công cộng GNU<br  /> Phiên bản 2, tháng 6/1991<br  /> Copyright (C) 1989, 1991 Free Software Foundation, Inc. &nbsp;<br  /> 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA <p>Mọi người đều được phép sao chép và lưu hành bản sao nguyên bản nhưng không được phép thay đổi nội dung của giấy phép này.<br  /> <br  /> <strong>Lời nói đầu</strong><br  /> <br  /> Giấy phép sử dụng của hầu hết các phần mềm đều được đưa ra nhằm hạn chế bạn tự do chia sẻ và thay đổi nó. Ngược lại, Giấy phép Công cộng của GNU có mục đích đảm bảo cho bạn có thể tự do chia sẻ và thay đổi phần mềm tự do - tức là đảm bảo rằng phần mềm đó là tự do đối với mọi người sử dụng. Giấy phép Công cộng này áp dụng cho hầu hết các phần mềm của Tổ chức Phần mềm Tự do và cho tất cả các chương trình khác mà tác giả cho phép sử dụng. (Đối với một số phần mềm khác của Tổ chức Phần Mềm Tự do, áp dụng Giấy phép Công cộng Hạn chế của GNU thay cho giấy phép công cộng). Bạn cũng có thể áp dụng nó cho các chương trình của mình.<br  /> <br  /> Khi nói đến phần mềm tự do, chúng ta nói đến sự tự do sử dụng chứ không quan tâm về giá cả. Giấy phép Công cộng của chúng tôi được thiết kế để đảm bảo rằng bạn hoàn toàn tự do cung cấp các bản sao của phần mềm tự do (cũng như kinh doanh dịch vụ này nếu bạn muốn), rằng bạn có thể nhận được mã nguồn nếu bạn có yêu cầu, rằng bạn có thể thay đổi phần mềm hoặc sử dụng các thành phần của phần mềm đó cho những chương trình tự do mới; và rằng bạn biết chắc là bạn có thể làm được những điều này.<br  /> <br  /> Để bảo vệ bản quyền của bạn, chúng tôi cần đưa ra những hạn chế để ngăn chặn những ai chối bỏ quyền của bạn, hoặc yêu cầu bạn chối bỏ quyền của mình. Những hạn chế này cũng có nghĩa là những trách nhiệm nhất định của bạn khi cung cấp các bản sao phần mềm hoặc khi chỉnh sửa phần mềm đó.<br  /> <br  /> Ví dụ, nếu bạn cung cấp các bản sao của một chương trình, dù miễn phí hay không, bạn phải cho người nhận tất cả các quyền mà bạn có. Bạn cũng phải đảm bảo rằng họ cũng nhận được hoặc tiếp cận được mã nguồn. Và bạn phải thông báo những điều khoản này cho họ để họ biết rõ về quyền của mình.<br  /> <br  /> Chúng tôi bảo vệ quyền của bạn với hai bước: (1) bảo vệ bản quyền phần mềm, và (2) cung cấp giấy phép này để bạn có thể sao chép, lưu hành và/hoặc chỉnh sửa phần mềm một cách hợp pháp.<br  /> <br  /> Ngoài ra, để bảo vệ các tác giả cũng như để bảo vệ chính mình, chúng tôi muốn chắc chắn rằng tất cả mọi người đều hiểu rõ rằng không hề có bảo hành đối với phần mềm tự do này. Nếu phần mềm được chỉnh sửa thay đổi bởi một người khác và sau đó lưu hành, thì chúng tôi muốn những người sử dụng biết rằng phiên bản họ đang có không phải là bản gốc, do đó tất cả những trục trặc do những người khác gây ra hoàn toàn không ảnh hưởng tới uy tín của tác giả ban đầu.<br  /> <br  /> Cuối cùng, bất kỳ một chương trình tự do nào cũng đều thường xuyên có nguy cơ bị đe doạ về giấy phép bản quyền. Chúng tôi muốn tránh nguy cơ khi những người cung cấp lại một chương trình tự do có thể có được giấy phép bản quyền cho bản thân họ, từ đó trở thành độc quyền đối với chương trình đó. Để ngăn ngừa trường hợp này, chúng tôi đã nêu rõ rằng mỗi giấy phép bản quyền hoặc phải được cấp cho tất cả mọi người sử dụng một cách tự do hoặc hoàn toàn không cấp phép.<br  /> <br  /> Dưới đây là những điều khoản và điều kiện rõ ràng đối với việc sao chép, lưu hành và chỉnh sửa.<br  /> <br  /> <strong>Những điều khoản và điều kiện đối với việc sao chép, lưu hành và chỉnh sửa</strong><br  /> <br  /> <strong>0.</strong>&nbsp;Giấy phép này áp dụng cho bất kỳ một chương trình hay sản phẩm nào mà người giữ bản quyền công bố rằng nó có thể được cung cấp trong khuôn khổ những điều khoản của Giấy phép Công cộng này. Từ “Chương trình” dưới đây có nghĩa là tất cả các chương trình hay sản phẩm như vậy, và “sản phẩm dựa trên Chương trình” có nghĩa là Chương trình hoặc bất kỳ một sản phẩm nào bắt nguồn từ chương trình đó tuân theo luật bản quyền, nghĩa là một sản phẩm dựa trên Chương trình hoặc một phần của nó, đúng nguyên bản hoặc có một số chỉnh sửa và/hoặc được dịch ra một ngôn ngữ khác. (Dưới đây, việc dịch cũng được hiểu trong khái niệm “chỉnh sửa”). Mỗi người được cấp phép được gọi là “bạn”.<br  /> <br  /> Trong Giấy phép này không đề cập tới các hoạt động khác ngoài việc sao chép, lưu hành và chỉnh sửa; chúng nằm ngoài phạm vi của giấy phép này. Hành động chạy chương trình không bị hạn chế, và những kết quả từ việc chạy chương trình chỉ được đề cập tới nếu nội dung của nó tạo thành một sản phẩm dựa trên chương trình (độc lập với việc chạy chương trình). Điều này đúng hay không là phụ thuộc vào Chương trình.<br  /> <br  /> <strong>1.</strong>&nbsp;Bạn có thể sao chép và lưu hành những phiên bản nguyên bản của mã nguồn Chương trình đúng như khi bạn nhận được, qua bất kỳ phương tiện phân phối nào, với điều kiện trên mỗi bản sao bạn đều kèm theo một ghi chú bản quyền rõ ràng và từ chối bảo hành; giữ nguyên tất cả các ghi chú về Giấy phép và về việc không có bất kỳ một sự bảo hành nào; và cùng với Chương trình bạn cung cấp cho người sử dụng một bản sao của Giấy phép này.<br  /> <br  /> Bạn có thể tính phí cho việc chuyển giao bản sao, và tuỳ theo quyết định của mình bạn có thể cung cấp bảo hành để đổi lại với chi phí mà bạn đã tính.<br  /> <br  /> <strong>2.</strong>&nbsp;Bạn có thể chỉnh sửa bản sao của bạn hoặc các bản sao của Chương trình hoặc của bất kỳ phần nào của nó, từ đó hình thành một sản phẩm dựa trên Chương trình, và sao chép cũng như lưu hành sản phẩm đó hoặc những chỉnh sửa đó theo điều khoản trong Mục 1 ở trên, với điều kiện bạn đáp ứng được những điều kiện dưới đây:<br  /> •&nbsp;&nbsp; &nbsp;a) Bạn phải có ghi chú rõ ràng trong những tập tin đã chỉnh sửa là bạn đã chỉnh sửa nó, và ngày tháng của bất kỳ một thay đổi nào.<br  /> •&nbsp;&nbsp; &nbsp;b) Bạn phải cấp phép miễn phí cho tất cả các bên thứ ba đối với các sản phẩm bạn cung cấp hoặc phát hành, bao gồm Chương trình nguyên bản, từng phần của nó hay các sản phẩm dựa trên Chương trình hay dựa trên từng phần của Chương trình, theo những điều khoản của Giấy phép này.<br  /> •&nbsp;&nbsp; &nbsp;c) Nếu chương trình đã chỉnh sửa thường đọc lệnh tương tác trong khi chạy, bạn phải thực hiện sao cho khi bắt đầu chạy để sử dụng tương tác theo cách thông thường nhất phải có một thông báo bao gồm bản quyền và thông báo về việc không có bảo hành (hoặc thông báo bạn là người cung cấp bảo hành), và rằng người sử dụng có thể cung cấp lại Chương trình theo những điều kiện này, và thông báo để người sử dụng có thể xem bản sao của Giấy phép này. (Ngoại lệ: nếu bản thân Chương trình là tương tác nhưng không có một thông báo nào như trên, thì sản phẩm của bạn dựa trên Chương trình đó cũng không bắt buộc phải có thông báo như vậy).<br  /> <br  /> Những yêu cầu trên áp dụng cho toàn bộ các sản phẩm chỉnh sửa. Nếu có những phần của sản phẩm rõ ràng không bắt nguồn từ Chương trình, và có thể được xem là độc lập và riêng biệt, thì Giấy phép này và các điều khoản của nó sẽ không áp dụng cho những phần đó khi bạn cung cấp chúng như những sản phẩm riêng biệt. Nhưng khi bạn cung cấp những phần đó như những phần nhỏ trong cả một sản phẩm dựa trên Chương trình, thì việc cung cấp này phải tuân theo những điều khoản của Giấy phép này, cho phép những người được cấp phép có quyền đối với toàn bộ sản phẩm, cũng như đối với từng phần trong đó, bất kể ai đã viết nó.<br  /> <br  /> Như vậy, điều khoản này không nhằm mục đích xác nhận quyền hoặc tranh giành quyền của bạn đối với những sản phẩm hoàn toàn do bạn viết; mà mục đích của nó là nhằm thi hành quyền kiểm soát đối với việc cung cấp những sản phẩm bắt nguồn hoặc tổng hợp dựa trên Chương trình.<br  /> <br  /> Ngoài ra, việc kết hợp thuần tuý Chương trình (hoặc một sản phẩm dựa trên Chương trình) với một sản phẩm không dựa trên Chương trình với mục đích lưu trữ hoặc quảng bá không đưa sản phẩm đó vào trong phạm vi áp dụng của Giấy phép này.<br  /> <br  /> <strong>3.</strong>&nbsp;Bạn có thể sao chép và cung cấp Chương trình (hoặc một sản phẩm dựa trên Chương trình, nêu trong Mục 2) dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được trong khuôn khổ các điều khoản nêu trong Mục 1 và 2 ở trên, nếu như bạn:<br  /> •&nbsp;&nbsp; &nbsp;a) Kèm theo đó một bản mã nguồn dạng đầy đủ có thể biên dịch được theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc,<br  /> •&nbsp;&nbsp; &nbsp;b) Kèm theo đó một đề nghị có hạn trong ít nhất 3 năm, theo đó cung cấp cho bất kỳ một bên thứ ba nào một bản sao đầy đủ của mã nguồn tương ứng, và phải được cung cấp với giá chi phí không cao hơn giá chi phí vật lý của việc cung cấp theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc<br  /> •&nbsp;&nbsp; &nbsp;c) Kèm theo đó thông tin bạn đã nhận được để đề nghị cung cấp mã nguồn tương ứng. (Phương án này chỉ được phép đối với việc cung cấp phi thương mại và chỉ với điều kiện nếu bạn nhận được Chương trình dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được cùng với lời đề nghị như vậy, theo phần b trong điều khoản nêu trên).<br  /> <br  /> Mã nguồn của một sản phẩm là một dạng ưu tiên của sản phẩm dành cho việc chỉnh sửa nó. Với một sản phẩm có thể thi hành, mã nguồn hoàn chỉnh có nghĩa là tất cả các mã nguồn cho các môđun trong sản phẩm đó, cộng với tất cả các tệp tin định nghĩa giao diện đi kèm với nó, cộng với các hướng dẫn dùng để kiểm soát việc biên dịch và cài đặt các tệp thi hành. Tuy nhiên, một ngoại lệ đặc biệt là mã nguồn không cần chứa bất kỳ một thứ gì mà bình thường được cung cấp (từ nguồn khác hoặc hình thức nhị phân) cùng với những thành phần chính (chương trình biên dịch, nhân, và những phần tương tự) của hệ điều hành mà các chương trình chạy trong đó, trừ khi bản thân thành phần đó lại đi kèm với một tệp thi hành.<br  /> <br  /> Nếu việc cung cấp lưu hành mã đã biên dịch hoặc tập tin thi hành được thực hiện qua việc cho phép tiếp cận và sao chép từ một địa điểm được chỉ định, thì việc cho phép tiếp cận tương đương tới việc sao chép mã nguồn từ cùng địa điểm cũng được tính như việc cung cấp mã nguồn, mặc dù thậm chí các bên thứ ba không bị buộc phải sao chép mã nguồn cùng với mã đã biên dịch.<br  /> <br  /> <strong>4.</strong>&nbsp;Bạn không được phép sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình trừ phi phải tuân thủ một cách chính xác các điều khoản trong Giấy phép. Bất kỳ ý định sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình theo cách khác đều làm mất hiệu lực và tự động huỷ bỏ quyền của bạn trong khuôn khổ Giấy phép này. Tuy nhiên, các bên đã nhận được bản sao hoặc quyền từ bạn với Giấy phép này sẽ không bị huỷ bỏ giấy phép nếu các bên đó vẫn tuân thủ đầy đủ các điều khoản của giấy phép.<br  /> <br  /> <strong>5.</strong>&nbsp;Bạn không bắt buộc phải chấp nhận Giấy phép này khi bạn chưa ký vào đó. Tuy nhiên, không có gì khác đảm bảo cho bạn được phép chỉnh sửa hoặc cung cấp Chương trình hoặc các sản phẩm bắt nguồn từ Chương trình. Những hành động này bị luật pháp nghiêm cấm nếu bạn không chấp nhận Giấy phép này. Do vậy, bằng việc chỉnh sửa hoặc cung cấp Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), bạn đã thể hiện sự chấp thuận đối với Giấy phép này, cùng với tất cả các điều khoản và điều kiện đối với việc sao chép, cung cấp hoặc chỉnh sửa Chương trình hoặc các sản phẩm dựa trên nó.<br  /> <br  /> <strong>6.</strong> Mỗi khi bạn cung cấp lại Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), người nhận sẽ tự động nhận được giấy phép từ người cấp phép đầu tiên cho phép sao chép, cung cấp và chỉnh sửa Chương trình theo các điều khoản và điều kiện này. Bạn không thể áp đặt bất cứ hạn chế nào khác đối với việc thực hiện quyền của người nhận đã được cấp phép từ thời điểm đó. Bạn cũng không phải chịu trách nhiệm bắt buộc các bên thứ ba tuân thủ theo Giấy phép này.<br  /> <br  /> <strong>7.</strong>&nbsp;Nếu như, theo quyết định của toà án hoặc với những bằng chứng về việc vi phạm bản quyền hoặc vì bất kỳ lý do nào khác (không giới hạn trong các vấn đề về bản quyền), mà bạn phải tuân theo các điều kiện (nêu ra trong lệnh của toà án, biên bản thoả thuận hoặc ở nơi khác) trái với các điều kiện của Giấy phép này, thì chúng cũng không thể miễn cho bạn khỏi những điều kiện của Giấy phép này. Nếu bạn không thể đồng thời thực hiện các nghĩa vụ của mình trong khuôn khổ Giấy phép này và các nghĩa vụ thích đáng khác, thì hậu quả là bạn hoàn toàn không được cung cấp Chương trình. Ví dụ, nếu trong giấy phép bản quyền không cho phép những người nhận được bản sao trực tiếp hoặc gián tiếp qua bạn có thể cung cấp lại Chương trình thì trong trường hợp này cách duy nhất bạn có thể thoả mãn cả hai điều kiện là hoàn toàn không cung cấp Chương trình.<br  /> <br  /> Nếu bất kỳ một phần nào trong điều khoản này không có hiệu lực hoặc không thể thi hành trong một hoàn cảnh cụ thể, thì sẽ cân đối áp dụng các điều khoản, và toàn bộ điều khoản sẽ được áp dụng trong những hoàn cảnh khác.<br  /> <br  /> Mục đích của điều khoản này không nhằm buộc bạn phải vi phạm bất kỳ một bản quyền nào hoặc các quyền sở hữu khác hoặc tranh luận về giá trị hiệu lực của bất kỳ quyền hạn nào như vậy; mục đích duy nhất của điều khoản này là nhằm bảo vệ sự toàn vẹn của hệ thống cung cấp phần mềm tự do đang được thực hiện với giấy phép công cộng. Nhiều người đã đóng góp rất nhiều vào sự đa dạng của các phần mềm tự do được cung cấp thông qua hệ thống này với sự tin tưởng rằng hệ thống được sử dụng một cách thống nhất; tác giả/người cung cấp có quyền quyết định rằng họ có mong muốn cung cấp phần mềm thông qua hệ thống nào khác hay không, và người được cấp phép không thể có ảnh hưởng tới sự lựa chọn này.<br  /> <br  /> Điều khoản này nhằm làm rõ những hệ quả của các phần còn lại của Giấy phép này.<br  /> <br  /> <strong>8.</strong>&nbsp;Nếu việc cung cấp và/hoặc sử dụng Chương trình bị cấm ở một số nước nhất định bởi quy định về bản quyền, người giữ bản quyền gốc đã đưa Chương trình vào dưới Giấy phép này có thể bổ sung một điều khoản hạn chế việc cung cấp ở những nước đó, nghĩa là việc cung cấp chỉ được phép ở các nước không bị liệt kê trong danh sách hạn chế. Trong trường hợp này, Giấy phép đưa vào những hạn chế được ghi trong nội dung của nó.<br  /> <br  /> <strong>9.&nbsp;</strong>Tổ chức Phần mềm Tự do có thể theo thời gian công bố những phiên bản chỉnh sửa và/hoặc phiên bản mới của Giấy phép Công cộng. Những phiên bản đó sẽ đồng nhất với tinh thần của phiên bản hiện này, nhưng có thể khác ở một số chi tiết nhằm giải quyết những vấn đề hay những lo ngại mới.<br  /> <br  /> Mỗi phiên bản sẽ có một mã số phiên bản riêng. Nếu Chương trình và &quot;bất kỳ một phiên bản nào sau đó&quot; có áp dụng một phiên bản Giấy phép cụ thể, bạn có quyền lựa chọn tuân theo những điều khoản và điều kiện của phiên bản giấy phép đó hoặc của bất kỳ một phiên bản nào sau đó do Tổ chức Phần mềm Tự do công bố. Nếu Chương trình không nêu cụ thể mã số phiên bản giấy phép, bạn có thể lựa chọn bất kỳ một phiên bản nào đã từng được công bố bởi Tổ chức Phần mềm Tự do.<br  /> <br  /> <strong>10.</strong>&nbsp;Nếu bạn muốn kết hợp các phần của Chương trình vào các chương trình tự do khác mà điều kiện cung cấp khác với chương trình này, hãy viết cho tác giả để được phép. Đối với các phần mềm được cấp bản quyền bởi Tổ chức Phầm mềm Tự do, hãy đề xuất với tổ chức này; đôi khi chúng tôi cũng có những ngoại lệ. Quyết định của chúng tôi sẽ dựa trên hai mục tiêu là bảo hộ tình trạng tự do của tất cả các sản phẩm bắt nguồn từ phần mềm tự do của chúng tôi, và thúc đẩy việc chia sẻ và tái sử dụng phần mềm nói chung.<br  /> <br  /> <strong>KHÔNG BẢO HÀNH</strong><br  /> DO CHƯƠNG TRÌNH ĐƯỢC CẤP PHÉP MIỄN PHÍ NÊN KHÔNG CÓ MỘT CHẾ ĐỘ BẢO HÀNH NÀO TRONG MỨC ĐỘ CHO PHÉP CỦA LUẬT PHÁP. TRỪ KHI ĐƯỢC CÔNG BỐ KHÁC ĐI BẰNG VĂN BẢN, NHỮNG NGƯỜI GIỮ BẢN QUYỀN VÀ/HOẶC CÁC BÊN CUNG CẤP CHƯƠNG TRÌNH NGUYÊN BẢN SẼ KHÔNG BẢO HÀNH DƯỚI BẤT KỲ HÌNH THỨC NÀO, BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG CÁC HÌNH THỨC BẢO HÀNH ĐỐI VỚI TÍNH THƯƠNG MẠI CŨNG NHƯ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. BẠN LÀ NGƯỜI CHỊU TOÀN BỘ RỦI RO VỀ CHẤT LƯỢNG CŨNG NHƯ VIỆC VẬN HÀNH CHƯƠNG TRÌNH. TRONG TRƯỜNG HỢP CHƯƠNG TRÌNH CÓ KHIẾM KHUYẾT, BẠN PHẢI CHỊU TOÀN BỘ CHI PHÍ CHO NHỮNG DỊCH VỤ SỬA CHỮA CẦN THIẾT.<br  /> <br  /> TRONG TẤT CẢ CÁC TRƯỜNG HỢP TRỪ KHI CÓ YÊU CẦU CỦA LUẬT PHÁP HOẶC CÓ THOẢ THUẬN BẰNG VĂN BẢN, NHỮNG NGƯỜI CÓ BẢN QUYỀN HOẶC BẤT KỲ MỘT BÊN NÀO CHỈNH SỬA VÀ/HOẶC CUNG CẤP LẠI CHƯƠNG TRÌNH TRONG CÁC ĐIỀU KIỆN NHƯ ĐÃ NÊU TRÊN ĐỀU KHÔNG CÓ TRÁCH NHIỆM VỚI BẠN VỀ CÁC LỖI HỎNG HÓC, BAO GỒM CÁC LỖI CHUNG HAY ĐẶC BIỆT, NGẪU NHIÊN HAY TẤT YẾU NẢY SINH DO VIỆC SỬ DỤNG HOẶC KHÔNG SỬ DỤNG ĐƯỢC CHƯƠNG TRÌNH (BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG VIỆC MẤT DỮ LIỆU, DỮ LIỆU THIẾU CHÍNH XÁC HOẶC CHƯƠNG TRÌNH KHÔNG VẬN HÀNH ĐƯỢC VỚI CÁC CHƯƠNG TRÌNH KHÁC), THẬM CHÍ CẢ KHI NGƯỜI CÓ BẢN QUYỀN VÀ CÁC BÊN KHÁC ĐÃ ĐƯỢC THÔNG BÁO VỀ KHẢ NĂNG XẢY RA NHỮNG THIỆT HẠI ĐÓ.<br  /> <br  /> <strong>KẾT THÚC CÁC ĐIỀU KIỆN VÀ ĐIỀU KHOẢN.</strong></p>  <p><strong>Áp dụng những điều khoản trên như thế nào đối với chương trình của bạn</strong><br  /> <br  /> Nếu bạn xây dựng một chương trình mới, và bạn muốn cung cấp một cách tối đa cho công chúng sử dụng, thì biện pháp tốt nhất để đạt được điều này là phát triển chương trình đó thành phần mềm tự do để ai cũng có thể cung cấp lại và thay đổi theo những điều khoản như trên.<br  /> <br  /> Để làm được việc này, hãy đính kèm những thông báo như sau cùng với chương trình của mình. An toàn nhất là đính kèm chúng trong phần đầu của tập tin mã nguồn để thông báo một cách hiệu quả nhất về việc không có bảo hành; và mỗi tệp tin đều phải có ít nhất một dòng về “bản quyền” và trỏ đến toàn bộ thông báo.</p>  <blockquote> <p>&nbsp; &nbsp; &nbsp; &nbsp; <strong>Một dòng đề tên chương trình và nội dung của nó.<br  /> &nbsp; &nbsp; &nbsp; &nbsp; Bản quyền (C) năm,&nbsp; tên tác giả.</strong><br  /> <br  /> Chương trình này là phần mềm tự do, bạn có thể cung cấp lại và/hoặc chỉnh sửa nó theo những điều khoản của Giấy phép Công cộng của GNU do Tổ chức Phần mềm Tự do công bố; phiên bản 2 của Giấy phép, hoặc bất kỳ một phiên bản sau đó (tuỳ sự lựa chọn của bạn).<br  /> <br  /> Chương trình này được cung cấp với hy vọng nó sẽ hữu ích, tuy nhiên KHÔNG CÓ BẤT KỲ MỘT BẢO HÀNH NÀO; thậm chí kể cả bảo hành về KHẢ NĂNG THƯƠNG MẠI hoặc TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. Xin xem Giấy phép Công cộng của GNU để biết thêm chi tiết.<br  /> <br  /> Bạn phải nhận được một bản sao của Giấy phép Công cộng của GNU kèm theo chương trình này; nếu bạn chưa nhận được, xin gửi thư về Tổ chức Phần mềm Tự do, 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA.<br  /> <br  /> Xin hãy bổ sung thông tin về địa chỉ liên lạc của bạn (thư điện tử và bưu điện).</p> </blockquote>  <p>Nếu chương trình chạy tương tác, hãy đưa một thông báo ngắn khi bắt đầu chạy chương trình như sau:</p>  <blockquote> <p>Gnomovision phiên bản 69, Copyright (C) năm, tên tác giả.<br  /> <br  /> Gnomovision HOÀN TOÀN KHÔNG CÓ BẢO HÀNH; để xem chi tiết hãy gõ `show w&#039;.&nbsp; Đây là một phần mềm miễn phí, bạn có thể cung cấp lại với những điều kiện nhất định, gõ ‘show c’ để xem chi tiết.<br  /> Giả thiết lệnh `show w&#039; và `show c&#039; cho xem những phần tương ứng trong Giấy phép Công cộng. Tất nhiên những lệnh mà bạn dùng có thể khác với ‘show w&#039; và `show c&#039;; những lệnh này có thể là nhấn chuột hoặc lệnh trong thanh công cụ - tuỳ theo chương trình của bạn.</p> </blockquote>  <p>Bạn cũng cần phải lấy chữ ký của người phụ trách (nếu bạn là người lập trình) hoặc của trường học (nếu có) xác nhận từ chối bản quyền đối với chương trình. Sau đây là ví dụ:</p>  <blockquote> <p>Yoyodyne, Inc., tại đây từ chối tất cả các quyền lợi bản quyền đối với chương trình `Gnomovision&#039; viết bởi James Hacker.<br  /> <br  /> chữ ký của Ty Coon, 1 April 1989<br  /> Ty Coon, Phó Tổng Giám đốc.</p> </blockquote>  <p>Giấy phép Công cộng này không cho phép đưa chương trình của bạn vào trong các chương trình độc quyền. Nếu chương trình của bạn là một thư viện thủ tục phụ, bạn có thể thấy nó hữu ích hơn nếu cho thư viện liên kết với các ứng dụng độc quyền. Nếu đây là việc bạn muốn làm, hãy sử dụng Giấy phép Công cộng Hạn chế của GNU thay cho Giấy phép này.</p>  <hr  /> <p><strong>Bản gốc của giấy phép bằng tiếng Anh có tại các địa chỉ sau:</strong></p>  <ol> 	<li>GNU General Public License, version 1, February 1989:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt</a></li> 	<li>GNU General Public License, version 2, June 1991:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-2.0.html\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-2.0.html</a></li> 	<li>GNU General Public License, version 3, 29 June 2007:&nbsp;<a href=\"http://www.gnu.org/licenses/gpl-3.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/gpl-3.0.txt</a></li> </ol>  <p><strong>Tài liệu tham khảo:</strong></p>  <ol> 	<li>Bản dịch tiếng Việt của Giấy phép Công cộng GNU tại OpenOffice.org:&nbsp;<br  /> 	<a href=\"http://vi.openoffice.org/gplv.html\" target=\"_blank\">http://vi.openoffice.org/gplv.html</a></li> 	<li>GPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/GPL\" target=\"_blank\">http://vi.wikisource.org/wiki/GPL</a></li> </ol>  <p><strong>Xem thêm:</strong></p>  <ol> 	<li>LGPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/LGPL\" target=\"_blank\">http://vi.wikisource.org/wiki/LGPL</a></li> 	<li>Giấy phép Công cộng GNU - WikiPedia:&nbsp;<br  /> 	<a href=\"http://vi.wikipedia.org/wiki/Gi%E1%BA%A5y_ph%C3%A9p_C%C3%B4ng_c%E1%BB%99ng_GNU\" target=\"_blank\">http://vi.wikipedia.org/wiki/Giấy_phép_Công_cộng_GNU</a></li> 	<li>Thảo luận giấy phép GNU GPL - HVA:<br  /> 	&nbsp;<a href=\"http://www.hvaonline.net/hvaonline/posts/list/7120.hva\" target=\"_blank\">http://www.hvaonline.net/hvaonline/posts/list/7120.hva</a></li> 	<li>Thảo luận tại diễn đàn:&nbsp;<a href=\"http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591\" target=\"_blank\">http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591</a></li> </ol>', 'giấy phép,công cộng,tiếng anh,gnu general,public license,gnu gpl,phần mềm,là tự,sử dụng,mã nguồn,bản dịch,tiếng việt,của gnu,đây là,này không,do tổ,chức tự,hành và,các điều,cho các,có bản,tuy nhiên,chúng tôi,cho những,phiên bản,mọi người,được phép,sao chép,lưu hành,bản sao,nguyên bản,nhưng không,và thay,nội dung,của này,hạn chế,tự do,chia sẻ,nukeviet,portal,mysql,php,cms,mã nguồn mở,thiết kế website', 0, '4', '', 0, 5, 1, 1459471000, 1459471000, 1), 
(5, 'Những tính năng của NukeViet CMS 4.0', 'nhung-tinh-nang-cua-nukeviet-cms-4-0', '', '', 'Những tính năng của NukeViet CMS 4.0', 'Những tính năng của NukeViet CMS 4.0', '', 0, '4', '', 0, 6, 1, 1459471000, 1459471000, 1), 
(6, 'Các yêu cầu cài đặt', 'cac-yeu-cau-cai-dat', '', '', 'Các yêu cầu cài đặt', 'Các yêu cầu cài đặt', '', 0, '4', '', 0, 7, 1, 1459471000, 1459471000, 1), 
(7, 'Giới thiệu về Công ty cổ phần phát triển nguồn mở Việt Nam', 'gioi-thieu-ve-cong-ty-co-phan-phat-trien-nguon-mo-viet-nam', '', '', 'Giới thiệu về Công ty cổ phần phát triển nguồn mở Việt Nam', '<p style=\"text-align: justify;\"><strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br  /> <br  /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br  /> <br  /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.</p>  <div style=\"text-align: center;\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"315\" src=\"https://www.youtube.com/embed/ZOhu2bLE-eA?rel=0&amp;showinfo=0\" width=\"420\"></iframe><br  /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br  /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div>  <p style=\"text-align: justify;\"><br  /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br  /> <br  /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p>  <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p>  <p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br  /> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br  /> Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a><br  /> Trụ sở: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /> - Tel: +84-4-85872007<br  /> - Fax: +84-4-35500914<br  /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'giới thiệu,công ty,cổ phần,phát triển', 0, '4', '', 0, 8, 1, 1459471000, 1459471000, 1), 
(8, 'Ủng hộ, hỗ trợ và tham gia phát triển NukeViet', 'ung-ho-ho-tro-va-tham-gia-phat-trien-nukeviet', '', '', 'Nếu bạn yêu thích NukeViet, bạn có thể ủng hộ và hỗ trợ NukeViet bằng nhiều cách', '<h2>1. Ủng hộ bằng tiền mặt vào Quỹ tài trợ NukeViet</h2> Qua tài khoản Paypal:  <p style=\"text-align:center\"><a href=\"https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=5LUSNE2SV5RR2\" target=\"_blank\"><img alt=\"\" src=\"https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif\" /></a></p> Chuyển khoản ngân hàng trực tiếp:  <ul> 	<li>Người đứng tên tài khoản:&nbsp;NGUYEN THE HUNG</li> 	<li>Số tài khoản:&nbsp;0031000792053</li> 	<li>Loại tài khoản: VND (Việt Nam Đồng)</li> 	<li>Ngân hàng Vietcombank chi nhánh Hải Phòng.</li> 	<li>Website:&nbsp;<a href=\"http://www.vietcombank.com.vn/\">http://www.vietcombank.com.vn</a></li> </ul>  <div class=\"alert alert-info\">Lưu ý: Đây là tài khoản hợp lệ duy nhất mà NukeViet.VN sử dụng cho&nbsp;Quỹ tài trợ NukeViet.</div> Thảo luận tại đây:&nbsp;<a href=\"http://forum.nukeviet.vn/viewtopic.php?f=3&amp;t=3592\" target=\"_blank\">http://forum.nukeviet.vn/viewtopic.php?f=3&amp;t=3592</a>  <h2>2. Ủng hộ bằng cách sử dụng và phổ biến NukeViet đến nhiều người hơn</h2> Cách đơn giản nhất để ủng hộ NukeViet phát triển là sử dụng NukeViet và giúp NukeViet phổ biến đến nhiều người hơn (ví dụ như giữ lại dòng chữ &quot;Powered by&nbsp;<a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a>&quot; hoặc &quot;Sử dụng&nbsp;<a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a>&quot; trên website của bạn, viết bài giới thiệu NukeViet đến mọi người).<br  /> Nếu bạn có thời gian, bạn có thể tham gia&nbsp;<a href=\"http://forum.nukeviet.vn/\" target=\"_blank\">diễn đàn NukeViet</a>&nbsp;thường xuyên và giúp đỡ những người mới sử dụng NukeViet.  <h2>3. Ủng hộ bằng cách tham gia phát triển NukeViet</h2>  <h3>3.1. Phát triển module, giao diện cho NukeViet</h3> Nếu bạn biết code, hãy tham gia viết module, block, theme cho NukeViet và đưa lên&nbsp;<a href=\"http://nukeviet.vn/vi/store/\" target=\"_blank\">NukeViet Store</a>&nbsp;để cung cấp cho cộng đồng. Bạn cũng có thể tham gia đội ngũ phát triển NukeViet.  <h3>3.2. Tham gia phát triển nhân hệ thống</h3> Toàn bộ code nhân hệ thống NukeViet đã được đưa lên GitHub.com (truy cập tắt:&nbsp;<a href=\"http://code.nukeviet.vn/\" target=\"_blank\">http://code.nukeviet.vn</a>), dù bạn là ai, cá nhân hay doanh nghiệp chỉ cần có một tài khoản tại GitHub và học cách sử dụng&nbsp;<a href=\"#git\">git&nbsp;(1)</a>&nbsp;là bạn có thể tham gia phát triển code NukeViet. Tìm hiểu thêm về việc tham gia phát triển code nhân hệ thống NukeViet tại đây:&nbsp;<a href=\"http://wiki.nukeviet.vn/programming:github_rule\" target=\"_blank\">http://wiki.nukeviet.vn/programming:github_rule</a>  <h3>3.3. Tham gia dịch thuật</h3> Nếu bạn biết ngoại ngữ, hãy đăng ký tham gia đội ngũ dịch thuật tình nguyện tại&nbsp;<a href=\"http://translate.nukeviet.vn/\" target=\"_blank\">NukeViet Stranslate System</a>&nbsp;để dịch thuật NukeViet sang các ngôn ngữ khác, quảng bá NukeViet ra với thế giới.  <h3>3.4. Tham gia viết tài liệu hướng dẫn sử dụng</h3> Nếu bạn không biết code, không biết ngoại ngữ, bạn vẫn có thể tham gia đóng góp cho NukeViet bằng cách biên soạn tài liệu hướng dẫn người dùng NukeViet tại thư viện tài liệu mở của NukeViet ở địa chỉ&nbsp;<a href=\"http://wiki.nukeviet.vn/\" target=\"_blank\">http://wiki.nukeviet.vn</a>  <hr  /> <a id=\"git\" name=\"git\">(1)</a>: Tìm hiểu về git:&nbsp;<a href=\"http://wiki.nukeviet.vn/programming:vcs:git\" target=\"_blank\">http://wiki.nukeviet.vn/programming:vcs:git</a>', 'ủng hộ,hỗ trợ,tham gia,phát triển', 0, '4', '', 0, 9, 1, 1459471000, 1459471000, 1), 
(9, 'About magento demo store', 'ABOUT-MAGENTO-DEMO-STORE', '', '', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede.</p>  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta.</p>  <p><strong>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit.</strong></p>  <p>Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper. Phasellus id massa. Pellentesque nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc augue. Aenean sed justo non leo vehicula laoreet. Praesent ipsum libero, auctor ac, tempus nec, tempor nec, justo.</p>  <p>Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus. Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi. Vestibulum sapien dolor, aliquet nec, porta ac, malesuada a, libero. Praesent feugiat purus eget est. Nulla facilisi. Vestibulum tincidunt sapien eu velit. Mauris purus. Maecenas eget mauris eu orci accumsan feugiat. Pellentesque eget velit. Nunc tincidunt.</p>  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi luctus. Duis lobortis. Nulla nec velit. Mauris pulvinar erat non massa. Suspendisse tortor turpis, porta nec, tempus vitae, iaculis semper, pede. Cras vel libero id lectus rhoncus porta. Suspendisse convallis felis ac enim. Vivamus tortor nisl, lobortis in, faucibus et, tempus at, dui. Nunc risus. Proin scelerisque augue. Nam ullamcorper</p>  <p><strong>Maecenas ullamcorper, odio vel tempus egestas, dui orci faucibus orci, sit amet aliquet lectus dolor et quam. Pellentesque consequat luctus purus.</strong></p>  <p>Nunc et risus. Etiam a nibh. Phasellus dignissim metus eget nisi.</p> &nbsp;  <p>To all of you, from all of us at Magento Demo Store - Thank you and Happy eCommerce!</p>  <p><strong>John Doe</strong><br  /> Some important guy</p>', '', 1, '4', '', 0, 1, 1, 1461122818, 1461122904, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about_config`
--

DROP TABLE IF EXISTS `nv4_vi_about_config`;
CREATE TABLE `nv4_vi_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about_config`
--

INSERT INTO `nv4_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_groups`;
CREATE TABLE `nv4_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10) DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=70  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_groups`
--

INSERT INTO `nv4_vi_blocks_groups` VALUES
(1, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:9:{s:6:\"numrow\";i:5;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:12:\"length_title\";i:400;s:15:\"length_hometext\";i:0;s:5:\"width\";i:500;s:6:\"height\";i:0;s:7:\"nocatid\";a:0:{}}'), 
(2, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(5, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(6, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'border', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''), 
(7, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 2, ''), 
(8, 'default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:39:\"/index.php?language=vi&amp;nv=siteterms\";}'), 
(9, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(10, 'default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 1, 'a:3:{s:5:\"level\";s:1:\"M\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(11, 'default', 'statistics', 'global.counter_button.php', 'Online button', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 2, ''), 
(12, 'default', 'users', 'global.user_button.php', 'Đăng nhập thành viên', '', 'no_title', '[PERSONALAREA]', 0, '1', 1, '6', 1, 1, ''), 
(13, 'default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.9845159999999992805896908976137638092041015625;s:20:\"company_mapcenterlng\";d:105.7954749999999961573848850093781948089599609375;s:14:\"company_maplat\";d:20.9845159999999992805896908976137638092041015625;s:14:\"company_maplng\";d:105.7954750000000103682396002113819122314453125;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(14, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(15, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', 1, '6', 1, 1, ''), 
(16, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(17, 'default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:8:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";}}'), 
(18, 'default', 'freecontent', 'global.free_content.php', 'Sản phẩm', '', 'no_title', '[FEATURED_PRODUCT]', 0, '1', 1, '6', 1, 1, 'a:2:{s:7:\"blockid\";i:1;s:7:\"numrows\";i:2;}'), 
(19, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(20, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(21, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''), 
(22, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''), 
(23, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(24, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(25, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:35:\"/index.php?language=vi&nv=siteterms\";}'), 
(26, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(27, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.9845159999999992805896908976137638092041015625;s:20:\"company_mapcenterlng\";d:105.7954749999999961573848850093781948089599609375;s:14:\"company_maplat\";d:20.9845159999999992805896908976137638092041015625;s:14:\"company_maplng\";d:105.7954750000000103682396002113819122314453125;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(28, 'bakery', 'theme', 'global.company_info.php', 'Contact Information', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:0:\"\";s:16:\"company_sortname\";s:0:\"\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:0:\"\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.9845159999999992805896908976137638092041015625;s:20:\"company_mapcenterlng\";d:105.7954749999999961573848850093781948089599609375;s:14:\"company_maplat\";d:20.9845159999999992805896908976137638092041015625;s:14:\"company_maplng\";d:105.7954750000000103682396002113819122314453125;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:15:\"+084-04-1234567\";s:11:\"company_fax\";s:0:\"\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(29, 'bakery', 'menu', 'global.bootstrap.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '3,4', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:2;s:12:\"title_length\";i:20;}'), 
(31, 'bakery', 'theme', 'global.copyright.php', 'Copyright', NULL, 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:39:\"/index.php?language=vi&amp;nv=siteterms\";}'), 
(32, 'bakery', 'contact', 'global.contact_form.php', 'Feedback', NULL, 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(33, 'bakery', 'news', 'global.block_category.php', 'Chủ đề', NULL, 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(34, 'bakery', 'theme', 'global.module_menu.php', 'Module Menu', NULL, 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(35, 'bakery', 'banners', 'global.banners.php', 'Quảng cáo trái', NULL, 'no_title', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(36, 'bakery', 'menu', 'global.metismenu.php', 'Why Choose Us', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:4;s:12:\"title_length\";i:20;}'), 
(63, 'bakery', 'menu', 'global.treeview.php', 'global treeview', '', 'no_title', '[OPENING_HOURS]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:5;s:12:\"title_length\";i:20;}'), 
(37, 'bakery', 'menu', 'global.slimmenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:3;s:12:\"title_length\";i:0;}'), 
(39, 'bakery', 'theme', 'global.QR_code.php', 'QR code', NULL, 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 1, 'a:3:{s:5:\"level\";s:1:\"M\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(40, 'bakery', 'statistics', 'global.counter_button.php', 'Online button', NULL, 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 2, ''), 
(41, 'bakery', 'about', 'global.about.php', 'Giới thiệu', NULL, 'border', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''), 
(44, 'bakery', 'news', 'module.block_newscenter.php', 'Tin mới nhất', NULL, 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:5:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:5:\"width\";s:3:\"400\";s:6:\"height\";s:0:\"\";}'), 
(45, 'bakery', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', NULL, 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(52, 'bakery', 'theme', 'global.image.php', 'global image', '', 'no_title', '[SLIDE_SHOW]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"imagecontent\";s:107:\"uploads/5_5.jpg|ngocphan|-||-uploads/sl1.png||-||-uploads/6.jpg||-||-||-||-||-||-||-||-||-||-||-||-||-||-||\";}'), 
(56, 'bakery', 'shops', 'global.block_relates_product.php', 'Featured Cakes', '', 'simple', '[HEADER]', 0, '1', 1, '6', 0, 1, 'a:3:{s:7:\"blockid\";i:2;s:6:\"numrow\";i:10;s:7:\"cut_num\";i:24;}'), 
(58, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[IMG_LEFT]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:3;}'), 
(59, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[IMG_BODY]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(60, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[IMG_RIGHT_RIGHT]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:4;}'), 
(61, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[IMG_LEFT_1]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:5;}'), 
(62, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[IMG_BODY_1]', 0, '1', 1, '6', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:6;}'), 
(64, 'bakery', 'theme', 'global.social.php', 'Social With Us', '', 'simple', '[SOCIIAL_WHITH_US]', 0, '1', 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(65, 'bakery', 'theme', 'global.module_menu.php', 'global module menu', '', '', '[POPULAR_TAGS]', 0, '1', 1, '6', 1, 1, ''), 
(66, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[RIGHT]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:5;}'), 
(67, 'bakery', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[RIGHT]', 0, '1', 1, '6', 0, 3, 'a:1:{s:12:\"idplanbanner\";i:4;}');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_weight`;
CREATE TABLE `nv4_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_weight`
--

INSERT INTO `nv4_vi_blocks_weight` VALUES
(13, 1, 1), 
(13, 36, 1), 
(13, 37, 1), 
(13, 38, 1), 
(13, 39, 1), 
(13, 45, 1), 
(13, 46, 1), 
(13, 47, 1), 
(13, 48, 1), 
(13, 55, 1), 
(13, 58, 1), 
(13, 4, 1), 
(13, 5, 1), 
(13, 6, 1), 
(13, 7, 1), 
(13, 8, 1), 
(13, 9, 1), 
(13, 10, 1), 
(13, 11, 1), 
(13, 12, 1), 
(13, 49, 1), 
(13, 57, 1), 
(13, 52, 1), 
(13, 53, 1), 
(13, 29, 1), 
(13, 30, 1), 
(13, 31, 1), 
(13, 32, 1), 
(13, 33, 1), 
(13, 34, 1), 
(13, 35, 1), 
(13, 18, 1), 
(13, 19, 1), 
(13, 20, 1), 
(13, 21, 1), 
(13, 22, 1), 
(13, 23, 1), 
(13, 24, 1), 
(13, 25, 1), 
(13, 26, 1), 
(13, 27, 1), 
(13, 56, 1), 
(15, 1, 1), 
(15, 36, 1), 
(15, 37, 1), 
(15, 38, 1), 
(15, 39, 1), 
(15, 45, 1), 
(15, 46, 1), 
(15, 47, 1), 
(15, 48, 1), 
(15, 55, 1), 
(15, 58, 1), 
(15, 4, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 8, 1), 
(15, 9, 1), 
(15, 10, 1), 
(15, 11, 1), 
(15, 12, 1), 
(15, 49, 1), 
(15, 57, 1), 
(15, 52, 1), 
(15, 53, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 35, 1), 
(15, 18, 1), 
(15, 19, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 22, 1), 
(15, 23, 1), 
(15, 24, 1), 
(15, 25, 1), 
(15, 26, 1), 
(15, 27, 1), 
(15, 56, 1), 
(18, 1, 1), 
(18, 36, 1), 
(18, 37, 1), 
(18, 38, 1), 
(18, 39, 1), 
(18, 45, 1), 
(18, 46, 1), 
(18, 47, 1), 
(18, 48, 1), 
(18, 55, 1), 
(18, 58, 1), 
(18, 4, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 8, 1), 
(18, 9, 1), 
(18, 10, 1), 
(18, 11, 1), 
(18, 12, 1), 
(18, 49, 1), 
(18, 57, 1), 
(18, 52, 1), 
(18, 53, 1), 
(18, 29, 1), 
(18, 30, 1), 
(18, 31, 1), 
(18, 32, 1), 
(18, 33, 1), 
(18, 34, 1), 
(18, 35, 1), 
(18, 18, 1), 
(18, 19, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 22, 1), 
(18, 23, 1), 
(18, 24, 1), 
(18, 25, 1), 
(18, 26, 1), 
(18, 27, 1), 
(18, 56, 1), 
(8, 1, 1), 
(8, 36, 1), 
(8, 37, 1), 
(8, 38, 1), 
(8, 39, 1), 
(8, 45, 1), 
(8, 46, 1), 
(8, 47, 1), 
(8, 48, 1), 
(8, 55, 1), 
(8, 58, 1), 
(8, 4, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 1), 
(8, 8, 1), 
(8, 9, 1), 
(8, 10, 1), 
(8, 11, 1), 
(8, 12, 1), 
(8, 49, 1), 
(8, 57, 1), 
(8, 52, 1), 
(8, 53, 1), 
(8, 29, 1), 
(8, 30, 1), 
(8, 31, 1), 
(8, 32, 1), 
(8, 33, 1), 
(8, 34, 1), 
(8, 35, 1), 
(8, 18, 1), 
(8, 19, 1), 
(8, 20, 1), 
(8, 21, 1), 
(8, 22, 1), 
(8, 23, 1), 
(8, 24, 1), 
(8, 25, 1), 
(8, 26, 1), 
(8, 27, 1), 
(8, 56, 1), 
(9, 1, 2), 
(9, 36, 2), 
(9, 37, 2), 
(9, 38, 2), 
(9, 39, 2), 
(9, 45, 2), 
(9, 46, 2), 
(9, 47, 2), 
(9, 48, 2), 
(9, 55, 2), 
(9, 58, 2), 
(9, 4, 2), 
(9, 5, 2), 
(9, 6, 2), 
(9, 7, 2), 
(9, 8, 2), 
(9, 9, 2), 
(9, 10, 2), 
(9, 11, 2), 
(9, 12, 2), 
(9, 49, 2), 
(9, 57, 2), 
(9, 52, 2), 
(9, 53, 2), 
(9, 29, 2), 
(9, 30, 2), 
(9, 31, 2), 
(9, 32, 2), 
(9, 33, 2), 
(9, 34, 2), 
(9, 35, 2), 
(9, 18, 2), 
(9, 19, 2), 
(9, 20, 2), 
(9, 21, 2), 
(9, 22, 2), 
(9, 23, 2), 
(9, 24, 2), 
(9, 25, 2), 
(9, 26, 2), 
(9, 27, 2), 
(9, 56, 2), 
(3, 7, 1), 
(3, 8, 1), 
(3, 4, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 6, 1), 
(3, 5, 1), 
(3, 12, 1), 
(3, 9, 1), 
(4, 22, 1), 
(4, 24, 1), 
(4, 19, 1), 
(4, 27, 1), 
(4, 23, 1), 
(4, 21, 1), 
(4, 18, 1), 
(4, 20, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 34, 1), 
(4, 32, 1), 
(4, 31, 1), 
(4, 33, 1), 
(4, 30, 1), 
(4, 29, 1), 
(4, 35, 1), 
(5, 1, 1), 
(5, 36, 1), 
(5, 37, 1), 
(5, 38, 1), 
(5, 39, 1), 
(5, 45, 1), 
(5, 46, 1), 
(5, 47, 1), 
(5, 48, 1), 
(5, 55, 1), 
(5, 58, 1), 
(5, 4, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 8, 2), 
(5, 9, 2), 
(5, 10, 2), 
(5, 11, 2), 
(5, 12, 2), 
(5, 49, 1), 
(5, 57, 1), 
(5, 52, 1), 
(5, 53, 1), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 35, 2), 
(5, 18, 2), 
(5, 19, 2), 
(5, 20, 2), 
(5, 21, 2), 
(5, 22, 2), 
(5, 23, 2), 
(5, 24, 2), 
(5, 25, 2), 
(5, 26, 2), 
(5, 27, 2), 
(5, 56, 1), 
(17, 1, 1), 
(17, 36, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 45, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 55, 1), 
(17, 58, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 49, 1), 
(17, 57, 1), 
(17, 52, 1), 
(17, 53, 1), 
(17, 29, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 56, 1), 
(14, 1, 1), 
(14, 36, 1), 
(14, 37, 1), 
(14, 38, 1), 
(14, 39, 1), 
(14, 45, 1), 
(14, 46, 1), 
(14, 47, 1), 
(14, 48, 1), 
(14, 55, 1), 
(14, 58, 1), 
(14, 4, 1), 
(14, 5, 1), 
(14, 6, 1), 
(14, 7, 1), 
(14, 8, 1), 
(14, 9, 1), 
(14, 10, 1), 
(14, 11, 1), 
(14, 12, 1), 
(14, 49, 1), 
(14, 57, 1), 
(14, 52, 1), 
(14, 53, 1), 
(14, 29, 1), 
(14, 30, 1), 
(14, 31, 1), 
(14, 32, 1), 
(14, 33, 1), 
(14, 34, 1), 
(14, 35, 1), 
(14, 18, 1), 
(14, 19, 1), 
(14, 20, 1), 
(14, 21, 1), 
(14, 22, 1), 
(14, 23, 1), 
(14, 24, 1), 
(14, 25, 1), 
(14, 26, 1), 
(14, 27, 1), 
(14, 56, 1), 
(12, 1, 1), 
(12, 36, 1), 
(12, 37, 1), 
(12, 38, 1), 
(12, 39, 1), 
(12, 45, 1), 
(12, 46, 1), 
(12, 47, 1), 
(12, 48, 1), 
(12, 55, 1), 
(12, 58, 1), 
(12, 4, 1), 
(12, 5, 1), 
(12, 6, 1), 
(12, 7, 1), 
(12, 8, 1), 
(12, 9, 1), 
(12, 10, 1), 
(12, 11, 1), 
(12, 12, 1), 
(12, 49, 1), 
(12, 57, 1), 
(12, 52, 1), 
(12, 53, 1), 
(12, 29, 1), 
(12, 30, 1), 
(12, 31, 1), 
(12, 32, 1), 
(12, 33, 1), 
(12, 34, 1), 
(12, 35, 1), 
(12, 18, 1), 
(12, 19, 1), 
(12, 20, 1), 
(12, 21, 1), 
(12, 22, 1), 
(12, 23, 1), 
(12, 24, 1), 
(12, 25, 1), 
(12, 26, 1), 
(12, 27, 1), 
(12, 56, 1), 
(10, 1, 1), 
(10, 36, 1), 
(10, 37, 1), 
(10, 38, 1), 
(10, 39, 1), 
(10, 45, 1), 
(10, 46, 1), 
(10, 47, 1), 
(10, 48, 1), 
(10, 55, 1), 
(10, 58, 1), 
(10, 4, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 8, 1), 
(10, 9, 1), 
(10, 10, 1), 
(10, 11, 1), 
(10, 12, 1), 
(10, 49, 1), 
(10, 57, 1), 
(10, 52, 1), 
(10, 53, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 35, 1), 
(10, 18, 1), 
(10, 19, 1), 
(10, 20, 1), 
(10, 21, 1), 
(10, 22, 1), 
(10, 23, 1), 
(10, 24, 1), 
(10, 25, 1), 
(10, 26, 1), 
(10, 27, 1), 
(10, 56, 1), 
(11, 1, 2), 
(11, 36, 2), 
(11, 37, 2), 
(11, 38, 2), 
(11, 39, 2), 
(11, 45, 2), 
(11, 46, 2), 
(11, 47, 2), 
(11, 48, 2), 
(11, 55, 2), 
(11, 58, 2), 
(11, 4, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 8, 2), 
(11, 9, 2), 
(11, 10, 2), 
(11, 11, 2), 
(11, 12, 2), 
(11, 49, 2), 
(11, 57, 2), 
(11, 52, 2), 
(11, 53, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 35, 2), 
(11, 18, 2), 
(11, 19, 2), 
(11, 20, 2), 
(11, 21, 2), 
(11, 22, 2), 
(11, 23, 2), 
(11, 24, 2), 
(11, 25, 2), 
(11, 26, 2), 
(11, 27, 2), 
(11, 56, 2), 
(6, 1, 1), 
(6, 36, 1), 
(6, 37, 1), 
(6, 38, 1), 
(6, 39, 1), 
(6, 45, 1), 
(6, 46, 1), 
(6, 47, 1), 
(6, 48, 1), 
(6, 55, 1), 
(6, 58, 1), 
(6, 4, 1), 
(6, 5, 1), 
(6, 6, 1), 
(6, 7, 1), 
(6, 8, 1), 
(6, 9, 1), 
(6, 10, 1), 
(6, 11, 1), 
(6, 12, 1), 
(6, 49, 1), 
(6, 57, 1), 
(6, 52, 1), 
(6, 53, 1), 
(6, 29, 1), 
(6, 30, 1), 
(6, 31, 1), 
(6, 32, 1), 
(6, 33, 1), 
(6, 34, 1), 
(6, 35, 1), 
(6, 18, 1), 
(6, 19, 1), 
(6, 20, 1), 
(6, 21, 1), 
(6, 22, 1), 
(6, 23, 1), 
(6, 24, 1), 
(6, 25, 1), 
(6, 26, 1), 
(6, 27, 1), 
(6, 56, 1), 
(7, 1, 2), 
(7, 36, 2), 
(7, 37, 2), 
(7, 38, 2), 
(7, 39, 2), 
(7, 45, 2), 
(7, 46, 2), 
(7, 47, 2), 
(7, 48, 2), 
(7, 55, 2), 
(7, 58, 2), 
(7, 4, 2), 
(7, 5, 2), 
(7, 6, 2), 
(7, 7, 2), 
(7, 8, 2), 
(7, 9, 2), 
(7, 10, 2), 
(7, 11, 2), 
(7, 12, 2), 
(7, 49, 2), 
(7, 57, 2), 
(7, 52, 2), 
(7, 53, 2), 
(7, 29, 2), 
(7, 30, 2), 
(7, 31, 2), 
(7, 32, 2), 
(7, 33, 2), 
(7, 34, 2), 
(7, 35, 2), 
(7, 18, 2), 
(7, 19, 2), 
(7, 20, 2), 
(7, 21, 2), 
(7, 22, 2), 
(7, 23, 2), 
(7, 24, 2), 
(7, 25, 2), 
(7, 26, 2), 
(7, 27, 2), 
(7, 56, 2), 
(16, 1, 1), 
(16, 36, 1), 
(16, 37, 1), 
(16, 38, 1), 
(16, 39, 1), 
(16, 45, 1), 
(16, 46, 1), 
(16, 47, 1), 
(16, 48, 1), 
(16, 55, 1), 
(16, 58, 1), 
(16, 4, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 8, 1), 
(16, 9, 1), 
(16, 10, 1), 
(16, 11, 1), 
(16, 12, 1), 
(16, 49, 1), 
(16, 57, 1), 
(16, 52, 1), 
(16, 53, 1), 
(16, 29, 1), 
(16, 30, 1), 
(16, 31, 1), 
(16, 32, 1), 
(16, 33, 1), 
(16, 34, 1), 
(16, 35, 1), 
(16, 18, 1), 
(16, 19, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 22, 1), 
(16, 23, 1), 
(16, 24, 1), 
(16, 25, 1), 
(16, 26, 1), 
(16, 27, 1), 
(16, 56, 1), 
(1, 4, 1), 
(2, 4, 2), 
(27, 1, 1), 
(27, 36, 1), 
(27, 37, 1), 
(27, 38, 1), 
(27, 39, 1), 
(27, 45, 1), 
(27, 46, 1), 
(27, 47, 1), 
(27, 48, 1), 
(27, 55, 1), 
(27, 58, 1), 
(27, 4, 1), 
(27, 5, 1), 
(27, 6, 1), 
(27, 7, 1), 
(27, 8, 1), 
(27, 9, 1), 
(27, 10, 1), 
(27, 11, 1), 
(27, 12, 1), 
(27, 49, 1), 
(27, 57, 1), 
(27, 52, 1), 
(27, 53, 1), 
(27, 29, 1), 
(27, 30, 1), 
(27, 31, 1), 
(27, 32, 1), 
(27, 33, 1), 
(27, 34, 1), 
(27, 35, 1), 
(27, 18, 1), 
(27, 19, 1), 
(27, 20, 1), 
(27, 21, 1), 
(27, 22, 1), 
(27, 23, 1), 
(27, 24, 1), 
(27, 25, 1), 
(27, 26, 1), 
(27, 27, 1), 
(27, 56, 1), 
(25, 1, 1), 
(25, 36, 1), 
(25, 37, 1), 
(25, 38, 1), 
(25, 39, 1), 
(25, 45, 1), 
(25, 46, 1), 
(25, 47, 1), 
(25, 48, 1), 
(25, 55, 1), 
(25, 58, 1), 
(25, 4, 1), 
(25, 5, 1), 
(25, 6, 1), 
(25, 7, 1), 
(25, 8, 1), 
(25, 9, 1), 
(25, 10, 1), 
(25, 11, 1), 
(25, 12, 1), 
(25, 49, 1), 
(25, 57, 1), 
(25, 52, 1), 
(25, 53, 1), 
(25, 29, 1), 
(25, 30, 1), 
(25, 31, 1), 
(25, 32, 1), 
(25, 33, 1), 
(25, 34, 1), 
(25, 35, 1), 
(25, 18, 1), 
(25, 19, 1), 
(25, 20, 1), 
(25, 21, 1), 
(25, 22, 1), 
(25, 23, 1), 
(25, 24, 1), 
(25, 25, 1), 
(25, 26, 1), 
(25, 27, 1), 
(25, 56, 1), 
(26, 1, 1), 
(26, 36, 1), 
(26, 37, 1), 
(26, 38, 1), 
(26, 39, 1), 
(26, 45, 1), 
(26, 46, 1), 
(26, 47, 1), 
(26, 48, 1), 
(26, 55, 1), 
(26, 58, 1), 
(26, 4, 1), 
(26, 5, 1), 
(26, 6, 1), 
(26, 7, 1), 
(26, 8, 1), 
(26, 9, 1), 
(26, 10, 1), 
(26, 11, 1), 
(26, 12, 1), 
(26, 49, 1), 
(26, 57, 1), 
(26, 52, 1), 
(26, 53, 1), 
(26, 29, 1), 
(26, 30, 1), 
(26, 31, 1), 
(26, 32, 1), 
(26, 33, 1), 
(26, 34, 1), 
(26, 35, 1), 
(26, 18, 1), 
(26, 19, 1), 
(26, 20, 1), 
(26, 21, 1), 
(26, 22, 1), 
(26, 23, 1), 
(26, 24, 1), 
(26, 25, 1), 
(26, 26, 1), 
(26, 27, 1), 
(26, 56, 1), 
(19, 1, 1), 
(19, 36, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 45, 1), 
(19, 46, 1), 
(19, 47, 1), 
(19, 48, 1), 
(19, 55, 1), 
(19, 58, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 49, 1), 
(19, 57, 1), 
(19, 52, 1), 
(19, 53, 1), 
(19, 29, 1), 
(19, 30, 1), 
(19, 31, 1), 
(19, 32, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 18, 1), 
(19, 19, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 56, 1), 
(20, 1, 2), 
(20, 36, 2), 
(20, 37, 2), 
(20, 38, 2), 
(20, 39, 2), 
(20, 45, 2), 
(20, 46, 2), 
(20, 47, 2), 
(20, 48, 2), 
(20, 55, 2), 
(20, 58, 2), 
(20, 4, 2), 
(20, 5, 2), 
(20, 6, 2), 
(20, 7, 2), 
(20, 8, 2), 
(20, 9, 2), 
(20, 10, 2), 
(20, 11, 2), 
(20, 12, 2), 
(20, 49, 2), 
(20, 57, 2), 
(20, 52, 2), 
(20, 53, 2), 
(20, 29, 2), 
(20, 30, 2), 
(20, 31, 2), 
(20, 32, 2), 
(20, 33, 2), 
(20, 34, 2), 
(20, 35, 2), 
(20, 18, 2), 
(20, 19, 2), 
(20, 20, 2), 
(20, 21, 2), 
(20, 22, 2), 
(20, 23, 2), 
(20, 24, 2), 
(20, 25, 2), 
(20, 26, 2), 
(20, 27, 2), 
(20, 56, 2), 
(21, 1, 1), 
(21, 36, 1), 
(21, 37, 1), 
(21, 38, 1), 
(21, 39, 1), 
(21, 45, 1), 
(21, 46, 1), 
(21, 47, 1), 
(21, 48, 1), 
(21, 55, 1), 
(21, 58, 1), 
(21, 4, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 8, 1), 
(21, 9, 1), 
(21, 10, 1), 
(21, 11, 1), 
(21, 12, 1), 
(21, 49, 1), 
(21, 57, 1), 
(21, 52, 1), 
(21, 53, 1), 
(21, 29, 1), 
(21, 30, 1), 
(21, 31, 1), 
(21, 32, 1), 
(21, 33, 1), 
(21, 34, 1), 
(21, 35, 1), 
(21, 18, 1), 
(21, 19, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 22, 1), 
(21, 23, 1), 
(21, 24, 1), 
(21, 25, 1), 
(21, 26, 1), 
(21, 27, 1), 
(21, 56, 1), 
(22, 1, 2), 
(22, 36, 2), 
(22, 37, 2), 
(22, 38, 2), 
(22, 39, 2), 
(22, 45, 2), 
(22, 46, 2), 
(22, 47, 2), 
(22, 48, 2), 
(22, 55, 2), 
(22, 58, 2), 
(22, 4, 2), 
(22, 5, 2), 
(22, 6, 2), 
(22, 7, 2), 
(22, 8, 2), 
(22, 9, 2), 
(22, 10, 2), 
(22, 11, 2), 
(22, 12, 2), 
(22, 49, 2), 
(22, 57, 2), 
(22, 52, 2), 
(22, 53, 2), 
(22, 29, 2), 
(22, 30, 2), 
(22, 31, 2), 
(22, 32, 2), 
(22, 33, 2), 
(22, 34, 2), 
(22, 35, 2), 
(22, 18, 2), 
(22, 19, 2), 
(22, 20, 2), 
(22, 21, 2), 
(22, 22, 2), 
(22, 23, 2), 
(22, 24, 2), 
(22, 25, 2), 
(22, 26, 2), 
(22, 27, 2), 
(22, 56, 2), 
(23, 1, 3), 
(23, 36, 3), 
(23, 37, 3), 
(23, 38, 3), 
(23, 39, 3), 
(23, 45, 3), 
(23, 46, 3), 
(23, 47, 3), 
(23, 48, 3), 
(23, 55, 3), 
(23, 58, 3), 
(23, 4, 3), 
(23, 5, 3), 
(23, 6, 3), 
(23, 7, 3), 
(23, 8, 3), 
(23, 9, 3), 
(23, 10, 3), 
(23, 11, 3), 
(23, 12, 3), 
(23, 49, 3), 
(23, 57, 3), 
(23, 52, 3), 
(23, 53, 3), 
(23, 29, 3), 
(23, 30, 3), 
(23, 31, 3), 
(23, 32, 3), 
(23, 33, 3), 
(23, 34, 3), 
(23, 35, 3), 
(23, 18, 3), 
(23, 19, 3), 
(23, 20, 3), 
(23, 21, 3), 
(23, 22, 3), 
(23, 23, 3), 
(23, 24, 3), 
(23, 25, 3), 
(23, 26, 3), 
(23, 27, 3), 
(23, 56, 3), 
(24, 1, 4), 
(24, 36, 4), 
(24, 37, 4), 
(24, 38, 4), 
(24, 39, 4), 
(24, 45, 4), 
(24, 46, 4), 
(24, 47, 4), 
(24, 48, 4), 
(24, 55, 4), 
(24, 58, 4), 
(24, 4, 4), 
(24, 5, 4), 
(24, 6, 4), 
(24, 7, 4), 
(24, 8, 4), 
(24, 9, 4), 
(24, 10, 4), 
(24, 11, 4), 
(24, 12, 4), 
(24, 49, 4), 
(24, 57, 4), 
(24, 52, 4), 
(24, 53, 4), 
(24, 29, 4), 
(24, 30, 4), 
(24, 31, 4), 
(24, 32, 4), 
(24, 33, 4), 
(24, 34, 4), 
(24, 35, 4), 
(24, 18, 4), 
(24, 19, 4), 
(24, 20, 4), 
(24, 21, 4), 
(24, 22, 4), 
(24, 23, 4), 
(24, 24, 4), 
(24, 25, 4), 
(24, 26, 4), 
(24, 27, 4), 
(24, 56, 4), 
(13, 69, 1), 
(13, 85, 1), 
(13, 64, 1), 
(13, 78, 1), 
(13, 59, 1), 
(13, 70, 1), 
(13, 71, 1), 
(13, 62, 1), 
(13, 67, 1), 
(13, 66, 1), 
(13, 79, 1), 
(13, 61, 1), 
(13, 86, 1), 
(13, 84, 1), 
(13, 72, 1), 
(13, 82, 1), 
(13, 65, 1), 
(15, 69, 1), 
(15, 85, 1), 
(15, 64, 1), 
(15, 78, 1), 
(15, 59, 1), 
(15, 70, 1), 
(15, 71, 1), 
(15, 62, 1), 
(15, 67, 1), 
(15, 66, 1), 
(15, 79, 1), 
(15, 61, 1), 
(15, 86, 1), 
(15, 84, 1), 
(15, 72, 1), 
(15, 82, 1), 
(15, 65, 1), 
(18, 69, 1), 
(18, 85, 1), 
(18, 64, 1), 
(18, 78, 1), 
(18, 59, 1), 
(18, 70, 1), 
(18, 71, 1), 
(18, 62, 1), 
(18, 67, 1), 
(18, 66, 1), 
(18, 79, 1), 
(18, 61, 1), 
(18, 86, 1), 
(18, 84, 1), 
(18, 72, 1), 
(18, 82, 1), 
(18, 65, 1), 
(8, 69, 1), 
(8, 85, 1), 
(8, 64, 1), 
(8, 78, 1), 
(8, 59, 1), 
(8, 70, 1), 
(8, 71, 1), 
(8, 62, 1), 
(8, 67, 1), 
(8, 66, 1), 
(8, 79, 1), 
(8, 61, 1), 
(8, 86, 1), 
(8, 84, 1), 
(8, 72, 1), 
(8, 82, 1), 
(8, 65, 1), 
(9, 69, 2), 
(9, 85, 2), 
(9, 64, 2), 
(9, 78, 2), 
(9, 59, 2), 
(9, 70, 2), 
(9, 71, 2), 
(9, 62, 2), 
(9, 67, 2), 
(9, 66, 2), 
(9, 79, 2), 
(9, 61, 2), 
(9, 86, 2), 
(9, 84, 2), 
(9, 72, 2), 
(9, 82, 2), 
(9, 65, 2), 
(5, 69, 1), 
(5, 85, 1), 
(5, 64, 1), 
(5, 78, 1), 
(5, 59, 1), 
(5, 70, 1), 
(5, 71, 1), 
(5, 62, 1), 
(5, 67, 1), 
(5, 66, 1), 
(5, 79, 1), 
(5, 61, 1), 
(5, 86, 1), 
(5, 84, 1), 
(5, 72, 1), 
(5, 82, 1), 
(5, 65, 1), 
(17, 69, 1), 
(17, 85, 1), 
(17, 64, 1), 
(17, 78, 1), 
(17, 59, 1), 
(17, 70, 1), 
(17, 71, 1), 
(17, 62, 1), 
(17, 67, 1), 
(17, 66, 1), 
(17, 79, 1), 
(17, 61, 1), 
(17, 86, 1), 
(17, 84, 1), 
(17, 72, 1), 
(17, 82, 1), 
(17, 65, 1), 
(14, 69, 1), 
(14, 85, 1), 
(14, 64, 1), 
(14, 78, 1), 
(14, 59, 1), 
(14, 70, 1), 
(14, 71, 1), 
(14, 62, 1), 
(14, 67, 1), 
(14, 66, 1), 
(14, 79, 1), 
(14, 61, 1), 
(14, 86, 1), 
(14, 84, 1), 
(14, 72, 1), 
(14, 82, 1), 
(14, 65, 1), 
(12, 69, 1), 
(12, 85, 1), 
(12, 64, 1), 
(12, 78, 1), 
(12, 59, 1), 
(12, 70, 1), 
(12, 71, 1), 
(12, 62, 1), 
(12, 67, 1), 
(12, 66, 1), 
(12, 79, 1), 
(12, 61, 1), 
(12, 86, 1), 
(12, 84, 1), 
(12, 72, 1), 
(12, 82, 1), 
(12, 65, 1), 
(10, 69, 1), 
(10, 85, 1), 
(10, 64, 1), 
(10, 78, 1), 
(10, 59, 1), 
(10, 70, 1), 
(10, 71, 1), 
(10, 62, 1), 
(10, 67, 1), 
(10, 66, 1), 
(10, 79, 1), 
(10, 61, 1), 
(10, 86, 1), 
(10, 84, 1), 
(10, 72, 1), 
(10, 82, 1), 
(10, 65, 1), 
(11, 69, 2), 
(11, 85, 2), 
(11, 64, 2), 
(11, 78, 2), 
(11, 59, 2), 
(11, 70, 2), 
(11, 71, 2), 
(11, 62, 2), 
(11, 67, 2), 
(11, 66, 2), 
(11, 79, 2), 
(11, 61, 2), 
(11, 86, 2), 
(11, 84, 2), 
(11, 72, 2), 
(11, 82, 2), 
(11, 65, 2), 
(6, 69, 1), 
(6, 85, 1), 
(6, 64, 1), 
(6, 78, 1), 
(6, 59, 1), 
(6, 70, 1), 
(6, 71, 1), 
(6, 62, 1), 
(6, 67, 1), 
(6, 66, 1), 
(6, 79, 1), 
(6, 61, 1), 
(6, 86, 1), 
(6, 84, 1), 
(6, 72, 1), 
(6, 82, 1), 
(6, 65, 1), 
(7, 69, 2), 
(7, 85, 2), 
(7, 64, 2), 
(7, 78, 2), 
(7, 59, 2), 
(7, 70, 2), 
(7, 71, 2), 
(7, 62, 2), 
(7, 67, 2), 
(7, 66, 2), 
(7, 79, 2), 
(7, 61, 2), 
(7, 86, 2), 
(7, 84, 2), 
(7, 72, 2), 
(7, 82, 2), 
(7, 65, 2), 
(16, 69, 1), 
(16, 85, 1), 
(16, 64, 1), 
(16, 78, 1), 
(16, 59, 1), 
(16, 70, 1), 
(16, 71, 1), 
(16, 62, 1), 
(16, 67, 1), 
(16, 66, 1), 
(16, 79, 1), 
(16, 61, 1), 
(16, 86, 1), 
(16, 84, 1), 
(16, 72, 1), 
(16, 82, 1), 
(16, 65, 1), 
(27, 69, 1), 
(27, 85, 1), 
(27, 64, 1), 
(27, 78, 1), 
(27, 59, 1), 
(27, 70, 1), 
(27, 71, 1), 
(27, 62, 1), 
(27, 67, 1), 
(27, 66, 1), 
(27, 79, 1), 
(27, 61, 1), 
(27, 86, 1), 
(27, 84, 1), 
(27, 72, 1), 
(27, 82, 1), 
(27, 65, 1), 
(25, 69, 1), 
(25, 85, 1), 
(25, 64, 1), 
(25, 78, 1), 
(25, 59, 1), 
(25, 70, 1), 
(25, 71, 1), 
(25, 62, 1), 
(25, 67, 1), 
(25, 66, 1), 
(25, 79, 1), 
(25, 61, 1), 
(25, 86, 1), 
(25, 84, 1), 
(25, 72, 1), 
(25, 82, 1), 
(25, 65, 1), 
(26, 69, 1), 
(26, 85, 1), 
(26, 64, 1), 
(26, 78, 1), 
(26, 59, 1), 
(26, 70, 1), 
(26, 71, 1), 
(26, 62, 1), 
(26, 67, 1), 
(26, 66, 1), 
(26, 79, 1), 
(26, 61, 1), 
(26, 86, 1), 
(26, 84, 1), 
(26, 72, 1), 
(26, 82, 1), 
(26, 65, 1), 
(19, 69, 1), 
(19, 85, 1), 
(19, 64, 1), 
(19, 78, 1), 
(19, 59, 1), 
(19, 70, 1), 
(19, 71, 1), 
(19, 62, 1), 
(19, 67, 1), 
(19, 66, 1), 
(19, 79, 1), 
(19, 61, 1), 
(19, 86, 1), 
(19, 84, 1), 
(19, 72, 1), 
(19, 82, 1), 
(19, 65, 1), 
(20, 69, 2), 
(20, 85, 2), 
(20, 64, 2), 
(20, 78, 2), 
(20, 59, 2), 
(20, 70, 2), 
(20, 71, 2), 
(20, 62, 2), 
(20, 67, 2), 
(20, 66, 2), 
(20, 79, 2), 
(20, 61, 2), 
(20, 86, 2), 
(20, 84, 2), 
(20, 72, 2), 
(20, 82, 2), 
(20, 65, 2), 
(21, 69, 1), 
(21, 85, 1), 
(21, 64, 1), 
(21, 78, 1), 
(21, 59, 1), 
(21, 70, 1), 
(21, 71, 1), 
(21, 62, 1), 
(21, 67, 1), 
(21, 66, 1), 
(21, 79, 1), 
(21, 61, 1), 
(21, 86, 1), 
(21, 84, 1), 
(21, 72, 1), 
(21, 82, 1), 
(21, 65, 1), 
(22, 69, 2), 
(22, 85, 2), 
(22, 64, 2), 
(22, 78, 2), 
(22, 59, 2), 
(22, 70, 2), 
(22, 71, 2), 
(22, 62, 2), 
(22, 67, 2), 
(22, 66, 2), 
(22, 79, 2), 
(22, 61, 2), 
(22, 86, 2), 
(22, 84, 2), 
(22, 72, 2), 
(22, 82, 2), 
(22, 65, 2), 
(23, 69, 3), 
(23, 85, 3), 
(23, 64, 3), 
(23, 78, 3), 
(23, 59, 3), 
(23, 70, 3), 
(23, 71, 3), 
(23, 62, 3), 
(23, 67, 3), 
(23, 66, 3), 
(23, 79, 3), 
(23, 61, 3), 
(23, 86, 3), 
(23, 84, 3), 
(23, 72, 3), 
(23, 82, 3), 
(23, 65, 3), 
(24, 69, 4), 
(24, 85, 4), 
(24, 64, 4), 
(24, 78, 4), 
(24, 59, 4), 
(24, 70, 4), 
(24, 71, 4), 
(24, 62, 4), 
(24, 67, 4), 
(24, 66, 4), 
(24, 79, 4), 
(24, 61, 4), 
(24, 86, 4), 
(24, 84, 4), 
(24, 72, 4), 
(24, 82, 4), 
(24, 65, 4), 
(28, 1, 1), 
(28, 36, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 45, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 55, 1), 
(28, 58, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 49, 1), 
(28, 57, 1), 
(28, 69, 1), 
(28, 85, 1), 
(28, 64, 1), 
(28, 78, 1), 
(28, 59, 1), 
(28, 70, 1), 
(28, 71, 1), 
(28, 62, 1), 
(28, 67, 1), 
(28, 66, 1), 
(28, 79, 1), 
(28, 61, 1), 
(28, 86, 1), 
(28, 84, 1), 
(28, 72, 1), 
(28, 82, 1), 
(28, 65, 1), 
(28, 52, 1), 
(28, 53, 1), 
(28, 29, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 56, 1), 
(29, 1, 1), 
(29, 36, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 45, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 55, 1), 
(29, 58, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 49, 1), 
(29, 57, 1), 
(29, 69, 1), 
(29, 85, 1), 
(29, 64, 1), 
(29, 78, 1), 
(29, 59, 1), 
(29, 70, 1), 
(29, 71, 1), 
(29, 62, 1), 
(29, 67, 1), 
(29, 66, 1), 
(29, 79, 1), 
(29, 61, 1), 
(29, 86, 1), 
(29, 84, 1), 
(29, 72, 1), 
(29, 82, 1), 
(29, 65, 1), 
(29, 52, 1), 
(29, 53, 1), 
(29, 29, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 56, 1), 
(31, 1, 1), 
(31, 36, 1), 
(31, 37, 1), 
(31, 38, 1), 
(31, 39, 1), 
(31, 45, 1), 
(31, 46, 1), 
(31, 47, 1), 
(31, 48, 1), 
(31, 55, 1), 
(31, 58, 1), 
(31, 4, 1), 
(31, 5, 1), 
(31, 6, 1), 
(31, 7, 1), 
(31, 8, 1), 
(31, 9, 1), 
(31, 10, 1), 
(31, 11, 1), 
(31, 12, 1), 
(31, 49, 1), 
(31, 57, 1), 
(31, 69, 1), 
(31, 85, 1), 
(31, 64, 1), 
(31, 78, 1), 
(31, 59, 1), 
(31, 70, 1), 
(31, 71, 1), 
(31, 62, 1), 
(31, 67, 1), 
(31, 66, 1), 
(31, 79, 1), 
(31, 61, 1), 
(31, 86, 1), 
(31, 84, 1), 
(31, 72, 1), 
(31, 82, 1), 
(31, 65, 1), 
(31, 52, 1), 
(31, 53, 1), 
(31, 29, 1), 
(31, 30, 1), 
(31, 31, 1), 
(31, 32, 1), 
(31, 33, 1), 
(31, 34, 1), 
(31, 35, 1), 
(31, 18, 1), 
(31, 19, 1), 
(31, 20, 1), 
(31, 21, 1), 
(31, 22, 1), 
(31, 23, 1), 
(31, 24, 1), 
(31, 25, 1), 
(31, 26, 1), 
(31, 27, 1), 
(31, 56, 1), 
(32, 1, 2), 
(32, 36, 2), 
(32, 37, 2), 
(32, 38, 2), 
(32, 39, 2), 
(32, 45, 2), 
(32, 46, 2), 
(32, 47, 2), 
(32, 48, 2), 
(32, 55, 2), 
(32, 58, 2), 
(32, 4, 2), 
(32, 5, 2), 
(32, 6, 2), 
(32, 7, 2), 
(32, 8, 2), 
(32, 9, 2), 
(32, 10, 2), 
(32, 11, 2), 
(32, 12, 2), 
(32, 49, 2), 
(32, 57, 2), 
(32, 69, 2), 
(32, 85, 2), 
(32, 64, 2), 
(32, 78, 2), 
(32, 59, 2), 
(32, 70, 2), 
(32, 71, 2), 
(32, 62, 2), 
(32, 67, 2), 
(32, 66, 2), 
(32, 79, 2), 
(32, 61, 2), 
(32, 86, 2), 
(32, 84, 2), 
(32, 72, 2), 
(32, 82, 2), 
(32, 65, 2), 
(32, 52, 2), 
(32, 53, 2), 
(32, 29, 2), 
(32, 30, 2), 
(32, 31, 2), 
(32, 32, 2), 
(32, 33, 2), 
(32, 34, 2), 
(32, 35, 2), 
(32, 18, 2), 
(32, 19, 2), 
(32, 20, 2), 
(32, 21, 2), 
(32, 22, 2), 
(32, 23, 2), 
(32, 24, 2), 
(32, 25, 2), 
(32, 26, 2), 
(32, 27, 2), 
(32, 56, 2), 
(33, 4, 1), 
(33, 5, 1), 
(33, 6, 1), 
(33, 7, 1), 
(33, 8, 1), 
(33, 9, 1), 
(33, 10, 1), 
(33, 11, 1), 
(33, 12, 1), 
(34, 18, 1), 
(34, 19, 1), 
(34, 20, 1), 
(34, 21, 1), 
(34, 22, 1), 
(34, 23, 1), 
(34, 24, 1), 
(34, 25, 1), 
(34, 26, 1), 
(34, 27, 1), 
(34, 29, 1), 
(34, 30, 1), 
(34, 31, 1), 
(34, 32, 1), 
(34, 33, 1), 
(34, 34, 1), 
(34, 35, 1), 
(35, 1, 1), 
(35, 36, 1), 
(35, 37, 1), 
(35, 38, 1), 
(35, 39, 1), 
(35, 45, 1), 
(35, 46, 1), 
(35, 47, 1), 
(35, 48, 1), 
(35, 55, 1), 
(35, 58, 1), 
(35, 4, 2), 
(35, 5, 2), 
(35, 6, 2), 
(35, 7, 2), 
(35, 8, 2), 
(35, 9, 2), 
(35, 10, 2), 
(35, 11, 2), 
(35, 12, 2), 
(35, 49, 1), 
(35, 57, 1), 
(35, 69, 1), 
(35, 85, 1), 
(35, 64, 1), 
(35, 78, 1), 
(35, 59, 1), 
(35, 70, 1), 
(35, 71, 1), 
(35, 62, 1), 
(35, 67, 1), 
(35, 66, 1), 
(35, 79, 1), 
(35, 61, 1), 
(35, 86, 1), 
(35, 84, 1), 
(35, 72, 1), 
(35, 82, 1), 
(35, 65, 1), 
(35, 52, 1), 
(35, 53, 1), 
(35, 29, 2), 
(35, 30, 2), 
(35, 31, 2), 
(35, 32, 2), 
(35, 33, 2), 
(35, 34, 2), 
(35, 35, 2), 
(35, 18, 2), 
(35, 19, 2), 
(35, 20, 2), 
(35, 21, 2), 
(35, 22, 2), 
(35, 23, 2), 
(35, 24, 2), 
(35, 25, 2), 
(35, 26, 2), 
(35, 27, 2), 
(35, 56, 1), 
(36, 1, 1), 
(36, 36, 1), 
(36, 37, 1), 
(36, 38, 1), 
(36, 39, 1), 
(36, 45, 1), 
(36, 46, 1), 
(36, 47, 1), 
(36, 48, 1), 
(36, 55, 1), 
(36, 58, 1), 
(36, 4, 1), 
(36, 5, 1), 
(36, 6, 1), 
(36, 7, 1), 
(36, 8, 1), 
(36, 9, 1), 
(36, 10, 1), 
(36, 11, 1), 
(36, 12, 1), 
(36, 49, 1), 
(36, 57, 1), 
(36, 69, 1), 
(36, 85, 1), 
(36, 64, 1), 
(36, 78, 1), 
(36, 59, 1), 
(36, 70, 1), 
(36, 71, 1), 
(36, 62, 1), 
(36, 67, 1), 
(36, 66, 1), 
(36, 79, 1), 
(36, 61, 1), 
(36, 86, 1), 
(36, 84, 1), 
(36, 72, 1), 
(36, 82, 1), 
(36, 65, 1), 
(36, 52, 1), 
(36, 53, 1), 
(36, 29, 1), 
(36, 30, 1), 
(36, 31, 1), 
(36, 32, 1), 
(36, 33, 1), 
(36, 34, 1), 
(36, 35, 1), 
(36, 18, 1), 
(36, 19, 1), 
(36, 20, 1), 
(36, 21, 1), 
(36, 22, 1), 
(36, 23, 1), 
(36, 24, 1), 
(36, 25, 1), 
(36, 26, 1), 
(36, 27, 1), 
(36, 56, 1), 
(37, 1, 1), 
(37, 36, 1), 
(37, 37, 1), 
(37, 38, 1), 
(37, 39, 1), 
(37, 45, 1), 
(37, 46, 1), 
(37, 47, 1), 
(37, 48, 1), 
(37, 55, 1), 
(37, 58, 1), 
(37, 4, 1), 
(37, 5, 1), 
(37, 6, 1), 
(37, 7, 1), 
(37, 8, 1), 
(37, 9, 1), 
(37, 10, 1), 
(37, 11, 1), 
(37, 12, 1), 
(37, 49, 1), 
(37, 57, 1), 
(37, 69, 1), 
(37, 85, 1), 
(37, 64, 1), 
(37, 78, 1), 
(37, 59, 1), 
(37, 70, 1), 
(37, 71, 1), 
(37, 62, 1), 
(37, 67, 1), 
(37, 66, 1), 
(37, 79, 1), 
(37, 61, 1), 
(37, 86, 1), 
(37, 84, 1), 
(37, 72, 1), 
(37, 82, 1), 
(37, 65, 1), 
(37, 52, 1), 
(37, 53, 1), 
(37, 29, 1), 
(37, 30, 1), 
(37, 31, 1), 
(37, 32, 1), 
(37, 33, 1), 
(37, 34, 1), 
(37, 35, 1), 
(37, 18, 1), 
(37, 19, 1), 
(37, 20, 1), 
(37, 21, 1), 
(37, 22, 1), 
(37, 23, 1), 
(37, 24, 1), 
(37, 25, 1), 
(37, 26, 1), 
(37, 27, 1), 
(37, 56, 1), 
(39, 1, 1), 
(39, 36, 1), 
(39, 37, 1), 
(39, 38, 1), 
(39, 39, 1), 
(39, 45, 1), 
(39, 46, 1), 
(39, 47, 1), 
(39, 48, 1), 
(39, 55, 1), 
(39, 58, 1), 
(39, 4, 1), 
(39, 5, 1), 
(39, 6, 1), 
(39, 7, 1), 
(39, 8, 1), 
(39, 9, 1), 
(39, 10, 1), 
(39, 11, 1), 
(39, 12, 1), 
(39, 49, 1), 
(39, 57, 1), 
(39, 69, 1), 
(39, 85, 1), 
(39, 64, 1), 
(39, 78, 1), 
(39, 59, 1), 
(39, 70, 1), 
(39, 71, 1), 
(39, 62, 1), 
(39, 67, 1), 
(39, 66, 1), 
(39, 79, 1), 
(39, 61, 1), 
(39, 86, 1), 
(39, 84, 1), 
(39, 72, 1), 
(39, 82, 1), 
(39, 65, 1), 
(39, 52, 1), 
(39, 53, 1), 
(39, 29, 1), 
(39, 30, 1), 
(39, 31, 1), 
(39, 32, 1), 
(39, 33, 1), 
(39, 34, 1), 
(39, 35, 1), 
(39, 18, 1), 
(39, 19, 1), 
(39, 20, 1), 
(39, 21, 1), 
(39, 22, 1), 
(39, 23, 1), 
(39, 24, 1), 
(39, 25, 1), 
(39, 26, 1), 
(39, 27, 1), 
(39, 56, 1), 
(40, 1, 2), 
(40, 36, 2), 
(40, 37, 2), 
(40, 38, 2), 
(40, 39, 2), 
(40, 45, 2), 
(40, 46, 2), 
(40, 47, 2), 
(40, 48, 2), 
(40, 55, 2), 
(40, 58, 2), 
(40, 4, 2), 
(40, 5, 2), 
(40, 6, 2), 
(40, 7, 2), 
(40, 8, 2), 
(40, 9, 2), 
(40, 10, 2), 
(40, 11, 2), 
(40, 12, 2), 
(40, 49, 2), 
(40, 57, 2), 
(40, 69, 2), 
(40, 85, 2), 
(40, 64, 2), 
(40, 78, 2), 
(40, 59, 2), 
(40, 70, 2), 
(40, 71, 2), 
(40, 62, 2), 
(40, 67, 2), 
(40, 66, 2), 
(40, 79, 2), 
(40, 61, 2), 
(40, 86, 2), 
(40, 84, 2), 
(40, 72, 2), 
(40, 82, 2), 
(40, 65, 2), 
(40, 52, 2), 
(40, 53, 2), 
(40, 29, 2), 
(40, 30, 2), 
(40, 31, 2), 
(40, 32, 2), 
(40, 33, 2), 
(40, 34, 2), 
(40, 35, 2), 
(40, 18, 2), 
(40, 19, 2), 
(40, 20, 2), 
(40, 21, 2), 
(40, 22, 2), 
(40, 23, 2), 
(40, 24, 2), 
(40, 25, 2), 
(40, 26, 2), 
(40, 27, 2), 
(40, 56, 2), 
(41, 1, 1), 
(41, 36, 1), 
(41, 37, 1), 
(41, 38, 1), 
(41, 39, 1), 
(41, 45, 1), 
(41, 46, 1), 
(41, 47, 1), 
(41, 48, 1), 
(41, 55, 1), 
(41, 58, 1), 
(41, 4, 1), 
(41, 5, 1), 
(41, 6, 1), 
(41, 7, 1), 
(41, 8, 1), 
(41, 9, 1), 
(41, 10, 1), 
(41, 11, 1), 
(41, 12, 1), 
(41, 49, 1), 
(41, 57, 1), 
(41, 69, 1), 
(41, 85, 1), 
(41, 64, 1), 
(41, 78, 1), 
(41, 59, 1), 
(41, 70, 1), 
(41, 71, 1), 
(41, 62, 1), 
(41, 67, 1), 
(41, 66, 1), 
(41, 79, 1), 
(41, 61, 1), 
(41, 86, 1), 
(41, 84, 1), 
(41, 72, 1), 
(41, 82, 1), 
(41, 65, 1), 
(41, 52, 1), 
(41, 53, 1), 
(41, 29, 1), 
(41, 30, 1), 
(41, 31, 1), 
(41, 32, 1), 
(41, 33, 1), 
(41, 34, 1), 
(41, 35, 1), 
(41, 18, 1), 
(41, 19, 1), 
(41, 20, 1), 
(41, 21, 1), 
(41, 22, 1), 
(41, 23, 1), 
(41, 24, 1), 
(41, 25, 1), 
(41, 26, 1), 
(41, 27, 1), 
(41, 56, 1), 
(44, 4, 1), 
(45, 4, 2), 
(52, 69, 1), 
(52, 85, 1), 
(52, 64, 1), 
(52, 78, 1), 
(52, 59, 1), 
(52, 70, 1), 
(52, 71, 1), 
(52, 62, 1), 
(52, 67, 1), 
(52, 66, 1), 
(52, 79, 1), 
(52, 61, 1), 
(52, 86, 1), 
(52, 84, 1), 
(52, 72, 1), 
(52, 82, 1), 
(52, 65, 1), 
(56, 69, 1), 
(56, 85, 1), 
(56, 64, 1), 
(56, 78, 1), 
(56, 59, 1), 
(56, 70, 1), 
(56, 71, 1), 
(56, 62, 1), 
(56, 67, 1), 
(56, 66, 1), 
(56, 79, 1), 
(56, 61, 1), 
(56, 86, 1), 
(56, 84, 1), 
(56, 72, 1), 
(56, 82, 1), 
(56, 65, 1), 
(58, 69, 1), 
(58, 85, 1), 
(58, 64, 1), 
(58, 78, 1), 
(58, 59, 1), 
(58, 70, 1), 
(58, 71, 1), 
(58, 62, 1), 
(58, 67, 1), 
(58, 66, 1), 
(58, 79, 1), 
(58, 61, 1), 
(58, 86, 1), 
(58, 84, 1), 
(58, 72, 1), 
(58, 82, 1), 
(58, 65, 1), 
(59, 69, 1), 
(59, 85, 1), 
(59, 64, 1), 
(59, 78, 1), 
(59, 59, 1), 
(59, 70, 1), 
(59, 71, 1), 
(59, 62, 1), 
(59, 67, 1), 
(59, 66, 1), 
(59, 79, 1), 
(59, 61, 1), 
(59, 86, 1), 
(59, 84, 1), 
(59, 72, 1), 
(59, 82, 1), 
(59, 65, 1), 
(60, 69, 1), 
(60, 85, 1), 
(60, 64, 1), 
(60, 78, 1), 
(60, 59, 1), 
(60, 70, 1), 
(60, 71, 1), 
(60, 62, 1), 
(60, 67, 1), 
(60, 66, 1), 
(60, 79, 1), 
(60, 61, 1), 
(60, 86, 1), 
(60, 84, 1), 
(60, 72, 1), 
(60, 82, 1), 
(60, 65, 1), 
(61, 69, 1), 
(61, 85, 1), 
(61, 64, 1), 
(61, 78, 1), 
(61, 59, 1), 
(61, 70, 1), 
(61, 71, 1), 
(61, 62, 1), 
(61, 67, 1), 
(61, 66, 1), 
(61, 79, 1), 
(61, 61, 1), 
(61, 86, 1), 
(61, 84, 1), 
(61, 72, 1), 
(61, 82, 1), 
(61, 65, 1), 
(62, 69, 1), 
(62, 85, 1), 
(62, 64, 1), 
(62, 78, 1), 
(62, 59, 1), 
(62, 70, 1), 
(62, 71, 1), 
(62, 62, 1), 
(62, 67, 1), 
(62, 66, 1), 
(62, 79, 1), 
(62, 61, 1), 
(62, 86, 1), 
(62, 84, 1), 
(62, 72, 1), 
(62, 82, 1), 
(62, 65, 1), 
(63, 69, 1), 
(63, 85, 1), 
(63, 64, 1), 
(63, 78, 1), 
(63, 59, 1), 
(63, 70, 1), 
(63, 71, 1), 
(63, 62, 1), 
(63, 67, 1), 
(63, 66, 1), 
(63, 79, 1), 
(63, 61, 1), 
(63, 86, 1), 
(63, 84, 1), 
(63, 72, 1), 
(63, 82, 1), 
(63, 65, 1), 
(63, 1, 1), 
(63, 4, 1), 
(63, 5, 1), 
(63, 6, 1), 
(63, 7, 1), 
(63, 8, 1), 
(63, 9, 1), 
(63, 10, 1), 
(63, 11, 1), 
(63, 12, 1), 
(63, 18, 1), 
(63, 19, 1), 
(63, 20, 1), 
(63, 21, 1), 
(63, 22, 1), 
(63, 23, 1), 
(63, 24, 1), 
(63, 25, 1), 
(63, 26, 1), 
(63, 27, 1), 
(63, 55, 1), 
(63, 29, 1), 
(63, 30, 1), 
(63, 31, 1), 
(63, 32, 1), 
(63, 33, 1), 
(63, 34, 1), 
(63, 35, 1), 
(63, 56, 1), 
(63, 36, 1), 
(63, 37, 1), 
(63, 38, 1), 
(63, 39, 1), 
(63, 57, 1), 
(63, 58, 1), 
(63, 49, 1), 
(63, 45, 1), 
(63, 46, 1), 
(63, 47, 1), 
(63, 48, 1), 
(63, 52, 1), 
(63, 53, 1), 
(64, 69, 1), 
(64, 85, 1), 
(64, 64, 1), 
(64, 78, 1), 
(64, 59, 1), 
(64, 70, 1), 
(64, 71, 1), 
(64, 62, 1), 
(64, 67, 1), 
(64, 66, 1), 
(64, 79, 1), 
(64, 61, 1), 
(64, 86, 1), 
(64, 84, 1), 
(64, 72, 1), 
(64, 82, 1), 
(64, 65, 1), 
(64, 1, 1), 
(64, 4, 1), 
(64, 5, 1), 
(64, 6, 1), 
(64, 7, 1), 
(64, 8, 1), 
(64, 9, 1), 
(64, 10, 1), 
(64, 11, 1), 
(64, 12, 1), 
(64, 18, 1), 
(64, 19, 1), 
(64, 20, 1), 
(64, 21, 1), 
(64, 22, 1), 
(64, 23, 1), 
(64, 24, 1), 
(64, 25, 1), 
(64, 26, 1), 
(64, 27, 1), 
(64, 55, 1), 
(64, 29, 1), 
(64, 30, 1), 
(64, 31, 1), 
(64, 32, 1), 
(64, 33, 1), 
(64, 34, 1), 
(64, 35, 1), 
(64, 56, 1), 
(64, 36, 1), 
(64, 37, 1), 
(64, 38, 1), 
(64, 39, 1), 
(64, 57, 1), 
(64, 58, 1), 
(64, 49, 1), 
(64, 45, 1), 
(64, 46, 1), 
(64, 47, 1), 
(64, 48, 1), 
(64, 52, 1), 
(64, 53, 1), 
(65, 69, 1), 
(65, 85, 1), 
(65, 64, 1), 
(65, 78, 1), 
(65, 59, 1), 
(65, 70, 1), 
(65, 71, 1), 
(65, 62, 1), 
(65, 67, 1), 
(65, 66, 1), 
(65, 79, 1), 
(65, 61, 1), 
(65, 86, 1), 
(65, 84, 1), 
(65, 72, 1), 
(65, 82, 1), 
(65, 65, 1), 
(65, 1, 1), 
(65, 4, 1), 
(65, 5, 1), 
(65, 6, 1), 
(65, 7, 1), 
(65, 8, 1), 
(65, 9, 1), 
(65, 10, 1), 
(65, 11, 1), 
(65, 12, 1), 
(65, 18, 1), 
(65, 19, 1), 
(65, 20, 1), 
(65, 21, 1), 
(65, 22, 1), 
(65, 23, 1), 
(65, 24, 1), 
(65, 25, 1), 
(65, 26, 1), 
(65, 27, 1), 
(65, 55, 1), 
(65, 29, 1), 
(65, 30, 1), 
(65, 31, 1), 
(65, 32, 1), 
(65, 33, 1), 
(65, 34, 1), 
(65, 35, 1), 
(65, 56, 1), 
(65, 36, 1), 
(65, 37, 1), 
(65, 38, 1), 
(65, 39, 1), 
(65, 57, 1), 
(65, 58, 1), 
(65, 49, 1), 
(65, 45, 1), 
(65, 46, 1), 
(65, 47, 1), 
(65, 48, 1), 
(65, 52, 1), 
(65, 53, 1), 
(66, 1, 3), 
(67, 1, 2), 
(28, 91, 1), 
(28, 101, 1), 
(28, 100, 1), 
(28, 90, 1), 
(28, 89, 1), 
(28, 96, 1), 
(28, 88, 1), 
(28, 99, 1), 
(28, 94, 1), 
(29, 91, 1), 
(29, 101, 1), 
(29, 100, 1), 
(29, 90, 1), 
(29, 89, 1), 
(29, 96, 1), 
(29, 88, 1), 
(29, 99, 1), 
(29, 94, 1), 
(31, 91, 1), 
(31, 101, 1), 
(31, 100, 1), 
(31, 90, 1), 
(31, 89, 1), 
(31, 96, 1), 
(31, 88, 1), 
(31, 99, 1), 
(31, 94, 1), 
(32, 91, 2), 
(32, 101, 2), 
(32, 100, 2), 
(32, 90, 2), 
(32, 89, 2), 
(32, 96, 2), 
(32, 88, 2), 
(32, 99, 2), 
(32, 94, 2), 
(35, 91, 1), 
(35, 101, 1), 
(35, 100, 1), 
(35, 90, 1), 
(35, 89, 1), 
(35, 96, 1), 
(35, 88, 1), 
(35, 99, 1), 
(35, 94, 1), 
(36, 91, 1), 
(36, 101, 1), 
(36, 100, 1), 
(36, 90, 1), 
(36, 89, 1), 
(36, 96, 1), 
(36, 88, 1), 
(36, 99, 1), 
(36, 94, 1), 
(37, 91, 1), 
(37, 101, 1), 
(37, 100, 1), 
(37, 90, 1), 
(37, 89, 1), 
(37, 96, 1), 
(37, 88, 1), 
(37, 99, 1), 
(37, 94, 1), 
(63, 91, 1), 
(63, 101, 1), 
(63, 100, 1), 
(63, 90, 1), 
(63, 89, 1), 
(63, 96, 1), 
(63, 88, 1), 
(63, 99, 1), 
(63, 94, 1), 
(65, 91, 1), 
(65, 101, 1), 
(65, 100, 1), 
(65, 90, 1), 
(65, 89, 1), 
(65, 96, 1), 
(65, 88, 1), 
(65, 99, 1), 
(65, 94, 1), 
(39, 91, 1), 
(39, 101, 1), 
(39, 100, 1), 
(39, 90, 1), 
(39, 89, 1), 
(39, 96, 1), 
(39, 88, 1), 
(39, 99, 1), 
(39, 94, 1), 
(40, 91, 2), 
(40, 101, 2), 
(40, 100, 2), 
(40, 90, 2), 
(40, 89, 2), 
(40, 96, 2), 
(40, 88, 2), 
(40, 99, 2), 
(40, 94, 2), 
(41, 91, 1), 
(41, 101, 1), 
(41, 100, 1), 
(41, 90, 1), 
(41, 89, 1), 
(41, 96, 1), 
(41, 88, 1), 
(41, 99, 1), 
(41, 94, 1), 
(64, 91, 1), 
(64, 101, 1), 
(64, 100, 1), 
(64, 90, 1), 
(64, 89, 1), 
(64, 96, 1), 
(64, 88, 1), 
(64, 99, 1), 
(64, 94, 1), 
(13, 91, 1), 
(13, 101, 1), 
(13, 100, 1), 
(13, 90, 1), 
(13, 89, 1), 
(13, 96, 1), 
(13, 88, 1), 
(13, 99, 1), 
(13, 94, 1), 
(15, 91, 1), 
(15, 101, 1), 
(15, 100, 1), 
(15, 90, 1), 
(15, 89, 1), 
(15, 96, 1), 
(15, 88, 1), 
(15, 99, 1), 
(15, 94, 1), 
(18, 91, 1), 
(18, 101, 1), 
(18, 100, 1), 
(18, 90, 1), 
(18, 89, 1), 
(18, 96, 1), 
(18, 88, 1), 
(18, 99, 1), 
(18, 94, 1), 
(8, 91, 1), 
(8, 101, 1), 
(8, 100, 1), 
(8, 90, 1), 
(8, 89, 1), 
(8, 96, 1), 
(8, 88, 1), 
(8, 99, 1), 
(8, 94, 1), 
(9, 91, 2), 
(9, 101, 2), 
(9, 100, 2), 
(9, 90, 2), 
(9, 89, 2), 
(9, 96, 2), 
(9, 88, 2), 
(9, 99, 2), 
(9, 94, 2), 
(5, 91, 1), 
(5, 101, 1), 
(5, 100, 1), 
(5, 90, 1), 
(5, 89, 1), 
(5, 96, 1), 
(5, 88, 1), 
(5, 99, 1), 
(5, 94, 1), 
(17, 91, 1), 
(17, 101, 1), 
(17, 100, 1), 
(17, 90, 1), 
(17, 89, 1), 
(17, 96, 1), 
(17, 88, 1), 
(17, 99, 1), 
(17, 94, 1), 
(14, 91, 1), 
(14, 101, 1), 
(14, 100, 1), 
(14, 90, 1), 
(14, 89, 1), 
(14, 96, 1), 
(14, 88, 1), 
(14, 99, 1), 
(14, 94, 1), 
(12, 91, 1), 
(12, 101, 1), 
(12, 100, 1), 
(12, 90, 1), 
(12, 89, 1), 
(12, 96, 1), 
(12, 88, 1), 
(12, 99, 1), 
(12, 94, 1), 
(10, 91, 1), 
(10, 101, 1), 
(10, 100, 1), 
(10, 90, 1), 
(10, 89, 1), 
(10, 96, 1), 
(10, 88, 1), 
(10, 99, 1), 
(10, 94, 1), 
(11, 91, 2), 
(11, 101, 2), 
(11, 100, 2), 
(11, 90, 2), 
(11, 89, 2), 
(11, 96, 2), 
(11, 88, 2), 
(11, 99, 2), 
(11, 94, 2), 
(6, 91, 1), 
(6, 101, 1), 
(6, 100, 1), 
(6, 90, 1), 
(6, 89, 1), 
(6, 96, 1), 
(6, 88, 1), 
(6, 99, 1), 
(6, 94, 1), 
(7, 91, 2), 
(7, 101, 2), 
(7, 100, 2), 
(7, 90, 2), 
(7, 89, 2), 
(7, 96, 2), 
(7, 88, 2), 
(7, 99, 2), 
(7, 94, 2), 
(16, 91, 1), 
(16, 101, 1), 
(16, 100, 1), 
(16, 90, 1), 
(16, 89, 1), 
(16, 96, 1), 
(16, 88, 1), 
(16, 99, 1), 
(16, 94, 1), 
(27, 91, 1), 
(27, 101, 1), 
(27, 100, 1), 
(27, 90, 1), 
(27, 89, 1), 
(27, 96, 1), 
(27, 88, 1), 
(27, 99, 1), 
(27, 94, 1), 
(25, 91, 1), 
(25, 101, 1), 
(25, 100, 1), 
(25, 90, 1), 
(25, 89, 1), 
(25, 96, 1), 
(25, 88, 1), 
(25, 99, 1), 
(25, 94, 1), 
(26, 91, 1), 
(26, 101, 1), 
(26, 100, 1), 
(26, 90, 1), 
(26, 89, 1), 
(26, 96, 1), 
(26, 88, 1), 
(26, 99, 1), 
(26, 94, 1), 
(19, 91, 1), 
(19, 101, 1), 
(19, 100, 1), 
(19, 90, 1), 
(19, 89, 1), 
(19, 96, 1), 
(19, 88, 1), 
(19, 99, 1), 
(19, 94, 1), 
(20, 91, 2), 
(20, 101, 2), 
(20, 100, 2), 
(20, 90, 2), 
(20, 89, 2), 
(20, 96, 2), 
(20, 88, 2), 
(20, 99, 2), 
(20, 94, 2), 
(21, 91, 1), 
(21, 101, 1), 
(21, 100, 1), 
(21, 90, 1), 
(21, 89, 1), 
(21, 96, 1), 
(21, 88, 1), 
(21, 99, 1), 
(21, 94, 1), 
(22, 91, 2), 
(22, 101, 2), 
(22, 100, 2), 
(22, 90, 2), 
(22, 89, 2), 
(22, 96, 2), 
(22, 88, 2), 
(22, 99, 2), 
(22, 94, 2), 
(23, 91, 3), 
(23, 101, 3), 
(23, 100, 3), 
(23, 90, 3), 
(23, 89, 3), 
(23, 96, 3), 
(23, 88, 3), 
(23, 99, 3), 
(23, 94, 3), 
(24, 91, 4), 
(24, 101, 4), 
(24, 100, 4), 
(24, 90, 4), 
(24, 89, 4), 
(24, 96, 4), 
(24, 88, 4), 
(24, 99, 4), 
(24, 94, 4);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_comment`
--

DROP TABLE IF EXISTS `nv4_vi_comment`;
CREATE TABLE `nv4_vi_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_department`
--

DROP TABLE IF EXISTS `nv4_vi_contact_department`;
CREATE TABLE `nv4_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `others` text NOT NULL,
  `cats` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_contact_department`
--

INSERT INTO `nv4_vi_contact_department` VALUES
(1, 'Phòng Chăm sóc khách hàng', 'Cham-soc-khach-hang', '(08) 38.000.000[+84838000000]', '08 38.000.001', 'customer@mysite.com', '', 'Bộ phận tiếp nhận và giải quyết các yêu cầu, đề nghị, ý kiến liên quan đến hoạt động chính của doanh nghiệp', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Tư vấn|Khiếu nại, phản ánh|Đề nghị hợp tác', '1/1/1/0;', 1, 1, 1), 
(2, 'Phòng Kỹ thuật', 'Ky-thuat', '(08) 38.000.002[+84838000002]', '08 38.000.003', 'technical@mysite.com', '', 'Bộ phận tiếp nhận và giải quyết các câu hỏi liên quan đến kỹ thuật', '{\"viber\":\"myViber2\",\"skype\":\"mySkype2\",\"yahoo\":\"myYahoo2\"}', 'Thông báo lỗi|Góp ý cải tiến', '1/1/1/0;', 1, 2, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_reply`
--

DROP TABLE IF EXISTS `nv4_vi_contact_reply`;
CREATE TABLE `nv4_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_send`
--

DROP TABLE IF EXISTS `nv4_vi_contact_send`;
CREATE TABLE `nv4_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(20) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_freecontent_blocks`
--

DROP TABLE IF EXISTS `nv4_vi_freecontent_blocks`;
CREATE TABLE `nv4_vi_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_freecontent_blocks`
--

INSERT INTO `nv4_vi_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_freecontent_rows`
--

DROP TABLE IF EXISTS `nv4_vi_freecontent_rows`;
CREATE TABLE `nv4_vi_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255) NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_freecontent_rows`
--

INSERT INTO `nv4_vi_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'nukeviet.jpg', 1459471000, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'nukeviet-portal.jpg', 1459471000, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'nukeviet-edu.jpg', 1459471000, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'nukeviet-toasoan.jpg', 1459471000, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu`
--

DROP TABLE IF EXISTS `nv4_vi_menu`;
CREATE TABLE `nv4_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu`
--

INSERT INTO `nv4_vi_menu` VALUES
(1, 'Top Menu'), 
(2, 'menu_top'), 
(3, 'Menu_bakery'), 
(4, 'footer_menu'), 
(5, 'Opening Hours');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv4_vi_menu_rows`;
CREATE TABLE `nv4_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=44  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu_rows`
--

INSERT INTO `nv4_vi_menu_rows` VALUES
(1, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 1, 1, 0, '2,3,4,5,6,7,8,9', '6', 'about', '', 1, '', 1, 1), 
(2, 1, 1, 'Giới thiệu về NukeViet', '/index.php?language=vi&nv=about&op=gioi-thieu-ve-nukeviet.html', '', '', 1, 2, 1, '', '6', 'about', 'gioi-thieu-ve-nukeviet.html', 1, '', 0, 1), 
(3, 1, 1, 'Giới thiệu về NukeViet CMS', '/index.php?language=vi&nv=about&op=gioi-thieu-ve-nukeviet-cms.html', '', '', 2, 3, 1, '', '6', 'about', 'gioi-thieu-ve-nukeviet-cms.html', 1, '', 0, 1), 
(4, 1, 1, 'Logo và tên gọi NukeViet', '/index.php?language=vi&nv=about&op=logo-va-ten-goi-nukeviet.html', '', '', 3, 4, 1, '', '6', 'about', 'logo-va-ten-goi-nukeviet.html', 1, '', 0, 1), 
(5, 1, 1, 'Giấy phép sử dụng NukeViet', '/index.php?language=vi&nv=about&op=giay-phep-su-dung-nukeviet.html', '', '', 4, 5, 1, '', '6', 'about', 'giay-phep-su-dung-nukeviet.html', 1, '', 0, 1), 
(6, 1, 1, 'Những tính năng của NukeViet CMS 4.0', '/index.php?language=vi&nv=about&op=nhung-tinh-nang-cua-nukeviet-cms-4-0.html', '', '', 5, 6, 1, '', '6', 'about', 'nhung-tinh-nang-cua-nukeviet-cms-4-0.html', 1, '', 0, 1), 
(7, 1, 1, 'Các yêu cầu cài đặt', '/index.php?language=vi&nv=about&op=cac-yeu-cau-cai-dat.html', '', '', 6, 7, 1, '', '6', 'about', 'cac-yeu-cau-cai-dat.html', 1, '', 0, 1), 
(8, 1, 1, 'Giới thiệu về Công ty cổ phần phát triển nguồn mở Việt Nam', '/index.php?language=vi&nv=about&op=gioi-thieu-ve-cong-ty-co-phan-phat-trien-nguon-mo-viet-nam.html', '', '', 7, 8, 1, '', '6', 'about', 'gioi-thieu-ve-cong-ty-co-phan-phat-trien-nguon-mo-viet-nam.html', 1, '', 0, 1), 
(9, 1, 1, 'Ủng hộ, hỗ trợ và tham gia phát triển NukeViet', '/index.php?language=vi&nv=about&op=ung-ho-ho-tro-va-tham-gia-phat-trien-nukeviet.html', '', '', 8, 9, 1, '', '6', 'about', 'ung-ho-ho-tro-va-tham-gia-phat-trien-nukeviet.html', 1, '', 0, 1), 
(10, 0, 1, 'Tin Tức', '/index.php?language=vi&nv=news', '', '', 2, 10, 0, '11,12,13,14,15,16,17', '6', 'news', '', 1, '', 1, 1), 
(11, 10, 1, 'Đối tác', '/index.php?language=vi&nv=news&amp;op=Doi-tac', '', '', 1, 11, 1, '', '6', 'news', 'Doi-tac', 1, '', 1, 1), 
(12, 10, 1, 'Tuyển dụng', '/index.php?language=vi&nv=news&amp;op=Tuyen-dung', '', '', 2, 12, 1, '', '6', 'news', 'Tuyen-dung', 1, '', 1, 1), 
(13, 10, 1, 'Rss', '/index.php?language=vi&nv=news&op=rss', '', '', 3, 13, 1, '', '6', 'news', 'rss', 1, '', 0, 1), 
(14, 10, 1, 'Đăng bài viết', '/index.php?language=vi&nv=news&op=content', '', '', 4, 14, 1, '', '6', 'news', 'content', 1, '', 0, 1), 
(15, 10, 1, 'Tìm kiếm', '/index.php?language=vi&nv=news&op=search', '', '', 5, 15, 1, '', '6', 'news', 'search', 1, '', 0, 1), 
(16, 10, 1, 'Tin tức', '/index.php?language=vi&nv=news&amp;op=Tin-tuc', '', '', 6, 16, 1, '', '6', 'news', 'Tin-tuc', 1, '', 1, 1), 
(17, 10, 1, 'Sản phẩm', '/index.php?language=vi&nv=news&amp;op=San-pham', '', '', 7, 17, 1, '', '6', 'news', 'San-pham', 1, '', 1, 1), 
(18, 0, 1, 'Thành viên', '/index.php?language=vi&nv=users', '', '', 3, 18, 0, '', '6', 'users', '', 1, '', 1, 1), 
(19, 0, 1, 'Thống kê', '/index.php?language=vi&nv=statistics', '', '', 4, 19, 0, '', '2', 'statistics', '', 1, '', 1, 1), 
(20, 0, 1, 'Thăm dò ý kiến', '/index.php?language=vi&nv=voting', '', '', 5, 20, 0, '', '6', 'voting', '', 1, '', 1, 1), 
(21, 0, 1, 'Tìm kiếm', '/index.php?language=vi&nv=seek', '', '', 6, 21, 0, '', '6', 'seek', '', 1, '', 1, 1), 
(22, 0, 1, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 7, 22, 0, '', '6', 'contact', '', 1, '', 1, 1), 
(23, 0, 2, 'My Account', '#', '', '', 1, 1, 0, '', '6', '0', '', 1, '', 0, 1), 
(24, 0, 2, 'My Wishlist', '#', '', '', 2, 2, 0, '', '6', '0', '', 1, '', 0, 1), 
(25, 0, 2, 'My Cart', '#', '', '', 3, 3, 0, '', '6', '0', '', 1, '', 0, 1), 
(26, 0, 2, 'Checkout', '#', '', '', 4, 4, 0, '', '6', '0', '', 1, '', 0, 1), 
(27, 0, 2, 'Login', '#', '', '', 5, 5, 0, '', '6', '0', '', 1, '', 0, 1), 
(28, 0, 2, 'English', '#', '', '', 6, 6, 0, '', '6', '0', '', 1, '', 0, 1), 
(29, 0, 3, 'Home', '/index.php?language=vi', '', '', 1, 1, 0, '', '6', '0', '', 1, '', 0, 1), 
(30, 0, 3, 'Product Types', '#', '', '', 2, 2, 0, '43', '6', '0', '', 1, '', 0, 1), 
(31, 0, 3, 'Paris Gateaux', '#', '', '', 3, 4, 0, '', '6', '0', '', 1, '', 0, 1), 
(32, 0, 3, 'Our Cake', '#', '', '', 4, 5, 0, '', '6', '0', '', 1, '', 0, 1), 
(33, 0, 3, 'About Us', '/index.php?language=vi&nv=about', '', '', 5, 6, 0, '', '6', 'about', '', 1, '', 0, 1), 
(34, 0, 3, 'Contact', '/index.php?language=vi&nv=contact', '', '', 6, 7, 0, '', '6', 'contact', '', 1, '', 0, 1), 
(35, 0, 4, 'Shipping &amp; Returns', '#', '', '', 1, 1, 0, '', '6', '0', '', 1, '', 0, 1), 
(36, 0, 4, 'Secure Shopping', '#', '', '', 2, 2, 0, '', '6', '0', '', 1, '', 0, 1), 
(37, 0, 4, 'International Shipping', '#', '', '', 3, 3, 0, '', '6', '0', '', 1, '', 0, 1), 
(38, 0, 4, 'Affiliates', '#', '', '', 4, 4, 0, '', '6', '0', '', 1, '', 0, 1), 
(39, 0, 4, 'Group Sales', '#', '', '', 5, 5, 0, '', '6', '0', '', 1, '', 0, 1), 
(40, 0, 5, 'MON to TUE - 10 AM to 10 PM', '#', '', '', 1, 1, 0, '', '6', '0', '', 1, '', 0, 1), 
(41, 0, 5, 'SAT - 12 AM to 12 PM', '#', '', '', 2, 2, 0, '', '6', '0', '', 1, '', 0, 1), 
(42, 0, 5, 'SUN - 12 AM to 12 PM', '#', '', '', 3, 3, 0, '', '6', '0', '', 1, '', 0, 1), 
(43, 30, 3, 'demo', '#', '', '', 1, 3, 1, '', '6', '0', '', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv4_vi_modfuncs`;
CREATE TABLE `nv4_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=102  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modfuncs`
--

INSERT INTO `nv4_vi_modfuncs` VALUES
(1, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', 'about', 0, 0, 0, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Đăng ký', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Kích hoạt', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Thiếp lập tài khoản', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Thoát', 'users', 1, 1, 10, ''), 
(28, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(29, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(30, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(31, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(32, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(33, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(34, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(35, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(36, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(37, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(38, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(39, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(40, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(41, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(42, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(43, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(46, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(47, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(48, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(49, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(50, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(51, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''), 
(52, 'main', 'main', 'Main', 'siteterms', 1, 0, 1, ''), 
(53, 'rss', 'rss', 'Rss', 'siteterms', 1, 0, 2, ''), 
(54, 'sitemap', 'sitemap', 'Sitemap', 'siteterms', 0, 0, 0, ''), 
(55, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(56, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(59, 'cart', 'cart', 'Cart', 'shops', 1, 0, 5, ''), 
(60, 'checkorder', 'checkorder', 'Checkorder', 'shops', 0, 0, 0, ''), 
(61, 'compare', 'compare', 'Compare', 'shops', 1, 0, 12, ''), 
(62, 'complete', 'complete', 'Complete', 'shops', 1, 0, 8, ''), 
(63, 'delhis', 'delhis', 'Delhis', 'shops', 0, 0, 0, ''), 
(64, 'detail', 'detail', 'Detail', 'shops', 1, 0, 3, ''), 
(65, 'download', 'download', 'Download', 'shops', 1, 0, 17, ''), 
(66, 'group', 'group', 'Group', 'shops', 1, 0, 10, ''), 
(67, 'history', 'history', 'History', 'shops', 1, 0, 9, ''), 
(68, 'loadcart', 'loadcart', 'Loadcart', 'shops', 0, 0, 0, ''), 
(69, 'main', 'main', 'Main', 'shops', 1, 0, 1, ''), 
(70, 'order', 'order', 'Order', 'shops', 1, 0, 6, ''), 
(71, 'payment', 'payment', 'Payment', 'shops', 1, 0, 7, ''), 
(72, 'point', 'point', 'Point', 'shops', 1, 0, 15, ''), 
(73, 'print', 'print', 'Print', 'shops', 0, 0, 0, ''), 
(74, 'print_pro', 'print_pro', 'Print_pro', 'shops', 0, 0, 0, ''), 
(75, 'remove', 'remove', 'Remove', 'shops', 0, 0, 0, ''), 
(76, 'review', 'review', 'Review', 'shops', 0, 0, 0, ''), 
(77, 'rss', 'rss', 'Rss', 'shops', 0, 0, 0, ''), 
(78, 'search', 'search', 'Search', 'shops', 1, 0, 4, ''), 
(79, 'search_result', 'search_result', 'Search_result', 'shops', 1, 0, 11, ''), 
(80, 'sendmail', 'sendmail', 'Sendmail', 'shops', 0, 0, 0, ''), 
(81, 'setcart', 'setcart', 'Setcart', 'shops', 0, 0, 0, ''), 
(82, 'shippingajax', 'shippingajax', 'Shippingajax', 'shops', 1, 0, 16, ''), 
(83, 'sitemap', 'sitemap', 'Sitemap', 'shops', 0, 0, 0, ''), 
(84, 'tag', 'tag', 'Tag', 'shops', 1, 0, 14, ''), 
(85, 'viewcat', 'viewcat', 'Viewcat', 'shops', 1, 0, 2, ''), 
(86, 'wishlist', 'wishlist', 'Wishlist', 'shops', 1, 0, 13, ''), 
(87, 'wishlist_update', 'wishlist_update', 'Wishlist_update', 'shops', 0, 0, 0, ''), 
(88, 'content', 'content', 'Content', 'new2', 1, 1, 7, ''), 
(89, 'detail', 'detail', 'Detail', 'new2', 1, 0, 5, ''), 
(90, 'groups', 'groups', 'Groups', 'new2', 1, 0, 4, ''), 
(91, 'main', 'main', 'Main', 'new2', 1, 0, 1, ''), 
(92, 'print', 'print', 'Print', 'new2', 0, 0, 0, ''), 
(93, 'rating', 'rating', 'Rating', 'new2', 0, 0, 0, ''), 
(94, 'rss', 'rss', 'Rss', 'new2', 1, 1, 9, ''), 
(95, 'savefile', 'savefile', 'Savefile', 'new2', 0, 0, 0, ''), 
(96, 'search', 'search', 'Search', 'new2', 1, 1, 6, ''), 
(97, 'sendmail', 'sendmail', 'Sendmail', 'new2', 0, 0, 0, ''), 
(98, 'sitemap', 'sitemap', 'Sitemap', 'new2', 0, 0, 0, ''), 
(99, 'tag', 'tag', 'Tag', 'new2', 1, 0, 8, ''), 
(100, 'topic', 'topic', 'Topic', 'new2', 1, 0, 3, ''), 
(101, 'viewcat', 'viewcat', 'Viewcat', 'new2', 1, 0, 2, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modthemes`
--

DROP TABLE IF EXISTS `nv4_vi_modthemes`;
CREATE TABLE `nv4_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modthemes`
--

INSERT INTO `nv4_vi_modthemes` VALUES
(0, 'body', 'mobile_default'), 
(0, 'left-body-right', 'bakery'), 
(0, 'left-body-right', 'default'), 
(1, 'body', 'mobile_default'), 
(1, 'body-right', 'bakery'), 
(1, 'left-body-right', 'default'), 
(4, 'body', 'mobile_default'), 
(4, 'left-body-right', 'bakery'), 
(4, 'left-body-right', 'default'), 
(5, 'body', 'mobile_default'), 
(5, 'left-body-right', 'bakery'), 
(5, 'left-body-right', 'default'), 
(6, 'body', 'mobile_default'), 
(6, 'left-body-right', 'bakery'), 
(6, 'left-body-right', 'default'), 
(7, 'body', 'mobile_default'), 
(7, 'left-body-right', 'bakery'), 
(7, 'left-body-right', 'default'), 
(8, 'body', 'mobile_default'), 
(8, 'left-body-right', 'bakery'), 
(8, 'left-body-right', 'default'), 
(9, 'body', 'mobile_default'), 
(9, 'left-body-right', 'bakery'), 
(9, 'left-body-right', 'default'), 
(10, 'left-body-right', 'bakery'), 
(10, 'left-body-right', 'default'), 
(11, 'body', 'mobile_default'), 
(11, 'left-body-right', 'bakery'), 
(11, 'left-body-right', 'default'), 
(12, 'body', 'mobile_default'), 
(12, 'left-body-right', 'bakery'), 
(12, 'left-body-right', 'default'), 
(18, 'body', 'mobile_default'), 
(18, 'left-body-right', 'bakery'), 
(18, 'left-body-right', 'default'), 
(19, 'body', 'mobile_default'), 
(19, 'left-body-right', 'bakery'), 
(19, 'left-body-right', 'default'), 
(20, 'body', 'mobile_default'), 
(20, 'left-body-right', 'bakery'), 
(20, 'left-body-right', 'default'), 
(21, 'body', 'mobile_default'), 
(21, 'left-body-right', 'bakery'), 
(21, 'left-body-right', 'default'), 
(22, 'body', 'mobile_default'), 
(22, 'left-body-right', 'bakery'), 
(22, 'left-body-right', 'default'), 
(23, 'body', 'mobile_default'), 
(23, 'left-body-right', 'bakery'), 
(23, 'left-body-right', 'default'), 
(24, 'body', 'mobile_default'), 
(24, 'left-body', 'default'), 
(24, 'left-body-right', 'bakery'), 
(25, 'body', 'mobile_default'), 
(25, 'left-body-right', 'bakery'), 
(25, 'left-body-right', 'default'), 
(26, 'left-body-right', 'bakery'), 
(26, 'left-body-right', 'default'), 
(27, 'body', 'mobile_default'), 
(27, 'left-body-right', 'bakery'), 
(27, 'left-body-right', 'default'), 
(29, 'body', 'mobile_default'), 
(29, 'left-body', 'default'), 
(29, 'left-body-right', 'bakery'), 
(30, 'body', 'mobile_default'), 
(30, 'left-body', 'default'), 
(30, 'left-body-right', 'bakery'), 
(31, 'body', 'mobile_default'), 
(31, 'left-body', 'default'), 
(31, 'left-body-right', 'bakery'), 
(32, 'body', 'mobile_default'), 
(32, 'left-body', 'default'), 
(32, 'left-body-right', 'bakery'), 
(33, 'body', 'mobile_default'), 
(33, 'left-body', 'default'), 
(33, 'left-body-right', 'bakery'), 
(34, 'body', 'mobile_default'), 
(34, 'left-body', 'default'), 
(34, 'left-body-right', 'bakery'), 
(35, 'body', 'mobile_default'), 
(35, 'left-body', 'default'), 
(35, 'left-body-right', 'bakery'), 
(36, 'body', 'mobile_default'), 
(36, 'left-body-right', 'bakery'), 
(36, 'left-body-right', 'default'), 
(37, 'body', 'mobile_default'), 
(37, 'left-body-right', 'bakery'), 
(37, 'left-body-right', 'default'), 
(38, 'body', 'mobile_default'), 
(38, 'left-body-right', 'bakery'), 
(38, 'left-body-right', 'default'), 
(39, 'body', 'mobile_default'), 
(39, 'left-body-right', 'bakery'), 
(39, 'left-body-right', 'default'), 
(45, 'body', 'mobile_default'), 
(45, 'left-body-right', 'bakery'), 
(45, 'left-body-right', 'default'), 
(46, 'body', 'mobile_default'), 
(46, 'left-body-right', 'bakery'), 
(46, 'left-body-right', 'default'), 
(47, 'body', 'mobile_default'), 
(47, 'left-body-right', 'bakery'), 
(47, 'left-body-right', 'default'), 
(48, 'body', 'mobile_default'), 
(48, 'left-body-right', 'bakery'), 
(48, 'left-body-right', 'default'), 
(49, 'body', 'mobile_default'), 
(49, 'left-body', 'default'), 
(49, 'left-body-right', 'bakery'), 
(52, 'body', 'mobile_default'), 
(52, 'left-body-right', 'bakery'), 
(52, 'left-body-right', 'default'), 
(53, 'body', 'mobile_default'), 
(53, 'left-body-right', 'bakery'), 
(53, 'left-body-right', 'default'), 
(55, 'body', 'mobile_default'), 
(55, 'left-body', 'bakery'), 
(55, 'left-body', 'default'), 
(56, 'body', 'mobile_default'), 
(56, 'left-body', 'default'), 
(56, 'left-body-right', 'bakery'), 
(57, 'body', 'mobile_default'), 
(57, 'left-body-right', 'bakery'), 
(57, 'left-body-right', 'default'), 
(58, 'body', 'mobile_default'), 
(58, 'left-body-right', 'bakery'), 
(58, 'left-body-right', 'default'), 
(59, 'body', 'bakery'), 
(59, 'body', 'mobile_default'), 
(59, 'left-body-right', 'default'), 
(60, 'left-body-right', 'default'), 
(61, 'body', 'bakery'), 
(61, 'body', 'mobile_default'), 
(61, 'left-body-right', 'default'), 
(62, 'body', 'bakery'), 
(62, 'body', 'mobile_default'), 
(62, 'left-body-right', 'default'), 
(63, 'left-body-right', 'default'), 
(64, 'body', 'bakery'), 
(64, 'body', 'mobile_default'), 
(64, 'left-body-right', 'default'), 
(65, 'body', 'bakery'), 
(65, 'body', 'mobile_default'), 
(65, 'left-body-right', 'default'), 
(66, 'body', 'bakery'), 
(66, 'body', 'mobile_default'), 
(66, 'left-body-right', 'default'), 
(67, 'body', 'bakery'), 
(67, 'body', 'mobile_default'), 
(67, 'left-body-right', 'default'), 
(68, 'left-body-right', 'default'), 
(69, 'body', 'bakery'), 
(69, 'body', 'mobile_default'), 
(69, 'left-body-right', 'default'), 
(70, 'body', 'bakery'), 
(70, 'body', 'mobile_default'), 
(70, 'left-body-right', 'default'), 
(71, 'body', 'bakery'), 
(71, 'body', 'mobile_default'), 
(71, 'left-body-right', 'default'), 
(72, 'body', 'bakery'), 
(72, 'body', 'mobile_default'), 
(72, 'left-body-right', 'default'), 
(73, 'left-body-right', 'default'), 
(74, 'left-body-right', 'default'), 
(75, 'left-body-right', 'default'), 
(76, 'left-body-right', 'default'), 
(77, 'left-body-right', 'default'), 
(78, 'body', 'bakery'), 
(78, 'body', 'mobile_default'), 
(78, 'left-body-right', 'default'), 
(79, 'body', 'bakery'), 
(79, 'body', 'mobile_default'), 
(79, 'left-body-right', 'default'), 
(80, 'left-body-right', 'default'), 
(81, 'left-body-right', 'default'), 
(82, 'body', 'bakery'), 
(82, 'body', 'mobile_default'), 
(82, 'left-body-right', 'default'), 
(83, 'left-body-right', 'default'), 
(84, 'body', 'bakery'), 
(84, 'body', 'mobile_default'), 
(84, 'left-body-right', 'default'), 
(85, 'body', 'bakery'), 
(85, 'body', 'mobile_default'), 
(85, 'left-body-right', 'default'), 
(86, 'body', 'bakery'), 
(86, 'body', 'mobile_default'), 
(86, 'left-body-right', 'default'), 
(87, 'left-body-right', 'default'), 
(88, 'body', 'mobile_default'), 
(88, 'left-body-right', 'bakery'), 
(88, 'left-body-right', 'default'), 
(89, 'body', 'mobile_default'), 
(89, 'left-body-right', 'bakery'), 
(89, 'left-body-right', 'default'), 
(90, 'body', 'mobile_default'), 
(90, 'left-body-right', 'bakery'), 
(90, 'left-body-right', 'default'), 
(91, 'body', 'mobile_default'), 
(91, 'left-body-right', 'bakery'), 
(91, 'left-body-right', 'default'), 
(92, 'left-body-right', 'bakery'), 
(93, 'left-body-right', 'bakery'), 
(94, 'body', 'mobile_default'), 
(94, 'left-body-right', 'bakery'), 
(94, 'left-body-right', 'default'), 
(95, 'left-body-right', 'bakery'), 
(96, 'body', 'mobile_default'), 
(96, 'left-body-right', 'bakery'), 
(96, 'left-body-right', 'default'), 
(97, 'left-body-right', 'bakery'), 
(98, 'left-body-right', 'bakery'), 
(99, 'body', 'mobile_default'), 
(99, 'left-body-right', 'bakery'), 
(99, 'left-body-right', 'default'), 
(100, 'body', 'mobile_default'), 
(100, 'left-body-right', 'bakery'), 
(100, 'left-body-right', 'default'), 
(101, 'body', 'mobile_default'), 
(101, 'left-body-right', 'bakery'), 
(101, 'left-body-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modules`
--

DROP TABLE IF EXISTS `nv4_vi_modules`;
CREATE TABLE `nv4_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `module_upload` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modules`
--

INSERT INTO `nv4_vi_modules` VALUES
('about', 'page', 'about', 'about', 'Giới thiệu', '', 1459471000, 1, 1, '', '', '', '', '6', 3, 1, '', 1, 0), 
('news', 'news', 'news', 'news', 'Tin Tức', '', 1459471000, 1, 1, '', '', '', '', '6', 4, 1, '', 1, 0), 
('users', 'users', 'users', 'users', 'Thành viên', 'Tài khoản', 1459471000, 1, 1, '', '', '', '', '6', 5, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Liên hệ', '', 1459471000, 1, 1, '', '', '', '', '6', 6, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', 1459471000, 1, 1, '', '', '', 'truy cập, online, statistics', '2', 7, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1459471000, 1, 1, '', '', '', '', '6', 8, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', 1459471000, 1, 1, '', '', '', '', '6', 9, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', 1459471000, 1, 0, '', '', '', '', '6', 10, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1459471000, 0, 1, '', '', '', '', '6', 11, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1459471000, 1, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1459471000, 1, 1, '', '', '', '', '6', 13, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1459471000, 0, 1, '', '', '', '', '6', 14, 1, '', 0, 0), 
('siteterms', 'page', 'siteterms', 'siteterms', 'Điều khoản sử dụng', '', 1459471000, 1, 1, '', '', '', '', '6', 15, 1, '', 1, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Giới thiệu sản phẩm', '', 1459471000, 0, 1, '', '', '', '', '6', 2, 1, '', 0, 0), 
('shops', 'shops', 'shops', 'shops', 'shops', '', 1459471352, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0), 
('new2', 'news', 'new2', 'new2', 'new2', '', 1461314421, 1, 1, '', '', '', '', '6', 16, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_1`
--

DROP TABLE IF EXISTS `nv4_vi_new2_1`;
CREATE TABLE `nv4_vi_new2_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_1`
--

INSERT INTO `nv4_vi_new2_1` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(14, 1, '1', 0, 1, '', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(17, 1, '1', 0, 1, '', 0, 1445391217, 1445393997, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_10`
--

DROP TABLE IF EXISTS `nv4_vi_new2_10`;
CREATE TABLE `nv4_vi_new2_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_10`
--

INSERT INTO `nv4_vi_new2_10` VALUES
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_11`
--

DROP TABLE IF EXISTS `nv4_vi_new2_11`;
CREATE TABLE `nv4_vi_new2_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_11`
--

INSERT INTO `nv4_vi_new2_11` VALUES
(7, 11, '11', 0, 1, '', 2, 1307197282, 1445390968, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'tuyen-dung-lap-trinh-vien-php-phat-trien-nukeviet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '', 1, 1, '2', 1, 1, 0, 0, 0), 
(12, 11, '11', 0, 1, '', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(13, 11, '11', 0, 1, '', 0, 1445391088, 1445394191, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ, kỹ thuật viên', 'tuyen-dung-chuyen-vien-do-hoa-ky-thuat-vien', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_12`
--

DROP TABLE IF EXISTS `nv4_vi_new2_12`;
CREATE TABLE `nv4_vi_new2_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_12`
--

INSERT INTO `nv4_vi_new2_12` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_2`
--

DROP TABLE IF EXISTS `nv4_vi_new2_2`;
CREATE TABLE `nv4_vi_new2_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_8`
--

DROP TABLE IF EXISTS `nv4_vi_new2_8`;
CREATE TABLE `nv4_vi_new2_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_8`
--

INSERT INTO `nv4_vi_new2_8` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_9`
--

DROP TABLE IF EXISTS `nv4_vi_new2_9`;
CREATE TABLE `nv4_vi_new2_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_9`
--

INSERT INTO `nv4_vi_new2_9` VALUES
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_admins`
--

DROP TABLE IF EXISTS `nv4_vi_new2_admins`;
CREATE TABLE `nv4_vi_new2_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_block`
--

DROP TABLE IF EXISTS `nv4_vi_new2_block`;
CREATE TABLE `nv4_vi_new2_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_block`
--

INSERT INTO `nv4_vi_new2_block` VALUES
(1, 1, 1), 
(2, 14, 4), 
(2, 12, 6), 
(2, 6, 9), 
(2, 13, 5), 
(2, 11, 7), 
(2, 1, 8), 
(2, 15, 3), 
(2, 16, 2), 
(2, 17, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_new2_block_cat`;
CREATE TABLE `nv4_vi_new2_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_block_cat`
--

INSERT INTO `nv4_vi_new2_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_vi_new2_bodyhtml_1`;
CREATE TABLE `nv4_vi_new2_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_bodyhtml_1`
--

INSERT INTO `nv4_vi_new2_bodyhtml_1` VALUES
(1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br /> <br /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br /> <br /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br /> <br /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', 1, 0, 1, 1, 1, 0), 
(11, '<div style=\"text-align: justify;\">Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.<br  /><br  />Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những&nbsp;sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.</div><p style=\"text-align: justify;\">Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.</p><p style=\"text-align: justify;\">Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.</p><p style=\"text-align: justify;\">Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước.&nbsp;NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có&nbsp;<a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/\" target=\"_blank\">tại đây</a>.</p><p style=\"text-align: justify;\">Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải&nbsp;ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu&nbsp;như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Đồng thời,&nbsp;các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở&nbsp;trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.<br  /><br  />Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (<a href=\"http://vinades.vn/\" target=\"_blank\">VINADES.,JSC</a>) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.</p>', 'mic.gov.vn', 2, 0, 1, 1, 1, 0), 
(6, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 1, 0, 1, 1, 1, 0), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.<br  /><br  />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân.<p style=\"text-align: justify;\"><strong>1. Vị trí dự tuyển</strong>: Chuyên viên đồ hoạ; Lập trình viên.</p><p style=\"text-align: justify;\"><strong>2. Mô tả công việc:</strong></p>Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.<p style=\"text-align: justify;\">Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:</p><p style=\"margin-left: 40px; text-align: justify;\">+ Vẽ và cắt giao diện.</p><p style=\"margin-left: 40px; text-align: justify;\">+ Valid CSS, xHTML.</p><p style=\"margin-left: 40px; text-align: justify;\">+ Ghép giao diện cho hệ thống.</p><strong>3. Yêu cầu: </strong><br  /><br  />Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.<br  /><br  />Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML.<p style=\"text-align: justify; margin-left: 40px;\">+ Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.</p><p style=\"text-align: justify; margin-left: 40px;\">+ Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)</p>Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.<p style=\"text-align: justify;\"><strong>4: Quyền lợi:</strong></p><p style=\"text-align: justify;\"><strong>-</strong> Lương: thoả thuận, trả qua ATM.</p><p style=\"text-align: justify;\">- Thưởng theo dự án, các ngày lễ tết.</p><p style=\"text-align: justify;\">- Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</p><p style=\"text-align: justify;\"><strong>5. Thời gian làm việc:</strong> Toàn thời gian cố định hoặc làm <strong>online</strong>.</p><p style=\"text-align: justify;\"><strong>6. Hạn nộp hồ sơ</strong>: Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a></p><p style=\"text-align: justify;\"><strong>7. Hồ sơ bao gồm:</strong></p><p style=\"text-align: justify;\">&nbsp;&nbsp;<strong>&nbsp; *&nbsp; Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn<br  />&nbsp;&nbsp;&nbsp; *&nbsp; <strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br  /><br  /><strong>+ Đơn xin việc:</strong> Tự biên soạn.</p><p style=\"text-align: justify;\"><strong>+ Thông tin ứng viên:</strong> Theo mẫu của VINADES.,JSC (dowload tại đây: <strong><u><a href=\"http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/\" target=\"_blank\" title=\"Mẫu lý lịch ứng viên\">Mẫu lý lịch ứng viên</a></u></strong>)<br  /><br  />Chi tiết vui lòng tham khảo tại: <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  />Mọi thắc mắc vui lòng liên hệ:<br  /><br  /><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-4-85872007 - Fax: +84-4-35500914<br  />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div>', 'http://vinades.vn/vi/news/Tuyen-dung/', 2, 0, 1, 1, 1, 0), 
(12, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(13, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(14, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(15, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(16, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(17, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', 'http://dantri.com.vn/c119/s119-539911/nhan-tai-dat-viet-chap-canh-khat-khao-sang-tao.htm', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_bodytext`
--

DROP TABLE IF EXISTS `nv4_vi_new2_bodytext`;
CREATE TABLE `nv4_vi_new2_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_bodytext`
--

INSERT INTO `nv4_vi_new2_bodytext` VALUES
(1, 'Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam. Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế. NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm xem chi tiết), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov xem chi tiết); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.'), 
(11, 'Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.  Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.  Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.  Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.  Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/ tại đây.  Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.  Đồng thời, các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.  Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.  Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (http://vinades.vn/ VINADES.,JSC) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.'), 
(6, 'THƯ MỜI HỢP TÁC TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN MÃ NGUỒN MỞ NUKEVIET Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh. VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này. NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển. Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên. Phương thức hợp tác nhưsau: 1.Quảng cáo, trao đổi banner, liên kết website: a. Mô tả hình thức: - Quảng cáo trên website & hệ thống kênh truyền thông của 2 bên. - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet. b, Lợi ích: - Quảng bá rộng rãi cho đối tượng của 2 bên. - Giảm chi phí quảng bá cho 2 bên. c, Trách nhiệm: - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên. - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet. 2.Hợp tác cung cấp hosting thử nghiệm NukeViet: a. Mô tả hình thức: - Hai bên ký hợp đồng nguyên tắc & thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó: + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt. + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet. b. Lợi ích: - Mở rộng thị trường theo cả hướng đối tượng. - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh. c. Trách nhiệm: - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác. - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác. 3,Hợp tác nhân lực hỗ trợ người sử dụng: a, Mô tả hình thức: - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng. + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác. b, Lợi ích: - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên. - Tăng hiệu quả hỗ trợ khách hàng. c, Trách nhiệm: - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này. 4. Các hình thức khác: Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam. Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”. Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị. Thông tin liên hệ: CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC) Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. Điện thoại: +84-4-85872007 Fax: +84-4-35500914 Website: http://www.vinades.vn/ www.vinades.vn – http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn'), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.  Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. 1. Vị trí dự tuyển: Chuyên viên đồ hoạ; Lập trình viên.  2. Mô tả công việc: Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.  Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:  + Vẽ và cắt giao diện.  + Valid CSS, xHTML.  + Ghép giao diện cho hệ thống. 3. Yêu cầu:   Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.  Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML. + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.  + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+) Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.  4: Quyền lợi:  - Lương: thoả thuận, trả qua ATM.  - Thưởng theo dự án, các ngày lễ tết.  - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...  5. Thời gian làm việc: Toàn thời gian cố định hoặc làm online.  6. Hạn nộp hồ sơ: Không hạn chế, vui lòng kiểm tra tại http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/  7. Hồ sơ bao gồm:   * Cách thức đăng ký dự tuyển: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn  * Nội dung hồ sơ xin việc file mềm gồm:  + Đơn xin việc: Tự biên soạn.  + Thông tin ứng viên: Theo mẫu của VINADES.,JSC (dowload tại đây: http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/ Mẫu lý lịch ứng viên)  Chi tiết vui lòng tham khảo tại: http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/  Mọi thắc mắc vui lòng liên hệ:  Công ty cổ phần phát triển nguồn mở Việt Nam. Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.  - Tel: +84-4-85872007 - Fax: +84-4-35500914 - Email: mailto:contact@vinades.vn contact@vinades.vn - Website: http://www.vinades.vn/ http://www.vinades.vn'), 
(12, 'Đang cập nhật nội dung'), 
(13, 'Đang cập nhật nội dung'), 
(14, 'Đang cập nhật nội dung'), 
(15, 'Đang cập nhật nội dung'), 
(16, 'Đang cập nhật nội dung'), 
(17, 'Đang cập nhật nội dung'), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg Sân khấu trước lễ trao giải. Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm. Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải. Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới dự Lễ trao giải. 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan. Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số… http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg Giáo sư - Viện sỹ Nguyễn Văn Hiệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam. Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải. Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg Tiết mục mở màn Lễ trao giải. Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự. Hà Nội, ngày 16 tháng 11 năm 2011 Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt. Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay. Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế. Chào thân ái, Chủ tịch danh dự Hội Khuyến học Việt Nam Đại tướng Võ Nguyên Giáp Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt. Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp các vị lãnh đạo Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ. Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia. “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang. Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng mới ra đời cách đây 7 năm. Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải. * Giải thưởng Khoa học Tự nhiên Việt Nam thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân. GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam. Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ. GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.” GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam. * Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược: 2 giải 1. Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình “Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp, 2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức. Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác. 2. Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu “Triển khai ghép tim trên người lấy từ người cho chết não”. Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế). http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt. Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện. --------------------- * Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin. Hệ thống sản phẩm đã ứng dụng thực tế: Giải Nhất: Không có. Giải Nhì: Không có Giải Ba: 3 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ cạc xử lý tín hiệu HDTV” của nhóm HD Việt Nam. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg Nhóm HDTV Việt Nam lên nhận giải. Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào. 2. “Mã nguồn mở NukeViet” của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). /uploads/news/2011_11/nukeviet-nhantaidatviet2011.jpg NukeViet nhận giải ba Nhân tài đất Việt 2011 NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. 3. “Hệ thống ngôi nhà thông minh homeON” của nhóm Smart home group. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ. * Hệ thống sản phẩm có tiềm năng ứng dụng: Giải Nhất: Không có. Giải Nhì: trị giá 50 triệu đồng: “Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion” của nhóm tác giả SIG. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng. ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động. Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.” Giải Ba: 2 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ điều khiển IPNET” của nhóm IPNET http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET. Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc. 2. “Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX” của nhóm LYNX. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome… Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng. Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_cat`
--

DROP TABLE IF EXISTS `nv4_vi_new2_cat`;
CREATE TABLE `nv4_vi_new2_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL,
  `titlesite` varchar(250) DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_cat`
--

INSERT INTO `nv4_vi_new2_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 4, 2, 0, '', '', 1274986690, 1274986690, '6'), 
(2, 0, 'Sản phẩm', '', 'San-pham', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274986705, 1274986705, '6'), 
(8, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987105, 1274987244, '6'), 
(9, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987212, 1274987212, '6'), 
(10, 0, 'Đối tác', '', 'Doi-tac', '', '', '', 0, 3, 9, 0, 'viewcat_main_right', 0, '', 1, 4, 2, 0, '', '', 1274987460, 1274987460, '6'), 
(11, 0, 'Tuyển dụng', '', 'Tuyen-dung', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987538, 1274987538, '6'), 
(12, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987902, 1274987902, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_new2_config_post`;
CREATE TABLE `nv4_vi_new2_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_logs`
--

DROP TABLE IF EXISTS `nv4_vi_new2_logs`;
CREATE TABLE `nv4_vi_new2_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_rows`
--

DROP TABLE IF EXISTS `nv4_vi_new2_rows`;
CREATE TABLE `nv4_vi_new2_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_rows`
--

INSERT INTO `nv4_vi_new2_rows` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(12, 11, '11', 0, 1, '', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(13, 11, '11', 0, 1, '', 0, 1445391088, 1445394191, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ, kỹ thuật viên', 'tuyen-dung-chuyen-vien-do-hoa-ky-thuat-vien', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(7, 11, '11', 0, 1, '', 2, 1307197282, 1445390968, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'tuyen-dung-lap-trinh-vien-php-phat-trien-nukeviet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '', 1, 1, '2', 1, 1, 0, 0, 0), 
(14, 1, '1', 0, 1, '', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(17, 1, '1', 0, 1, '', 0, 1445391217, 1445393997, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_sources`
--

DROP TABLE IF EXISTS `nv4_vi_new2_sources`;
CREATE TABLE `nv4_vi_new2_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_sources`
--

INSERT INTO `nv4_vi_new2_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 4, 1322685396, 1322685396), 
(4, 'Bộ Thông tin và Truyền thông', 'http://http://mic.gov.vn', '', 5, 1445309676, 1445309676);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_tags`
--

DROP TABLE IF EXISTS `nv4_vi_new2_tags`;
CREATE TABLE `nv4_vi_new2_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_tags`
--

INSERT INTO `nv4_vi_new2_tags` VALUES
(1, 1, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 1, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 1, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 1, 'việt-nam', '', '', 'việt nam'), 
(5, 1, 'hoạt-động', '', '', 'hoạt động'), 
(6, 1, 'tin-tức', '', '', 'tin tức'), 
(7, 1, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 1, 'điện-tử', '', '', 'điện tử'), 
(9, 3, 'nukeviet', '', '', 'nukeviet'), 
(10, 1, 'vinades', '', '', 'vinades'), 
(11, 1, 'lập-trình-viên', '', '', 'lập trình viên'), 
(12, 1, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(13, 1, 'php', '', '', 'php'), 
(14, 1, 'mysql', '', '', 'mysql'), 
(15, 1, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(16, 1, 'mã-nguồn-mở', '', '', 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_new2_tags_id`;
CREATE TABLE `nv4_vi_new2_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_tags_id`
--

INSERT INTO `nv4_vi_new2_tags_id` VALUES
(1, 1, 'nguồn mở'), 
(1, 2, 'quen thuộc'), 
(1, 3, 'cộng đồng'), 
(1, 4, 'việt nam'), 
(1, 5, 'hoạt động'), 
(1, 6, 'tin tức'), 
(1, 7, 'thương mại điện'), 
(1, 8, 'điện tử'), 
(1, 9, 'nukeviet'), 
(7, 10, 'vinades'), 
(7, 9, 'nukeviet'), 
(7, 11, 'lập trình viên'), 
(7, 12, 'chuyên viên đồ họa'), 
(7, 13, 'php'), 
(7, 14, 'mysql'), 
(10, 15, 'Nhân tài đất Việt 2011'), 
(10, 16, 'mã nguồn mở'), 
(10, 9, 'nukeviet');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_new2_topics`
--

DROP TABLE IF EXISTS `nv4_vi_new2_topics`;
CREATE TABLE `nv4_vi_new2_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_new2_topics`
--

INSERT INTO `nv4_vi_new2_topics` VALUES
(1, 'NukeViet 4', 'NukeViet-4', '', 'NukeViet 4', 1, 'NukeViet 4', 1445396011, 1445396011);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_1`;
CREATE TABLE `nv4_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_1`
--

INSERT INTO `nv4_vi_news_1` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(14, 1, '1', 0, 1, '', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(17, 1, '1', 0, 1, '', 0, 1445391217, 1445393997, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_10`
--

DROP TABLE IF EXISTS `nv4_vi_news_10`;
CREATE TABLE `nv4_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_10`
--

INSERT INTO `nv4_vi_news_10` VALUES
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_11`
--

DROP TABLE IF EXISTS `nv4_vi_news_11`;
CREATE TABLE `nv4_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_11`
--

INSERT INTO `nv4_vi_news_11` VALUES
(7, 11, '11', 0, 1, '', 2, 1307197282, 1445390968, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'tuyen-dung-lap-trinh-vien-php-phat-trien-nukeviet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '', 1, 1, '2', 1, 1, 0, 0, 0), 
(12, 11, '11', 0, 1, '', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(13, 11, '11', 0, 1, '', 0, 1445391088, 1445394191, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ, kỹ thuật viên', 'tuyen-dung-chuyen-vien-do-hoa-ky-thuat-vien', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_12`
--

DROP TABLE IF EXISTS `nv4_vi_news_12`;
CREATE TABLE `nv4_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_12`
--

INSERT INTO `nv4_vi_news_12` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_2`
--

DROP TABLE IF EXISTS `nv4_vi_news_2`;
CREATE TABLE `nv4_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_8`
--

DROP TABLE IF EXISTS `nv4_vi_news_8`;
CREATE TABLE `nv4_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_8`
--

INSERT INTO `nv4_vi_news_8` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_9`
--

DROP TABLE IF EXISTS `nv4_vi_news_9`;
CREATE TABLE `nv4_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_9`
--

INSERT INTO `nv4_vi_news_9` VALUES
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_admins`
--

DROP TABLE IF EXISTS `nv4_vi_news_admins`;
CREATE TABLE `nv4_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block`
--

DROP TABLE IF EXISTS `nv4_vi_news_block`;
CREATE TABLE `nv4_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block`
--

INSERT INTO `nv4_vi_news_block` VALUES
(1, 1, 1), 
(2, 14, 4), 
(2, 12, 6), 
(2, 6, 9), 
(2, 13, 5), 
(2, 11, 7), 
(2, 1, 8), 
(2, 15, 3), 
(2, 16, 2), 
(2, 17, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_block_cat`;
CREATE TABLE `nv4_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block_cat`
--

INSERT INTO `nv4_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodyhtml_1`;
CREATE TABLE `nv4_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodyhtml_1`
--

INSERT INTO `nv4_vi_news_bodyhtml_1` VALUES
(1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br /> <br /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br /> <br /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br /> <br /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', 1, 0, 1, 1, 1, 0), 
(11, '<div style=\"text-align: justify;\">Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.<br  /><br  />Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những&nbsp;sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.</div><p style=\"text-align: justify;\">Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.</p><p style=\"text-align: justify;\">Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.</p><p style=\"text-align: justify;\">Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước.&nbsp;NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có&nbsp;<a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/\" target=\"_blank\">tại đây</a>.</p><p style=\"text-align: justify;\">Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải&nbsp;ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu&nbsp;như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Đồng thời,&nbsp;các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở&nbsp;trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p style=\"text-align: justify;\">Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.<br  /><br  />Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (<a href=\"http://vinades.vn/\" target=\"_blank\">VINADES.,JSC</a>) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.</p>', 'mic.gov.vn', 2, 0, 1, 1, 1, 0), 
(6, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 1, 0, 1, 1, 1, 0), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.<br  /><br  />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân.<p style=\"text-align: justify;\"><strong>1. Vị trí dự tuyển</strong>: Chuyên viên đồ hoạ; Lập trình viên.</p><p style=\"text-align: justify;\"><strong>2. Mô tả công việc:</strong></p>Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.<p style=\"text-align: justify;\">Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:</p><p style=\"margin-left: 40px; text-align: justify;\">+ Vẽ và cắt giao diện.</p><p style=\"margin-left: 40px; text-align: justify;\">+ Valid CSS, xHTML.</p><p style=\"margin-left: 40px; text-align: justify;\">+ Ghép giao diện cho hệ thống.</p><strong>3. Yêu cầu: </strong><br  /><br  />Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.<br  /><br  />Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML.<p style=\"text-align: justify; margin-left: 40px;\">+ Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.</p><p style=\"text-align: justify; margin-left: 40px;\">+ Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)</p>Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.<p style=\"text-align: justify;\"><strong>4: Quyền lợi:</strong></p><p style=\"text-align: justify;\"><strong>-</strong> Lương: thoả thuận, trả qua ATM.</p><p style=\"text-align: justify;\">- Thưởng theo dự án, các ngày lễ tết.</p><p style=\"text-align: justify;\">- Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</p><p style=\"text-align: justify;\"><strong>5. Thời gian làm việc:</strong> Toàn thời gian cố định hoặc làm <strong>online</strong>.</p><p style=\"text-align: justify;\"><strong>6. Hạn nộp hồ sơ</strong>: Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a></p><p style=\"text-align: justify;\"><strong>7. Hồ sơ bao gồm:</strong></p><p style=\"text-align: justify;\">&nbsp;&nbsp;<strong>&nbsp; *&nbsp; Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn<br  />&nbsp;&nbsp;&nbsp; *&nbsp; <strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br  /><br  /><strong>+ Đơn xin việc:</strong> Tự biên soạn.</p><p style=\"text-align: justify;\"><strong>+ Thông tin ứng viên:</strong> Theo mẫu của VINADES.,JSC (dowload tại đây: <strong><u><a href=\"http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/\" target=\"_blank\" title=\"Mẫu lý lịch ứng viên\">Mẫu lý lịch ứng viên</a></u></strong>)<br  /><br  />Chi tiết vui lòng tham khảo tại: <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  />Mọi thắc mắc vui lòng liên hệ:<br  /><br  /><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-4-85872007 - Fax: +84-4-35500914<br  />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div>', 'http://vinades.vn/vi/news/Tuyen-dung/', 2, 0, 1, 1, 1, 0), 
(12, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(13, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(14, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(15, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(16, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(17, 'Đang cập nhật nội dung', '', 2, 0, 1, 1, 1, 0), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', 'http://dantri.com.vn/c119/s119-539911/nhan-tai-dat-viet-chap-canh-khat-khao-sang-tao.htm', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodytext`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodytext`;
CREATE TABLE `nv4_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodytext`
--

INSERT INTO `nv4_vi_news_bodytext` VALUES
(1, 'Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam. Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế. NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm xem chi tiết), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov xem chi tiết); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.'), 
(11, 'Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.  Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.  Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.  Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.  Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/ tại đây.  Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.  Đồng thời, các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.  Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.  Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (http://vinades.vn/ VINADES.,JSC) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.'), 
(6, 'THƯ MỜI HỢP TÁC TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN MÃ NGUỒN MỞ NUKEVIET Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh. VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này. NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển. Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên. Phương thức hợp tác nhưsau: 1.Quảng cáo, trao đổi banner, liên kết website: a. Mô tả hình thức: - Quảng cáo trên website & hệ thống kênh truyền thông của 2 bên. - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet. b, Lợi ích: - Quảng bá rộng rãi cho đối tượng của 2 bên. - Giảm chi phí quảng bá cho 2 bên. c, Trách nhiệm: - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên. - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet. 2.Hợp tác cung cấp hosting thử nghiệm NukeViet: a. Mô tả hình thức: - Hai bên ký hợp đồng nguyên tắc & thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó: + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt. + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet. b. Lợi ích: - Mở rộng thị trường theo cả hướng đối tượng. - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh. c. Trách nhiệm: - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác. - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác. 3,Hợp tác nhân lực hỗ trợ người sử dụng: a, Mô tả hình thức: - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng. + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác. b, Lợi ích: - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên. - Tăng hiệu quả hỗ trợ khách hàng. c, Trách nhiệm: - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này. 4. Các hình thức khác: Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam. Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”. Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị. Thông tin liên hệ: CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC) Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. Điện thoại: +84-4-85872007 Fax: +84-4-35500914 Website: http://www.vinades.vn/ www.vinades.vn – http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn'), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.  Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. 1. Vị trí dự tuyển: Chuyên viên đồ hoạ; Lập trình viên.  2. Mô tả công việc: Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.  Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:  + Vẽ và cắt giao diện.  + Valid CSS, xHTML.  + Ghép giao diện cho hệ thống. 3. Yêu cầu:   Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.  Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML. + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.  + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+) Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.  4: Quyền lợi:  - Lương: thoả thuận, trả qua ATM.  - Thưởng theo dự án, các ngày lễ tết.  - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...  5. Thời gian làm việc: Toàn thời gian cố định hoặc làm online.  6. Hạn nộp hồ sơ: Không hạn chế, vui lòng kiểm tra tại http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/  7. Hồ sơ bao gồm:   * Cách thức đăng ký dự tuyển: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn  * Nội dung hồ sơ xin việc file mềm gồm:  + Đơn xin việc: Tự biên soạn.  + Thông tin ứng viên: Theo mẫu của VINADES.,JSC (dowload tại đây: http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/ Mẫu lý lịch ứng viên)  Chi tiết vui lòng tham khảo tại: http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/  Mọi thắc mắc vui lòng liên hệ:  Công ty cổ phần phát triển nguồn mở Việt Nam. Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.  - Tel: +84-4-85872007 - Fax: +84-4-35500914 - Email: mailto:contact@vinades.vn contact@vinades.vn - Website: http://www.vinades.vn/ http://www.vinades.vn'), 
(12, 'Đang cập nhật nội dung'), 
(13, 'Đang cập nhật nội dung'), 
(14, 'Đang cập nhật nội dung'), 
(15, 'Đang cập nhật nội dung'), 
(16, 'Đang cập nhật nội dung'), 
(17, 'Đang cập nhật nội dung'), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg Sân khấu trước lễ trao giải. Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm. Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải. Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới dự Lễ trao giải. 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan. Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số… http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg Giáo sư - Viện sỹ Nguyễn Văn Hiệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam. Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải. Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg Tiết mục mở màn Lễ trao giải. Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự. Hà Nội, ngày 16 tháng 11 năm 2011 Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt. Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay. Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế. Chào thân ái, Chủ tịch danh dự Hội Khuyến học Việt Nam Đại tướng Võ Nguyên Giáp Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt. Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp các vị lãnh đạo Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ. Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia. “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang. Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng mới ra đời cách đây 7 năm. Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải. * Giải thưởng Khoa học Tự nhiên Việt Nam thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân. GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam. Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ. GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.” GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam. * Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược: 2 giải 1. Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình “Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp, 2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức. Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác. 2. Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu “Triển khai ghép tim trên người lấy từ người cho chết não”. Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế). http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt. Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện. --------------------- * Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin. Hệ thống sản phẩm đã ứng dụng thực tế: Giải Nhất: Không có. Giải Nhì: Không có Giải Ba: 3 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ cạc xử lý tín hiệu HDTV” của nhóm HD Việt Nam. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg Nhóm HDTV Việt Nam lên nhận giải. Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào. 2. “Mã nguồn mở NukeViet” của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). /uploads/news/2011_11/nukeviet-nhantaidatviet2011.jpg NukeViet nhận giải ba Nhân tài đất Việt 2011 NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. 3. “Hệ thống ngôi nhà thông minh homeON” của nhóm Smart home group. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ. * Hệ thống sản phẩm có tiềm năng ứng dụng: Giải Nhất: Không có. Giải Nhì: trị giá 50 triệu đồng: “Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion” của nhóm tác giả SIG. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng. ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động. Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.” Giải Ba: 2 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ điều khiển IPNET” của nhóm IPNET http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET. Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc. 2. “Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX” của nhóm LYNX. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome… Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng. Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_cat`;
CREATE TABLE `nv4_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL,
  `titlesite` varchar(250) DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_cat`
--

INSERT INTO `nv4_vi_news_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 4, 2, 0, '', '', 1274986690, 1274986690, '6'), 
(2, 0, 'Sản phẩm', '', 'San-pham', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274986705, 1274986705, '6'), 
(8, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987105, 1274987244, '6'), 
(9, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987212, 1274987212, '6'), 
(10, 0, 'Đối tác', '', 'Doi-tac', '', '', '', 0, 3, 9, 0, 'viewcat_main_right', 0, '', 1, 4, 2, 0, '', '', 1274987460, 1274987460, '6'), 
(11, 0, 'Tuyển dụng', '', 'Tuyen-dung', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987538, 1274987538, '6'), 
(12, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987902, 1274987902, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_news_config_post`;
CREATE TABLE `nv4_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_logs`
--

DROP TABLE IF EXISTS `nv4_vi_news_logs`;
CREATE TABLE `nv4_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_rows`
--

DROP TABLE IF EXISTS `nv4_vi_news_rows`;
CREATE TABLE `nv4_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_rows`
--

INSERT INTO `nv4_vi_news_rows` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 2, 0, 0, 0), 
(11, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 2, 0, 0, 0), 
(12, 11, '11', 0, 1, '', 0, 1445391061, 1445394203, 1, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(13, 11, '11', 0, 1, '', 0, 1445391088, 1445394191, 1, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ, kỹ thuật viên', 'tuyen-dung-chuyen-vien-do-hoa-ky-thuat-vien', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(7, 11, '11', 0, 1, '', 2, 1307197282, 1445390968, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'tuyen-dung-lap-trinh-vien-php-phat-trien-nukeviet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '', 1, 1, '2', 1, 1, 0, 0, 0), 
(14, 1, '1', 0, 1, '', 0, 1445391118, 1445394180, 1, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(15, 1, '1,10', 0, 1, '', 0, 1445391135, 1445394444, 1, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(16, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 0, 0, 0, 0), 
(17, 1, '1', 0, 1, '', 0, 1445391217, 1445393997, 1, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Đang cập nhật nội dung', '', '', 0, 1, '4', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 3, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_sources`
--

DROP TABLE IF EXISTS `nv4_vi_news_sources`;
CREATE TABLE `nv4_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_sources`
--

INSERT INTO `nv4_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 4, 1322685396, 1322685396), 
(4, 'Bộ Thông tin và Truyền thông', 'http://http://mic.gov.vn', '', 5, 1445309676, 1445309676);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags`;
CREATE TABLE `nv4_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags`
--

INSERT INTO `nv4_vi_news_tags` VALUES
(1, 1, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 1, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 1, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 1, 'việt-nam', '', '', 'việt nam'), 
(5, 1, 'hoạt-động', '', '', 'hoạt động'), 
(6, 1, 'tin-tức', '', '', 'tin tức'), 
(7, 1, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 1, 'điện-tử', '', '', 'điện tử'), 
(9, 3, 'nukeviet', '', '', 'nukeviet'), 
(10, 1, 'vinades', '', '', 'vinades'), 
(11, 1, 'lập-trình-viên', '', '', 'lập trình viên'), 
(12, 1, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(13, 1, 'php', '', '', 'php'), 
(14, 1, 'mysql', '', '', 'mysql'), 
(15, 1, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(16, 1, 'mã-nguồn-mở', '', '', 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags_id`;
CREATE TABLE `nv4_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags_id`
--

INSERT INTO `nv4_vi_news_tags_id` VALUES
(1, 1, 'nguồn mở'), 
(1, 2, 'quen thuộc'), 
(1, 3, 'cộng đồng'), 
(1, 4, 'việt nam'), 
(1, 5, 'hoạt động'), 
(1, 6, 'tin tức'), 
(1, 7, 'thương mại điện'), 
(1, 8, 'điện tử'), 
(1, 9, 'nukeviet'), 
(7, 10, 'vinades'), 
(7, 9, 'nukeviet'), 
(7, 11, 'lập trình viên'), 
(7, 12, 'chuyên viên đồ họa'), 
(7, 13, 'php'), 
(7, 14, 'mysql'), 
(10, 15, 'Nhân tài đất Việt 2011'), 
(10, 16, 'mã nguồn mở'), 
(10, 9, 'nukeviet');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_topics`
--

DROP TABLE IF EXISTS `nv4_vi_news_topics`;
CREATE TABLE `nv4_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_topics`
--

INSERT INTO `nv4_vi_news_topics` VALUES
(1, 'NukeViet 4', 'NukeViet-4', '', 'NukeViet 4', 1, 'NukeViet 4', 1445396011, 1445396011);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page`
--

DROP TABLE IF EXISTS `nv4_vi_page`;
CREATE TABLE `nv4_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page_config`
--

DROP TABLE IF EXISTS `nv4_vi_page_config`;
CREATE TABLE `nv4_vi_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_page_config`
--

INSERT INTO `nv4_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv4_vi_referer_stats`;
CREATE TABLE `nv4_vi_referer_stats` (
  `host` varchar(250) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv4_vi_searchkeys`;
CREATE TABLE `nv4_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_siteterms`
--

DROP TABLE IF EXISTS `nv4_vi_siteterms`;
CREATE TABLE `nv4_vi_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_siteterms`
--

INSERT INTO `nv4_vi_siteterms` VALUES
(1, 'Chính sách bảo mật (Quyền riêng tư)', 'privacy', '', '', '', '<h2 style=\"text-align: justify;\">Điều 1: Thu thập thông tin</h2><h3 style=\"text-align: justify;\">1.1. Thu thập tự động:</h3><div style=\"text-align: justify;\">Như mọi website hiện đại khác, Chúng tôi sẽ thu thập địa chỉ IP và các thông tin web tiêu chuẩn khác của bạn như: loại trình duyệt, các trang bạn truy cập trong quá trình sử dụng dịch vụ, thông tin về máy tính &amp; thiết bị mạng v.v… cho mục đích phân tích thông tin phục vụ việc bảo mật và giữ an toàn cho hệ thống.</div><h3 style=\"text-align: justify;\">1.2. Thu thập từ các khai báo của chính bạn:</h3><div style=\"text-align: justify;\">Các thông tin do bạn khai báo cho chúng tôi trong quá trình làm việc như: đăng ký tài khoản, liên hệ với chúng tôi... cũng sẽ được chúng tôi lưu trữ phục vụ công việc chăm sóc khách hàng sau này.</div><h3 style=\"text-align: justify;\">1.3. Thu thập thông tin thông qua việc đặt cookies:</h3><p style=\"text-align: justify;\">Như mọi website hiện đại khác, khi bạn truy cập website, chúng tôi (hoặc các công cụ theo dõi hoặc thống kê hoạt động của website do các đối tác cung cấp) sẽ đặt một số File dữ liệu gọi là Cookies lên đĩa cứng hoặc bộ nhớ máy tính của bạn.</p><p style=\"text-align: justify;\">Một trong số những Cookies này có thể tồn tại lâu để thuận tiện cho bạn trong quá trình sử dụng, ví dụ như: lưu Email của bạn trong trang đăng nhập để bạn không phải nhập lại v.v…</p><h3 style=\"text-align: justify;\">1.4. Thu thập và lưu trữ thông tin trong quá khứ:</h3><p style=\"text-align: justify;\">Bạn có thể thay đổi thông tin cá nhân của mình bất kỳ lúc nào bằng cách sử dụng chức năng tương ứng. Tuy nhiên chúng tôi sẽ lưu lại những thông tin bị thay đổi để chống các hành vi xóa dấu vết gian lận.</p><h2 style=\"text-align: justify;\"><br  />Điều 2: Lưu trữ &amp; Bảo vệ thông tin</h2><div style=\"text-align: justify;\">Hầu hết các thông tin được thu thập sẽ được lưu trữ tại cơ sở dữ liệu của chúng tôi.<br  /><br  />Chúng tôi bảo vệ dữ liệu cá nhân của các bạn bằng các hình thức như: mật khẩu, tường lửa, mã hóa cùng các hình thức thích hợp khác và chỉ cấp phép việc truy cập và xử lý dữ liệu cho các đối tượng phù hợp, ví dụ chính bạn hoặc các nhân viên có trách nhiệm xử thông tin với bạn thông qua các bước xác định danh tính phù hợp.</div><h2 style=\"text-align: justify;\"><br  />Điều 3: Sử dụng thông tin</h2><p style=\"text-align: justify;\">Thông tin thu thập được sẽ được chúng tôi sử dụng để:</p><blockquote><p style=\"text-align: justify;\">o Cung cấp các dịch vụ hỗ trợ &amp; chăm sóc khách hàng.</p><p style=\"text-align: justify;\">o Thực hiện giao dịch thanh toán &amp; gửi các thông báo trong quá trình giao dịch.</p><p style=\"text-align: justify;\">o Xử lý khiếu nại, thu phí &amp; giải quyết sự cố.</p><p style=\"text-align: justify;\">o Ngăn chặn các hành vi có nguy cơ rủi ro, bị cấm hoặc bất hợp pháp và đảm bảo tuân thủ đúng chính sách “Thỏa thuận người dùng”.</p><p style=\"text-align: justify;\">o Đo đạc, tùy biến &amp; cải tiến dịch vụ, nội dung và hình thức của website.</p><p style=\"text-align: justify;\">o Gửi bạn các thông tin về chương trình Marketing, các thông báo &amp; chương trình khuyến mại.</p><p style=\"text-align: justify;\">o So sánh độ chính xác của thông tin cá nhân của bạn trong quá trình kiểm tra với bên thứ ba.</p></blockquote><h2 style=\"text-align: justify;\"><br  />Điều 4: Tiếp nhận thông tin từ các đối tác</h2><div style=\"text-align: justify;\">Khi sử dụng các công cụ giao dịch và thanh toán thông qua internet, chúng tôi có thể tiếp nhận thêm các thông tin về bạn như địa chỉ username, Email, số tài khoản ngân hàng... Chúng tôi kiểm tra những thông tin này với cơ sở dữ liệu người dùng của mình nhằm xác nhận rằng bạn có phải là khách hàng của chúng tôi hay không nhằm giúp việc thực hiện các dịch vụ cho bạn được thuận lợi.<br  /><br  />Các thông tin tiếp nhận được sẽ được chúng tôi bảo mật như những thông tin mà chúng tôi thu thập được trực tiếp từ bạn.</div><h2 style=\"text-align: justify;\"><br  />Điều 5: Chia sẻ thông tin với bên thứ ba</h2><p style=\"text-align: justify;\">Chúng tôi sẽ không chia sẻ thông tin cá nhân, thông tin tài chính... của bạn cho các bên thứ 3 trừ khi được sự đồng ý của chính bạn hoặc khi chúng tôi buộc phải tuân thủ theo các quy định pháp luật hoặc khi có yêu cầu từ cơ quan công quyền có thẩm quyền.</p><h2 style=\"text-align: justify;\"><br  />Điều 6: Thay đổi chính sách bảo mật</h2><p style=\"text-align: justify;\">Chính sách Bảo mật này có thể thay đổi theo thời gian. Chúng tôi sẽ không giảm quyền của bạn theo Chính sách Bảo mật này mà không có sự đồng ý rõ ràng của bạn. Chúng tôi sẽ đăng bất kỳ thay đổi Chính sách Bảo mật nào trên trang này và, nếu những thay đổi này quan trọng, chúng tôi sẽ cung cấp thông báo nổi bật hơn (bao gồm, đối với một số dịch vụ nhất định, thông báo bằng email về các thay đổi của Chính sách Bảo mật).<br  />&nbsp;</p><p style=\"text-align: right;\">Tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a></p>', '', 0, '4', '', 0, 1, 1, 1459471000, 1459471000, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_siteterms_config`
--

DROP TABLE IF EXISTS `nv4_vi_siteterms_config`;
CREATE TABLE `nv4_vi_siteterms_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_siteterms_config`
--

INSERT INTO `nv4_vi_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting`
--

DROP TABLE IF EXISTS `nv4_vi_voting`;
CREATE TABLE `nv4_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(250) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting`
--

INSERT INTO `nv4_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv4_vi_voting_rows`;
CREATE TABLE `nv4_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(245) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting_rows`
--

INSERT INTO `nv4_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);